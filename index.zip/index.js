// ========[ MÓDULOS E FUNÇÕES ]======= \\
const { downloadContentFromMessage, prepareWAMessageMedia, relayWAMessage, mentionedJid, processTime, MediaType, proto, Browser, MessageType, Presence, Mimetype, Browsers, delay, getLastMessageInChat, WA_DEFAULT_EPHEMERAL } = require('@whiskeysockets/baileys');

// ======[ JS-MENUS/INFORMAÇÕES ]====== \\

const { linguagem, mess, getInfo, menu, infodono, menudono, adms, menulogos, efeitos, menuprem, brincadeiras, alteradores, destrava, destrava2, tabela, conselhob, palavrasc, ban, joguinhodavelhajs, joguinhodavelhajs2, nescessario, logoslink, premium, muted, rg_aluguel, sendVideoAsSticker, sendImageAsSticker, sendVideoAsSticker2, sendImageAsSticker2, sotoy, comandos, limitefll, addVote, delVote, patentes, antispam, anotar, black_, enviarfiguUrl, getFileBuffer, DLT_FL, sleep, ANT_LTR_MD_EMJ, EnvBotao, fs, Boom, sendHours, axios, yts, crypto, util, P, linkfy, request, cheerio, ms, ffmpeg, webp_mp4, webp_mp42, qrterminal, exec, spawn, execSync, moment, color, time, hora, date, getBuffer, convertSticker, recognize, fetchJson, fetchText, fetch, getBase64, createExif, writeExifImg, addLimit, upload, nit, addBanned, unBanned, BannedExpired, cekBannedUser, validmove, setGame, addComandosId, deleteComandos, getComandoBlock, getComandos, addComandos, palavrasANA, quizanimais, garticArchives, whatMusic, enigmaArchive, getpc, supre, wait, getExtension, generateMessageID, getGroupAdmins, getMembros, getRandom, banner2, banner3, temporizador, chyt, kyun, simih, botoff, colors, RSM_FUNC, infoSystem, os, arcloud, EmojiAPI, emoji, infoClima, insert, response, addFilter, isFiltered, mines, getMinesPositions, MinesHelp, ytdl, MultiDownload, AssemblyAI, level2, addKoinUser, checkATMuser, confirmATM, addATM, confirmBANCO, checkATBANCO, addKoinBanco, addBANCO, didins, banco, roupab, confirmDIAMANTE, addKoinDiamante, checkATDIAMNTE, addDIAMANTE, diamante, vida, fomegato, petgato, level, _level, _leveling, addKoinComidagato, checkATMGato, addCOMIDAGATO, addKoinFomeGato, checkATMFOMEGARTO, addFOMEGATO, confirmATMvida, addVidauser, checkATMvida, addATMVida, getLevelingXp, getLevelingLevel, getLevelingId, addLevelingXp, addLevelingLevel, addLevelingId, gato, hentai, getLevelingIdd, getLevelingmiss, getLevelingXpp, addLevelingXpp, addLevelingLevell, addLevelingIdd, carab, caussa, sapato, palitor, confirmATMdano, checkATMdano, addATMdano, adddanouser, confirmATMdefesa, checkATMdefesa, adddefesauser, addATMdefesa, confirmATMataque, checkATMataque, addataqueuser, addATMataque, dano, defesa, ataque, divida, addATMbatalhaperdida, addbatalhaperdidauser, checkATMbatalhaperdida, isBlackCityOff, confirmATMbatalhaperdida, addATMbatalhaganhas, addbatalhaganhasuser, checkATMbatalhaganhas, confirmATMbatalhaganhas, confirmcartao, checkATcartao, addKoincartao, addcartao, addpicareta, addKoinpicareta, checkATpicareta, confirmpicareta, addaquipado, addKoinaquipado, checkATaquipado, confirmaquipado, adddesequipado, addKoindesequipado, checkATdesequipado, confirmdesequipado, zerorpg, bcbet, minerar, elitepasse, coderpg2, coderpg, galosrpg, roubosrpg, setting, autorpg, medalhao, pc, listCommands, fuzzySimilarity, daily, packname, sendButton } = require('./exports.js');

//_-_-_-_-_-_-_-_-_-_-_-_-(INFOS)_-_-_-_-_-_-_-_-_-_-_-_-_-_-_--\\

var { botoes, forwarding, crtt, visualizarmsg, akiyamasite, dono1, dono2, dono3, dono4, dono5, dono6 } = require("./settings/nescessario.json");

var { fundo1, fundo2, imgnazista, imggay, imgcorno, imggostosa, imggostoso, imgfeio, imgvesgo, imgbebado, imggado, matarcmd, beijocmd, chutecmd, tapacmd, rnkgay, rnkgado, rnkcorno, rnkgostoso, rnkgostosa, rnknazista, rnkotaku, rnkpau } = require("./settings/imagen's.json");

////==================
var { NomeDoBot, NickDono, prefix, API_KEY_MIWA } = require("./settings/settings.json");

const figurinhas = JSON.parse(fs.readFileSync("./database/data/figurinhas.json"));

const countMessage = JSON.parse(fs.readFileSync("./settings/media/countmsg.json"));
//====================≠≠===============\\

var numerodono_ofc = setting.numerodono.replace(new RegExp("[()+-/ +/]", "gi"), "");

async function reiniciarSAB() {
  file = require.resolve("./connect.js");
  delete require.cache[file];
  require(file);
}

var AsMsg = [];

process.on('uncaughtException', function (err) {

console.error((new Date).toUTCString() + ' uncaughtException:', err.message);

console.error(err.stack);

});
// ABAIXO: INÍCIO DE CONEXÃO

module.exports = upsert = async (upsert, miwa) => {
  async function msgupsrt() {
    const nmrdn_dono2 = setting.numerodono.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";

    var hora120 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');

    RSM_FUNC(miwa, nmrdn_dono2, hora120, upsert);

    for (const info of upsert?.messages || []) {

      const from = info.key.remoteJid;
      const isGroup = from.endsWith('@g.us');

      if (fs.existsSync(`./database/grupos/activation_gp/${from}.json`)) {
        var jsonGp = JSON.parse(fs.readFileSync(`./database/grupos/activation_gp/${from}.json`));
      }

      if (fs.existsSync(`./database/grupos/activation_gp/${from}.json`) && jsonGp[0].x9 && info.messageStubType) {
        switch (info.messageStubType) {
          case 29:
            await delay(1000);
            await miwa.sendMessage(info.key.remoteJid, {
              text: `O participante: [ @${info.messageStubParameters[0].split("@")[0]} ] foi promovido ao cargo de admin do grupo pelo admin - [ @${info.participant.split("@")[0]} ]`
              , mentions: [info.messageStubParameters[0], info.participant]
            });
            break;
          case 30:
            await delay(1000);
            await miwa.sendMessage(info.key.remoteJid, {
              text: `O adminstrador: [ @${info.messageStubParameters[0].split("@")[0]} ] foi rebaixado para membro comum do grupo pelo admin - [ @${info.participant.split("@")[0]} ]`
              , mentions: [info.messageStubParameters[0], info.participant]
            });
            break;
        }
      }

      if (!info.message) return;
      if (upsert.type == "append") return;
      const baileys = require('@whiskeysockets/baileys');
      const type = baileys.getContentType(info.message);
      const content = JSON.stringify(info.message);
      const pushname = info.pushName ? info.pushName : '';
      if (visualizarmsg) {
        await miwa.readMessages([info.key]);
      } else {
        if (from == "status@broadcast") return;
      }

      const largeNumber = (value) => {
        if (Number(value) < 0) return "O número precisa ser ≥ 0"
        nmr = `${Number(value).toFixed(0)}`
        if (nmr.length >= 4) {
          const existPoint = (nmr) => {
            if (Number(nmr) !== 0) return "." + `${nmr}`
            return ``
          }
          if (nmr.length >= 4) txt = nmr.slice(0, (nmr.length - 3)) + existPoint(nmr.slice((nmr.length - 3), (nmr.length - 2))) + "K"
          if (nmr.length >= 7) txt = nmr.slice(0, (nmr.length - 6)) + existPoint(nmr.slice((nmr.length - 6), (nmr.length - 5))) + "M"
          if (nmr.length >= 10) txt = nmr.slice(0, (nmr.length - 9)) + existPoint(nmr.slice((nmr.length - 9), (nmr.length - 8))) + "B"
          if (nmr.length >= 13) txt = nmr.slice(0, (nmr.length - 12)) + existPoint(nmr.slice((nmr.length - 12), (nmr.length - 11))) + "T"
        } else { txt = nmr }
        return txt
      }

      //==============(BODY)================\\

      var body = type === "conversation" ? info.message.conversation : type == "editedMessage" ? info.message.editedMessage.message.protocolMessage.editedMessage?.conversation || info.message.editedMessage.message.protocolMessage.editedMessage?.imageMessage?.caption || info.message.editedMessage.message.protocolMessage.editedMessage?.videoMessage?.caption || info.message.editedMessage.message.protocolMessage.editedMessage?.documentMessage?.caption : type === "viewOnceMessageV2" ? info.message.viewOnceMessageV2.message.imageMessage ? info.message.viewOnceMessageV2.message.imageMessage.caption : info.message.viewOnceMessageV2.message.videoMessage.caption : type === "imageMessage" ? info.message.imageMessage.caption : type === "videoMessage" ? info.message.videoMessage.caption : type === "extendedTextMessage" ? info.message.extendedTextMessage.text : type === "viewOnceMessage" ? info.message.viewOnceMessage.message.videoMessage ? info.message.viewOnceMessage.message.videoMessage.caption : info.message.viewOnceMessage.message.imageMessage.caption : type === "documentWithCaptionMessage" ? info.message.documentWithCaptionMessage.message.documentMessage.caption : type === "buttonsMessage" ? info.message.buttonsMessage.imageMessage.caption : type === "buttonsResponseMessage" ? info.message.buttonsResponseMessage.selectedButtonId : type === "listResponseMessage" ? info.message.listResponseMessage.singleSelectReply.selectedRowId : type === "templateButtonReplyMessage" ? info.message.templateButtonReplyMessage.selectedId : type === "groupInviteMessage" ? info.message.groupInviteMessage.caption : type === "pollCreationMessageV3" ? info.message.pollCreationMessageV3 : type === "interactiveResponseMessage" ? JSON.parse(info.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : type === "text" ? info.text : ""
      const budy = (type === "conversation") ?
        info.message.conversation :
        (type === "extendedTextMessage" && info.message.extendedTextMessage) ?
          info.message.extendedTextMessage.text :
          "";

      var Procurar_String = info.message?.conversation || info.message?.viewOnceMessageV2?.message?.imageMessage?.caption || info.message?.viewOnceMessageV2?.message?.videoMessage?.caption || info.message?.imageMessage?.caption || info.message?.videoMessage?.caption || info.message?.extendedTextMessage?.text || info.message?.viewOnceMessage?.message?.videoMessage?.caption || info.message?.viewOnceMessage?.message?.imageMessage?.caption || info.message?.documentWithCaptionMessage?.message?.documentMessage?.caption || info.message?.buttonsMessage?.imageMessage?.caption || ""

      const args = body.trim().split(/ +/).slice(1);

      var budy2 = body.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");

      if (isGroup && fs.existsSync(`./database/grupos/activation_gp/${from}.json`) && jsonGp[0].multiprefix) {
        var prefix = jsonGp[0]?.prefixos[jsonGp[0]?.prefixos?.indexOf(String(body)?.trim()?.charAt(0))] || jsonGp[0].prefixos[0]
      }

      if (isGroup && fs.existsSync(`./database/grupos/activation_gp/${from}.json`) && !jsonGp[0].multiprefix) {
        var prefix = setting.prefix;
      } else if (!isGroup) {
        var prefix = setting.prefix
      };

      var isCmd = body.trim().startsWith(prefix);

      const command = isCmd ? budy2.trim().slice(1).split(/ +/).shift().toLocaleLowerCase() : null;

      const reqcmd = JSON.parse(fs.readFileSync('./database/data/totalcmd.json'))

      const q_2 = budy2.trim().split(/ +/).slice(1).join(' ');

      const q = args.join(' ');


      var budy3 = budy.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");

      var PR_String = Procurar_String.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");

      const q_ofc = PR_String.trim().split(/ +/).slice(1).join(" ");

      //======================================\\

      try { var groupMetadata = isGroup ? await miwa.groupMetadata(from) : "" } catch { return }

      const groupName = isGroup ? groupMetadata.subject : '';

      const sender = isGroup ? info.key.participant.includes(':') ? info.key.participant.split(':')[0] + '@s.whatsapp.net' : info.key.participant : info.key.remoteJid;

      const messagesC = PR_String.slice(0).trim().split(/ +/).shift().toLowerCase();

      const arg = body.substring(body.indexOf(' ') + 1);

      const botNumber = await miwa.user.id.split(':')[0] + '@s.whatsapp.net';
      const argss = body.split(/ +/g);
      const testat = body;
      const ants = body;

      const groupDesc = isGroup ? groupMetadata.desc : ''

      const groupMembers = isGroup ? groupMetadata.participants : ''

      const isnit = nit.includes(sender)

      const issupre = supre.includes(sender)

      const ischyt = chyt.includes(sender)

      const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''

      const somembros = isGroup ? getMembros(groupMembers) : ''

      const path = require('path');
      //======================================\\

      const nmrdn = setting.numerodono.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net` || isnit

      const numerodono = [`${nmrdn}`, `${dono1}@s.whatsapp.net`, `${dono2}@s.whatsapp.net`, `${dono3}@s.whatsapp.net`, `${dono4}@s.whatsapp.net`, `${dono5}@s.whatsapp.net`, `${dono6}@s.whatsapp.net`]

      async function btncomfoto(jid, text = "a", title = "b", subtitle = "c", footer = "d", media, mediaType, quoted, options, buttons) {
        if (!jid) throw new Error("precisa do jid")
        if (typeof jid !== "string") throw new TypeError("jid tem que ser uma string")
        if (typeof text !== "string") throw new TypeError("text tem que ser uma string")
        if (typeof title !== "string") throw new TypeError("title tem que ser uma string")
        if (typeof footer !== "string") throw new TypeError("footer tem que ser uma string")
        if (media && typeof mediaType !== "string") throw new TypeError("mediaType  tem que ser uma string")
        if (quoted && typeof quoted !== "object") throw new TypeError("quoted tem que ser um objeto")
        if (options && typeof options !== "object") throw new TypeError("options tem que ser um objeto")
        if (mediaType && !["document", "image", "video"].includes(mediaType)) throw new TypeError("mediaType invalido, formatos suportados: image, video, document")
        quoted = { ...quoted }
        options = { ...options }
        const contextInfo = {
          mentionedJid: Array.isArray(options.mentions) ? options.mentions : [],
          ...options.contextInfo,
          stanzaId: quoted.key?.id,
          remoteJid: quoted.key?.remoteJid,
          participant: quoted.key?.participant,
          fromMe: quoted.key?.fromMe,
          quotedMessage: quoted.message
        }
        delete options.contextInfo
        const msg = baileys.generateWAMessageFromContent(jid, {
          interactiveMessage: baileys.proto.Message.InteractiveMessage.create({
            body: baileys.proto.Message.InteractiveMessage.Body.create({
              text
            }),
            footer: baileys.proto.Message.InteractiveMessage.Footer.create({
              text: footer
            }),
            header: baileys.proto.Message.InteractiveMessage.Header.create({
              title,
              subtitle,
              hasMediaAttachment: !!media,
              ...(media && mediaType ? await baileys.generateWAMessageContent({ [mediaType]: media }, { upload: miwa.waUploadToServer }) : {})
            }),
            nativeFlowMessage: baileys.proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: buttons
            }),
            contextInfo
          })
        }, {})
        await miwa.relayMessage(msg.key.remoteJid, msg.message, {
          messageId: msg.key.id
        })
        return msg
      }

      //=================> Funções de Grupo 🥋

      const dirGroup = `./database/grupos/activation_gp/${from}.json`

      const nescj = "./settings/nescessario.json"

      if (isGroup && !fs.existsSync(dirGroup)) {
        var data = [{
          name: groupName,
          groupId: from, x9: false,
          antiimg: false, antivideo: false,
          antiaudio: false, antisticker: false,
          antidoc: false, antictt: false,
          antiloc: false, antilinkgp: false,
          antilinkhard: false, antifake: false, antiporn: false,
          Odelete: false, antispam: false,
          antinotas: false, anticatalogo: false, visuUnica: false,
          registrarFIGUS: false, soadm: false,
          listanegra: [], advertir: [], prefixos: [`${setting.prefix}`],
          advertir2: [], legenda_estrangeiro: "0",
          legenda_documento: "0", legenda_video: "0",
          legenda_imagem: "0", multiprefix: false,
          forca_ofc: [{ acertos: 0, erros: 0, palavra: [], escreveu: [], palavra_ofc: 0, dica: 0, tema: 0 }], ausentes: [],
          antipalavrao: {
            active: false,
            palavras: []
          },
          limitec: {
            active: false,
            quantidade: null
          },
          wellcome: [{
            bemvindo1: false,
            legendabv: "Olá #numerodele#, seja bem vindo (a)",
            legendasaiu: 0
          },
          {
            bemvindo2: false,
            legendabv: "Olá #numerodele#, seja bem vindo (a)",
            legendasaiu: 0
          }],
          simi1: false, simi2: false,
          autosticker: false, autoresposta: false,
          jogos: false, level: false,
          bangp: false, nsfw: false,
          isAutodown: false
        }]
        fs.writeFileSync(dirGroup, JSON.stringify(data, null, 2) + '\n')
      }

      const dataGp = isGroup ? JSON.parse(fs.readFileSync(dirGroup)) : undefined

      var DFNMULTIP = `./database/func/prefixo/multip_${from}.json`

      function setGp(index) {
        fs.writeFileSync(dirGroup, JSON.stringify(index, null, 2) + '\n')
      }

      function setNes(index) {
        fs.writeFileSync(nescj, JSON.stringify(index, null, 2) + '\n')
      }

      //=====(ADMS/DONO/ETC..CONST)=======\\


      const adivinha = info.key.id.length > 21 ? 'Android' : info.key.id.substring(0, 2) == '3A' ? 'iPhone' : 'WhatsApp Web';
      const quoted = info.quoted ? info.quoted : info

      const isBot = info.key.fromMe ? true : false

      const SoDono = numerodono.includes(sender) || isBot || isnit || issupre || ischyt

      dfndofc = setting.numerodono + "@s.whatsapp.net"

      const DonoOficial = dfndofc.includes(sender)

      const isPremium = premium.includes(sender) || SoDono

      const isBotGroupAdmins = groupAdmins.includes(botNumber) || false

      const isGroupAdmins = groupAdmins.includes(sender) || false || DonoOficial

      const isAutoBaixar = isGroup ? dataGp[0].autodown : undefined

      const isBanned = ban.includes(sender)

      const isVisualizar = nescessario.visualizarmsg

      const isVerificado = nescessario.verificado

      const isAudioMenu = nescessario.menu_audio

      const isAntiPv2 = nescessario.banChats

      const isConsole = nescessario.consoleoff

      const isBotoff = nescessario.botoff

      const listanegraG = nescessario.listanegraG

      const isAntiPv = nescessario.antipv

      const isAnticall = nescessario.anticall

      const TOKEN_GPT = nescessario.TOKEN_GPT

      const isJoguin = isGroup ? joguinhodavelhajs.includes(sender) : false

      //============(FUNÇÕES)============\\


      const isAntiImg = isGroup ? dataGp[0].antiimg : undefined

      const isAntiVid = isGroup ? dataGp[0].antivideo : undefined

      const isAntiAudio = isGroup ? dataGp[0].antiaudio : undefined

      const isAntiSticker = isGroup ? dataGp[0].antisticker : undefined

      const Antidoc = isGroup ? dataGp[0].antidoc : undefined

      const isAntiCtt = isGroup ? dataGp[0].antictt : undefined

      const Antiloc = isGroup ? dataGp[0].antiloc : undefined

      const isAntilinkgp = isGroup ? dataGp[0].antilinkgp : undefined

      const isAntiLinkHard = isGroup ? dataGp[0].antilinkhard : undefined

      const isAntiPorn = isGroup ? dataGp[0].antiporn : undefined

      const isAntifake = isGroup ? dataGp[0].antifake : undefined

      const IS_DELETE = nescessario.Odelete

      const So_Adm = isGroup ? dataGp[0].soadm : undefined

      const isX9VisuUnica = isGroup ? dataGp[0].visuUnica : undefined

      const ADVT = isGroup ? dataGp[0].advertir : undefined

      const ADVT2 = isGroup ? dataGp[0].advertir2 : undefined

      const isx9 = isGroup ? dataGp[0].x9 : undefined

      const isMultiP = isGroup ? dataGp[0].multiprefix : undefined

      const isAntiNotas = isGroup ? dataGp[0].antinotas : undefined

      const isAnticatalogo = isGroup ? dataGp[0].anticatalogo : undefined

      const isWelkom = isGroup ? dataGp[0].wellcome[0].bemvindo1 : undefined

      const isWelkom2 = isGroup ? dataGp[0].wellcome[1].bemvindo2 : undefined

      const isTotext = isGroup ? dataGp[0].autototext : undefined

      const isSimi = isGroup ? dataGp[0].simi1 : undefined

      const isSimi2 = isGroup ? dataGp[0].simi2 : undefined

      const isAutofigu = isGroup ? dataGp[0].autosticker : undefined

      const isAutorepo = isGroup ? dataGp[0].autoresposta : undefined

      const isModobn = isGroup ? dataGp[0].jogos : undefined

      const isLevelingOn = isGroup ? dataGp[0].level : undefined

      const isBanchat = isGroup ? dataGp[0].bangp : undefined

      const isNsfw = isGroup ? dataGp[0].nsfw : undefined

      const isPalavrao = isGroup ? dataGp[0].antipalavrao.active : undefined

      const isPalavras = isGroup ? dataGp[0].antipalavrao.palavras : undefined

      const isAntiFlood = isGroup ? dataGp[0].limitec.active : undefined

      //const isAntiSpam = isGroup ? dataGp[0].antispam : undefined

      const isLimitec = isGroup ? dataGp[0].limitec.quantidade : undefined
      //================(SALDO E ETC.)==================\\
      
        
      

   
      //================(CONST KEYS)====================\\
      //=======================================\\

      const vcard = "BEGIN:VCARD\n"
        + "VERSION:3.0\n"
        + "FN:Yuki\nitem1.TEL;waid=555194709091:+55 51 94709091\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET: nescaukkj@gmail.com\nitem2.X-ABLabel:Email\nitem4.ADR:;;;;;Brasil\nitem4.X-ABLabel:Regiao\n"
        + "END:VCARD" // Fim do ctt




      //==MUTE==\\
      const muteall = JSON.parse(fs.readFileSync('./arquivos/FilesJson/grupos/muteall.json'))
      const isMuteAll = (muteall.indexOf('Ativado') >= 0) ? true : false
      var banChatss = nescessario.banChatss
      //===========================

      //==========(VERIFICADO)===============\\

      if (isVerificado) {
        var selo = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg", "caption": `${NomeDoBot}\n 𝒀𝒖𝒌𝒊 𝑴𝒐𝒅𝒔 𝑫𝒐𝒎𝒊𝒏𝒂` } } }

      } else {
        var selo = info
      }

      //()=> selos ay john

      //selo localização
      const seloloc = { "key": { "fromMe": false, "participant": "0@s.whatsapp.net", "remoteJid": 'status@broadcast' }, message: { liveLocationMessage: { degreesLatitude: 173.282, degreesLongitude: -19.378, sequenceNumber: "1657237469254001", thumbnail: null, caption: `Bem vindo: ${pushname}` } } }

      //selo contato
      const selocontato = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ... {} }, message: { "contactMessage": { "displayName": `${pushname}`, "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, "sourceUrl": `https://chat.whatsapp.com/EcbQgbQceFQH0fzKUnE0mH` } } }

      //sabios
      const selogrupo = { key: { fromMe: false, participant: "0@s.whatsapp.net", ...{} }, message: { "groupInviteMessage": { "text": "https://chat.whatsapp.com/EcbQgbQceFQH0fzKUnE0mH", "sourceUrl": "https://chat.whatsapp.com/EcbQgbQceFQH0fzKUnE0mH", "matchedText": "https://chat.whatsapp.com/EcbQgbQceFQH0fzKUnE0mH", "description": "Convite para grupo do WhatsApp", "title": "GILIARDIX", "previewType": "NONE", "jpegThumbnail": null } } }

      //selo vizualização única
      const selovizu = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "viewOnceMessage": { "jpegThumbnail": null } } }

      //selo documento
      const selodoc = { key: { fromMe: false, participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: `➥𝑩𝒆𝒎 𝒗𝒊𝒏𝒅𝒐 𝒂𝒐 𝑺𝒚𝒔𝒕𝒆𝒎 𝑴𝒂𝒊 𝑩𝒐𝒕 ${pushname}\n 𝒀𝒖𝒌𝒊 𝑴𝒐𝒅𝒔 𝑫𝒐𝒎𝒊𝒏𝒂`, jpegThumbnail: null } } };

      //selo grupo 
      const selogp = { "key": { "fromMe": false, "participant": "0@s.whatsapp.net", "remoteJid": "0@s.whatsapp.net" }, "message": { "groupInviteMessage": { "groupJid": "6282127487538-1625305606@g.us", "title": `Grupo da Mai oficial `, "body": `Yuki Mods `, "mediaType": 1, "renderLargerThumbnail": false, "showAdAttribution": true, "thumbnail": null, "body": `Yuki Mods`, "sourceUrl": `https://chat.whatsapp.com/HN9fP1VRh31HUCzARrj6VB` } } }

      //async function
      async function replyWithReaction(text, options = {}, quotedThis = info) {
        await miwa.sendMessage(from, options)
        await miwa.sendMessage(from, { text: text }, { quoted: quotedThis })
          .catch(async (error) => {
            await miwa.sendMessage(from, { text: 'Ocorreu um erro ao encaminhar a mensagem pré-definida na função.' }, { quoted: selo });
          });
      }
      //selo grupo 3
      const selowagp = {
        "key": { "fromMe": false, "participant": "0@s.whatsapp.net" }, "message": {
          "imageMessage": {
            "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-9e3350da-fa67-4c21-bd79-5deb3540b6f7?ccb=9-4&oh=01_AdQhhSRRTZNium5zoC5DdQIsGVS9Thx2iAnrtTzFsrR9ow&oe=64B9C015&mms3=true",
            "mimetype": "image/jpeg",
            "caption": "Yuki Mods",
            "sourceUrl": "https://chat.whatsapp.com/EcbQgbQceFQH0fzKUnE0mH",
            "fileLength": "999999999999999999",
            "jpegThumbnail": null
          }
        }
      }

      //selo grupo atualizado wandinha


      //selo carrinho       
      const selocar = { key: { fromMe: false, "participant": "0@s.whatsapp.net", "remoteJid": "120363022697760691@g.us" }, "message": { orderMessage: { itemCount: 999, status: 200, jpegThumbnail: fs.readFileSync('./settings/lib/logo.jpg'), surface: 200, message: `Yuki Mods\nBem vindo: ${pushname}`, orderTitle: 'up', sellerJid: '0@s.whatsapp.net' } }, contextInfo: { "forwardingScore": 999, "isForwarded": true }, sendEphemeral: true }

      //selo vídeo
      const selovideo = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289643739077-1613049930@g.us" } : {}) }, message: { "videoMessage": { "title": `bem vindo: ${pushname}`, "h": `Usuario: ${pushname}`, "duration": "28382", "caption": `Bem vindo: ${pushname}`, "jpegThumbnail": null } } };

      //============
      const getBuffer = async (url, opcoes) => {
        try {
          opcoes ? opcoes : {}
          const post = await axios({
            method: "get",
            url,
            headers: {
              'user-agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari/537.36',
              'DNT': 1,
              'Upgrade-Insecure-Request': 1
            },
            ...opcoes,
            responseType: 'arraybuffer'
          })
          return post.data
        } catch (erro) {
          console.log(`Erro identificado: ${erro}`)
        }
      }
      // FUNÇÕES DE MARCAÇÕES ESSENCIAL \\

      const menc_prt = info.message?.extendedTextMessage?.contextInfo?.participant

      const menc_jid = args?.join(" ").replace("@", "") + "@s.whatsapp.net"

      const menc_jid2 = info.message?.extendedTextMessage?.contextInfo?.mentionedJid

      const sender_ou_n = q.includes("@") ? menc_jid : sender

      const mrc_ou_numero = q.length > 6 && !q.includes("@") ? q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net` : menc_prt
      const menc_os2 = q.includes("@") ? menc_jid : menc_prt

      const marc_tds = q.includes("@") ? menc_jid : q.length > 6 && !q.includes("@") ? q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net` : menc_prt

      const menc_prt_nmr = q.length > 12 ? q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net` : menc_prt

      ////////////////////////////////////////////


      var isUrl = (url) => {
        if (linkfy.find(url)[0]) return true
        return false
      }

      if (info.key.fromMe) return

      const reply = (texto) => {
        miwa.sendMessage(from, { text: texto }, { quoted: info }).catch(e => {
          return reply("Erro..");
        })
      }

      const msgSemQuoted = (oq_que_deseja) => {
        miwa.sendMessage(from, { text: oq_que_deseja }).catch(e => {
          return reply("Erro..");
        })
      }
      //
      const time2 = moment().tz('America/Sao_Paulo').format('HH:mm:ss')
      if (time2 > "00:00:00" && time2 < "05:00:00") {
        var tempo = 'Boa Madrugada'
      } if (time2 > "05:00:00" && time2 < "12:00:00") {
        var tempo = 'Bom Dia'
      } if (time2 > "12:00:00" && time2 < "18:00:00") {
        var tempo = 'Boa Tarde'
      } if (time2 > "18:00:00") {
        var tempo = 'Boa Noite'
      }


      const yts2 = require('yt-search');


      async function sendUrlText(id, textCaption, title, desc, imageUrl, linkAcess, quotedThis) {
        miwa.sendMessage(id, { text: textCaption, contextInfo: { externalAdReply: { title: title, body: desc, thumbnail: await getBuffer(imageUrl), mediaType: 1, sourceUrl: linkAcess } } }, { quoted: quotedThis })
      }

      const sendSticker = (from, filename, info) => {
        miwa.sendMessage(from, { sticker: { url: fileName } }, { quoted: info })
      }

      const sendImage = (ytb) => {
        miwa.sendMessage(from, { image: { url: ytb } }, { quoted: info })
      }


      const sendMess = (hehe, ytb) => {
        miwa.sendMessage(hehe, { text: ytb })
      }

      const mentions = (teks, memberr, id) => {
        (id == null || id == undefined || id == false) ? miwa.sendMessage(from, { text: teks.trim(), mentions: memberr }) : miwa.sendMessage(from, { text: teks.trim(), mentions: memberr })
      }

      const mention = (teks = '', ms = info) => {
        memberr = []
        vy = teks.includes('\n') ? teks.split('\n') : [teks]
        for (vz of vy) {
          for (zn of vz.split(' ')) {
            if (zn.includes('@')) memberr.push(parseInt(zn.split('@')[1]) + '@s.whatsapp.net')
          }
        }
        miwa.sendMessage(from, { text: teks.trim(), mentions: memberr }, { quoted: ms })
      }

      const mencionarIMG = (teks = '', Url, ms) => {
        memberr = []
        vy = teks.includes('\n') ? teks.split('\n') : [teks]
        for (vz of vy) {
          for (zn of vz.split(' ')) {
            if (zn.includes('@')) memberr.push(parseInt(zn.split('@')[1]) + '@s.whatsapp.net')
          }
        }
        miwa.sendMessage(from, { image: { url: Url }, caption: teks.trim(), mentions: memberr }, { quoted: ms })
      }

      const reagir = async (idgp, emj) => {
        var reactionMessage = {
          react: {
            text: emj,
            key: info.key
          }
        }
        miwa.sendMessage(idgp, reactionMessage)
      }

      const verificarN = async (sla) => {
        const [result] = await miwa.onWhatsApp(sla)
        if (result == undefined) {
          reply("Este usuário não é existente no WhatsApp")
        } else {
          reply(`${sla} Número inserido é existente no WhatsApp.\n\ncom o id: ${result.jid}`)
        }
      }

      var sendlistA = async (id, txt1, txt2, title1, btext, but, vr) => {
        var sections = but
        var listMessage = {
          text: txt1,
          footer: txt2,
          title: title1,
          buttonText: btext,
          sections
        }
        miwa.sendMessage(id, listMessage, { quoted: vr })
      }

      const EnvLista = async (IDG, TXT1, TXT2, TTL, TTB, TTB2, ENVLRW) => {
        listMessage = {
          text: TXT1, footer: TXT2,
          title: TTL, buttonText: TTB,
          sections: [{
            title: TTB2, rows: ENVLRW
          }]
        };
        miwa.sendMessage(IDG, listMessage).catch(e => {
          console.log(e);
        });
      };

      if (isGroup && isBotGroupAdmins && !isGroupAdmins && !SoDono && !info.key.fromMe) {
        if (menc_jid2?.length >= groupMembers.length - 1) {
          miwa.sendMessage(from, { text: "*O participante foi removido do grupo* - Motivo: Membro comum com mensagem de marcação de todos do grupo, por conta disso irei remover do grupo, qualquer coisa entre em contato com um administrador..." })
          if (IS_DELETE) {
            setTimeout(() => {
              miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
            }, 500)
          }
          miwa.groupParticipantsUpdate(from, [sender], "remove")
        }
      }

      const enviarfigu = async (figu, tag) => {
        miwa.sendMessage(from, { sticker: { url: figu } }, { quoted: tag })
      }

      if (isAutofigu && isGroup) {
        async function autofiguf() {
          setTimeout(async () => {

            if (budy.includes(`${prefix}sticker`) || budy.includes(`${prefix}s`) || budy.includes(`${prefix}stk`) || budy.includes(`${prefix}st`) || budy.includes(`${prefix}fsticker`) || budy.includes(`${prefix}f`) || budy.includes(`${prefix}fstiker`)) return

            if (type == 'imageMessage') {
              var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}`
              var author2 = `↧ ☁️ ⃟ɢʀᴜᴘᴏ\n↳ ${groupName}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
              owgi = await getFileBuffer(info.message.imageMessage, 'image')
              let encmediaa = await sendImageAsSticker2(miwa, from, owgi, info, { packname: pack, author: author2 })
              DLT_FL(encmediaa)
            }

            if (type == 'videoMessage') {
              if ((isMedia && info.message.videoMessage.seconds < 10)) {
                var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}`
                var author2 = `↧ ☁️ ⃟ɢʀᴜᴘᴏ\n↳ ${groupName}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
                owgi = await getFileBuffer(info.message.videoMessage, 'video')
                let encmedia = await sendVideoAsSticker2(miwa, from, owgi, info, { packname: pack, author: author2 })
                DLT_FL(encmedia)
              }
            }
          }, 1000)
        }
        autofiguf().catch(e => {
          console.log(e)
        })
      }

      var nmrdnofc1 = setting.numerodono.replace(new RegExp("[()+-/ +/]", "gi"), "")

      if (isGroup && fs.existsSync(`./database/func/afk/afk-@${nmrdnofc1}.json`)) {
        if (budy.indexOf(`@${nmrdnofc1}`) >= 0) {
          const tabelin = JSON.parse(fs.readFileSync(`./database/func/afk/afk-@${nmrdnofc1}.json`));
          txt = `Olá, o meu proprietário "${NickDono}" se encontra ausente no momento.\n↺Desde do Horário: ${tabelin.Ausente_Desde}\n\n☇ Mensagem de Ausência: ${tabelin.Motivo_Da_Ausência}`
          miwa.sendMessage(from, { text: txt }, { quoted: info })
        }
      }

      if (isGroup && dataGp[0].ausentes?.length > 0 && menc_jid2?.length > 0 && JSON.stringify(dataGp[0].ausentes).includes(menc_jid2)) {
        blue = []
        for (i of menc_jid2) {
          if (groupAdmins.indexOf(String(i)) != -1) blue.push(groupAdmins.indexOf(String(i)))
        }
        if (blue.length == 0) return
        big = []
        for (i of blue) {
          big.push(groupAdmins[i])
        }
        blr = []
        for (i = 0; i < big.length; i++) {
          blr.push(dataGp[0].ausentes[dataGp[0].ausentes.map(i => i.id).indexOf(big[i])])
        }
        for (i of blr) {
          var blak = i
        }
        mention(`*Registro de Ausência* - O adminstrador "@${blak.id.split("@")[0]}" se encontra *ausente* nesse momento.\n\n☇ Mensagem: ${blak.msg}`)
      }

      if (isBotGroupAdmins && isGroupAdmins && body === "apaga") {
        if (!menc_prt) return
        await miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.message.extendedTextMessage.contextInfo.stanzaId, participant: menc_prt } })
      }

      if (SoDono && budy.includes("reiniciar-mai") || info.key.fromMe && budy.includes("reiniciar-mai")) {
        fs.writeFileSync("./cnt-upd.json", JSON.stringify([], null, 2))
        setTimeout(() => {
          file = require.resolve("./connect.js")
          delete require.cache[file]
          require(file)
        }, 500)
        setTimeout(() => {
          DLT_FL("./cnt-upd.json")
        }, 1500)
      }




      //========================================\\

      //BAN GRUPO & BOT OFF
      if (isGroup && isCmd && isBanchat && !SoDono) return

      if (isGroup && isCmd && So_Adm && !SoDono && !isGroupAdmins) return

      if (isBotoff && !SoDono) return

      //=======================================\\

      const sendStickerFromUrl = async (to, url) => {
        try {
          var names = Date.now() / 10000;
          var download = function (uri, filename, callback) {
            request.head(uri, function (err, res, body) {
              request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
            });
          };
          download(url, './sticker' + names + '.png', async function () {
            console.log('Enviando sticker..');
            let filess = './sticker' + names + '.png'
            let asw = './sticker' + names + '.webp'
            exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${asw}`, (err) => {
              let media = fs.readFileSync(asw)
              miwa.sendMessage(to, { sticker: media }, { sendEphemeral: true, contextInfo: { forwardingScore: 50, isForwarded: true }, quoted: info }).catch(e => {
                return reply("Erro..")
              })
              DLT_FL(filess)
              DLT_FL(asw)
            });
          });
        } catch {
          return reply("Erro.. FNC")
        }
      }

      //=========(isQuoted/consts)=============\\
      const isImage = type == 'imageMessage'
      const isVideo = type == 'videoMessage'
      const isVisuU2 = type == 'viewOnceMessageV2'
      const isAudio = type == 'audioMessage'
      const isSticker = type == 'stickerMessage'
      const isContact = type == 'contactMessage'
      const isLocation = type == 'locationMessage'
      const isProduct = type == 'productMessage'
      const isMedia = (type === 'imageMessage' || type === 'videoMessage' || type === 'audioMessage' || type == "viewOnceMessage" || type == "viewOnceMessageV2")
      typeMessage = body.substr(0, 50).replace(/\n/g, '')
      if (isImage) typeMessage = "Image"
      else if (isVideo) typeMessage = "Video"
      else if (isAudio) typeMessage = "Audio"
      else if (isSticker) typeMessage = "Sticker"
      else if (isContact) typeMessage = "Contact"
      else if (isLocation) typeMessage = "Location"
      else if (isProduct) typeMessage = "Product"

      const isQuotedMsg = type === 'extendedTextMessage' && content.includes('conversation')

      const isQuotedMsg2 = type === 'extendedTextMessage' && content.includes('text')

      const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')

      const isQuotedVisuU = type === 'extendedTextMessage' && content.includes('viewOnceMessage')

      const isQuotedVisuU2 = type === 'extendedTextMessage' && content.includes('viewOnceMessageV2')

      const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')

      const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')

      const isQuotedDocW = type === 'extendedTextMessage' && content.includes('documentWithCaptionMessage')

      const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')

      const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')

      const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')

      const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')

      const isQuotedProduct = type === 'extendedTextMessage' && content.includes('productMessage')

      //////BLOCK CMD///////
      //(CREDITOS AO KAUAN GAY)\\
      if (isGroup) {
        const checar = getComandos(from)
        if (checar === undefined) addComandosId(from)
      }
      if (isGroup && isCmd && !SoDono && !isnit && getComandoBlock(from).includes(command)) return reply('comando blockeado')

      ////FIMMMMMMMMM/////

      const { color, bgcolor } = require('./arquivos/js/color')
      const tipoMensagem = type == 'audioMessage' ? 'Áudio' : type == 'stickerMessage' ? 'Figurinha' : type == 'imageMessage' ? 'Imagem' : type == 'videoMessage' ? 'Vídeo' : type == 'documentMessage' ? 'Documento' : type == 'contactMessage' ? 'Contato' : type == 'locationMessage' ? 'Localização' ? 'Enquete' : 'pollCreationMessage' : 'Mensagem'
      const date = moment.tz('America/Sao_Paulo').format('DD/MM/YY');
      const time = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
      const hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
      const dataa = moment.tz('America/Sao_Paulo').format('DD/MM/YY');
      consoleEmoji = "• "

      // { COMANDOS NO PV }
      if (!isGroup && isCmd) console.log(
        color(` ❯❯ 𝐌𝐀𝐈 𝐁𝐎𝐓 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 ❮❮`, 'green'), '\n\n',
        color('• PV:', 'green'), color(groupName, 'white'), '\n',
        color('• NOME:', 'green'), color(pushname, 'white'), '\n',
        color('• COMANDO', 'green'), color(command, 'white'), '\n',
        color('• HORA :', 'green'), color(hora, 'white'), '\n',
        color('• DATA :', 'green'), color(dataa, 'white'), '\n')

      // { MENSAGENS NO PV}
      if (!isCmd && !isGroup) console.log(
        color(` ❯❯ 𝐌𝐀𝐈 𝐁𝐎𝐓 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 ❮❮`, 'green'), '\n',
        color('• PV:', 'green'), color(groupName, 'white'), '\n',
        color('• NOME:', 'green'), color(pushname, 'white'), '\n',
        color('• MENSAGEM', 'green'), color(budy, 'white'), '\n',
        color('• TIPO', 'green'), color(tipoMensagem, 'white'), '\n',
        color('• HORA :', 'green'), color(hora, 'white'), '\n',
        color('• DATA :', 'green'), color(dataa, 'white'), '\n')

      // { COMANDOS EM GRUPO}
      if (isCmd && isGroup) console.log(
        color(` ❯❯ 𝐌𝐀𝐈 𝐁𝐎𝐓 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 ❮❮`, 'green'), '\n',
        color('• GRUPO:', 'green'), color(groupName, 'white'), '\n',
        color('• NOME:', 'green'), color(pushname, 'white'), '\n',
        color('• COMANDO', 'green'), color(command, 'white'), '\n',
        color('• HORA :', 'green'), color(hora, 'white'), '\n',
        color('• DATA :', 'green'), color(dataa, 'white'), '\n')

      // { MENSAGENS EM GRUPOS }
      if (!isCmd && isGroup) console.log(
        color(` ❯❯ 𝐌𝐀𝐈 𝐁𝐎𝐓 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 ❮❮`, 'green'), '\n',
        color('• GRUPO:', 'green'), color(groupName, 'white'), '\n',
        color('• NOME:', 'green'), color(pushname, 'white'), '\n',
        color('• MENSAGEM', 'green'), color(budy, 'white'), '\n',
        color('• TIPO', 'green'), color(tipoMensagem, 'white'), '\n',
        color('• HORA :', 'green'), color(hora, 'white'), '\n',
        color('• DATA :', 'green'), color(dataa, 'white'), '\n')

      // ========= || PlayList Configs || ======== \\

      const loadUserPlaylist = (userId) => {
        try {
          const playlistsFolderPath = './funções_rpg/playlists';
          if (!fs.existsSync(playlistsFolderPath)) {
            fs.mkdirSync(playlistsFolderPath, { recursive: true });
          }
          const userPlaylistPath = `${playlistsFolderPath}/${userId}.json`;
          if (!fs.existsSync(userPlaylistPath)) {
            fs.writeFileSync(userPlaylistPath, '[]');
          }
          return JSON.parse(fs.readFileSync(userPlaylistPath));
        } catch (err) {
          console.error(err);
          return [];
        }
      };

      // Função para salvar a playlist de um usuário no arquivo JSON
      const saveUserPlaylist = (userId, playlist) => {
        const userPlaylistPath = `./funções_rpg/playlists/${userId}.json`;
        fs.writeFileSync(userPlaylistPath, JSON.stringify(playlist, null, 2));//ryuu
      };

      // Adicionar uma música à playlist de um usuário
      const addSongToPlaylist = (userId, songName) => {
        const playlist = loadUserPlaylist(userId);
        if (!playlist.some(song => song.name === songName)) {//Akiyamax
          playlist.push({ name: songName });
          saveUserPlaylist(userId, playlist);
          return `Adicionado ${songName} à sua playlist!`;
        } else {
          return `${songName} já está na sua playlist.`;
        }
      };

      // Remover uma música da playlist de um usuário
      const removeSongFromPlaylist = (userId, songName) => {//ryuu franky
        const playlist = loadUserPlaylist(userId);
        const index = playlist.findIndex(song => song.name === songName);
        if (index !== -1) {
          playlist.splice(index, 1);
          saveUserPlaylist(userId, playlist);
          return `Removido ${songName} da sua playlist!`;
        } else {
          return 'Música não encontrada na sua playlist.';
        }
      };

      // Limpar a playlist de um usuário
      const clearUserPlaylist = (userId) => {
        saveUserPlaylist(userId, []);
        return 'Sua playlist foi limpa!';//ryuu 
      };

      // Reproduzir a playlist de um usuário
      const playUserPlaylist = (userId) => {
        const playlist = loadUserPlaylist(userId);
        if (playlist.length === 0) {
          return 'Sua playlist está vazia.';
        }
        let playlistText = '🎵 Sua Playlist 🎵\n';
        playlist.forEach((song, index) => {
          playlistText += `${index + 1}. ${song.name}\n`;//ryuu
        });
        return playlistText;
      };

      // Compartilhar a playlist de um usuário com outro
      const shareUserPlaylist = (fromUserId, toUserId) => {
        const fromUserPlaylist = loadUserPlaylist(fromUserId);
        const toUserPlaylist = loadUserPlaylist(toUserId);

        const mergedPlaylist = [...toUserPlaylist, ...fromUserPlaylist.filter(song => !toUserPlaylist.some(s => s.name === song.name))];
        saveUserPlaylist(toUserId, mergedPlaylist);

        return `Playlist compartilhada com sucesso com o usuário ${toUserId}!`;
      };

      const fotoryuu = async (jid, mediaUrl, caption, mentions = [], quoted) => {
        if (!jid) throw new Error("Precisa do JID");
        if (typeof jid !== "string") throw new TypeError("JID tem que ser uma string");
        if (typeof mediaUrl !== "string") throw new TypeError("mediaUrl tem que ser uma string");
        if (typeof caption !== "string") throw new TypeError("caption tem que ser uma string");

        const message = {
          image: { url: mediaUrl },
          caption: caption,
          mentions: mentions,
          quoted: quoted ? { ...quoted } : undefined
        };

        await miwa.sendMessage(jid, message);
      };

      // ========= || Jogo da Velha || ======== \\
      async function joguinhodavelha() {
        if (joguinhodavelhajs2.includes(from) || joguinhodavelhajs.includes(sender)) {
          const cmde = budy.toLowerCase().split(" ")[0] || "";
          let arrNum = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
          if (fs.existsSync(`./arquivos/tictactoe/db/${from}.json`)) {
            const boardnow = setGame(`${from}`);
            if (budy == "Cex") return reply("why");
            if (
              budy.toLowerCase() == "s" ||
              budy.toLowerCase() == "sim" ||
              budy.toLowerCase() == "ok"
            ) {
              if (boardnow.O == sender.replace("@s.whatsapp.net", "")) {
                if (boardnow.status)
                  return reply(`O jogo já começou antes!`);
                const matrix = boardnow._matrix;
                boardnow.status = true;
                fs.writeFileSync(`./arquivos/tictactoe/db/${from}.json`,
                  JSON.stringify(boardnow, null, 2)
                );
                const chatAccept = `*🎮Ꮐ̸Ꭺ̸Ꮇ̸Ꭼ̸ Ꭰ̸Ꭺ̸ Ꮩ̸Ꭼ̸Ꮮ̸Ꮋ̸Ꭺ̸🕹️*
                    
❌ : @${boardnow.X}
⭕ : @${boardnow.O}
               
Sua vez... : @${boardnow.turn == "X" ? boardnow.X : boardnow.O}

${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
`;
                mention(chatAccept);
              }
            } else if (
              budy.toLowerCase() == "n" ||
              budy.toLowerCase() == "não" ||
              budy.toLowerCase() == "no"
            ) {
              if (boardnow.O == sender.replace("@s.whatsapp.net", "")) {
                if (boardnow.status)
                  return reply(`O jogo já começou!`);
                DLT_FL(`./arquivos/tictactoe/db/${from}.json`);
                mention(`@${boardnow.X} *_Infelizmente seu oponente não aceitou o desafio ❌😕_*`)
                joguinhodavelhajs.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
                joguinhodavelhajs2.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
              }
            }
          }

          if (arrNum.includes(cmde)) {
            const boardnow = setGame(`${from}`);
            if (!boardnow.status) return reply(`Parece que seu oponente não aceitou o desafio ainda...`)
            if (
              (boardnow.turn == "X" ? boardnow.X : boardnow.O) !=

              sender.replace("@s.whatsapp.net", "")
            )
              return;
            const moving = validmove(Number(budy), `${from}`);
            const matrix = moving._matrix;
            if (moving.isWin) {
              if (moving.winner == "SERI") {
                const chatEqual = `*🎮Ꮐ̸Ꭺ̸Ꮇ̸Ꭼ̸ Ꭰ̸Ꭺ̸ Ꮩ̸Ꭼ̸Ꮮ̸Ꮋ̸Ꭺ̸🕹️*
          
Jogo da velha termina empatado 😐
`;
                reply(chatEqual);
                DLT_FL(`./arquivos/tictactoe/db/${from}.json`);
                joguinhodavelhajs.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
                joguinhodavelhajs2.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
                return;
              }
              const abt = Math.ceil(Math.random() + 4000)
              const winnerJID = moving.winner == "O" ? moving.O : moving.X;
              const looseJID = moving.winner == "O" ? moving.X : moving.O;
              const limWin = Math.floor(Math.random() * 1) + 10;
              const limLoose = Math.floor(Math.random() * 1) + 5;
              const chatWon = `*🎮Ꮐ̸Ꭺ̸Ꮇ̸Ꭼ̸ Ꭰ̸Ꭺ̸ Ꮩ̸Ꭼ̸Ꮮ̸Ꮋ̸Ꭺ̸🕹️*

O jogo da velha foi vencido pelo usuário: @${winnerJID}..`;

              await miwa.sendMessage(from, { text: chatWon }, {
                quoted: info,
                mentions: [
                  moving.winner == "O" ?
                    moving.O + "@s.whatsapp.net" :
                    moving.X + "@s.whatsapp.net"]
              });
              setTimeout(() => {
                if (fs.existsSync("./arquivos/tictactoe/db/" + from + ".json")) {
                  DLT_FL("./arquivos/tictactoe/db/" + from + ".json");
                  reply(`*🕹️JOGO DA VELHA RESETADO...🕹️*`);
                } else {
                  console.log(colors.red(time, "red"), colors.magenta("[ EXPIRADO ]"), colors.red('Jogo da velha espirado..'));
                }
                joguinhodavelhajs.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
                joguinhodavelhajs2.splice([])
                fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
              }, 300000) //5 minutos
              reply(`Parabéns @${winnerJID} você ganhou o jogo da velha... 🥳\nParabéns aos ambos jogadores, vocês foram bem, perder não é o fim, perder faz parte da vida.. Não desista!`)
              DLT_FL(`./arquivos/tictactoe/db/${from}.json`);
              joguinhodavelhajs.splice([])
              fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
              joguinhodavelhajs2.splice([])
              fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
            } else {
              const chatMove = `*🎮Ꮐ̸Ꭺ̸Ꮇ̸Ꭼ̸ Ꭰ̸Ꭺ̸ Ꮩ̸Ꭼ̸Ꮮ̸Ꮋ̸Ꭺ̸🕹️*
          
❌ : @${moving.X}
⭕ : @${moving.O}

Sua vez : @${moving.turn == "X" ? moving.X : moving.O}

${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
`;
              mention(chatMove);
            }
          }
        }
      }

      // ==========[ ANAGRAMA ]==========\\

      if (isGroup && fs.existsSync(`./arquivos/games/anagrama/${from}.json`)) {
        let dataAnagrama = JSON.parse(fs.readFileSync(`./arquivos/games/anagrama/${from}.json`))
        if (budy.slice(0, 4).toUpperCase() == dataAnagrama.original.slice(0, 4).toUpperCase() && budy.toUpperCase() != dataAnagrama.original) return reply('está perto')
        if (budy.toUpperCase() == dataAnagrama.original) {
          await miwa.sendMessage(from, { text: `*Parabéns ${pushname}. Você acertou! 🥳🥳*\n*Palavra original:* ${dataAnagrama.original}\n*Iniciando o proximo jogo em 5 segundos...*` }, { "mentionedJid": [sender] }), fs.unlinkSync(`./arquivos/games/anagrama/${from}.json`)
          setTimeout(async () => {
            fs.writeFileSync(`./arquivos/games/anagrama/${from}.json`, `${JSON.stringify(palavrasANA[Math.floor(Math.random() * palavrasANA.length)])}`)
            let dataAnagrama2 = JSON.parse(fs.readFileSync(`./arquivos/games/anagrama/${from}.json`))
            await miwa.sendMessage(from, {
              text: `╭━━ ⪩ 「 Descubra a palavra 」
▢ ⌁ ⚠︎ Anagrama: ${dataAnagrama2.embaralhada}
▢ ⌁ ⚠︎ Dica: ${dataAnagrama2.dica}
╰━━━ ⪨ 「 ${NomeDoBot} 」
`})
          }, 5000)
        }
      }

      if (isGroup && fs.existsSync(`./arquivos/games/quiz-animais/${from}.json`)) {
        let dataAnagramaa = JSON.parse(fs.readFileSync(`./arquivos/games/quiz-animais/${from}.json`))
        if (budy.slice(0, 4).toUpperCase() == dataAnagramaa.original.slice(0, 4).toUpperCase() && budy.toUpperCase() != dataAnagramaa.original) return reply('está perto')
        if (budy.toUpperCase() == dataAnagramaa.original) {
          await miwa.sendMessage(from, { text: `*Parabéns ${pushname}. Você acertou! 🥳🥳*\n*Nome do Animal:* ${dataAnagramaa.original}\n*Iniciando o proximo jogo em 5 segundos...*` }, { "mentionedJid": [sender] }), fs.unlinkSync(`./arquivos/games/quiz-animais/${from}.json`)
          setTimeout(async () => {
            fs.writeFileSync(`./arquivos/games/quiz-animais/${from}.json`, `${JSON.stringify(quizanimais[Math.floor(Math.random() * quizanimais.length)])}`)
            let dataAnagrama2 = JSON.parse(fs.readFileSync(`./arquivos/games/quiz-animais/${from}.json`))
            imagemtexto = `╭━━ ⪩ 「 Descubra o animal 」
▢ ⌁ ⚠︎ Jogador: ${pushname}
╰━━━ ⪨ 「 ${NomeDoBot} 」`
            wew = await getBuffer(`${dataAnagrama2.foto}`)
            await miwa.sendMessage(from, { image: wew, caption: imagemtexto, thumbnail: wew }, { quoted: selo })
          }, 5000)
        }
      }

      //=================================\\

      function contar(frase, letraProcurada) {
        var total = 0;[...frase].forEach(letra => {
          if (letra === letraProcurada) total++;
        });
        return total;
      }

      joguinhodavelha()

      if (isAntilinkgp && isGroup && isBotGroupAdmins && !isGroupAdmins) {
        if (Procurar_String.includes("chat.whatsapp.com/")) {
          if (isBot) return
          link_dgp = await miwa.groupInviteCode(from)
          if (Procurar_String.match(link_dgp)) return reply('Link do nosso grupo, não irei remover.. ')
          if (IS_DELETE) {
            setTimeout(() => {
              miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
            }, 500)
          }
          if (!JSON.stringify(groupMembers).includes(sender)) return
          miwa.groupParticipantsUpdate(from, [sender], 'remove')
        }
      }

      const groupIdscount = [];
      for (let obj of countMessage) {
        groupIdscount.push(obj.groupId);
      }

      // BOTÕES
      var sendBtext = async (id, text1, desc1, but = [], vr) => {
        buttonMessagse = {
          text: text1,
          footer: desc1,
          buttons: but,
          headerType: 1
        }
        await miwa.sendMessage(id, buttonMessagse, { quoted: vr })
      }

      // MUTAR USUÁRIO 
      const GroupsMutedActived = []
      for (let obj of muted) {
        GroupsMutedActived.push(obj.jid)
      }
      const isMuted = (isGroup && GroupsMutedActived.indexOf(from) >= 0) ? true : false
      const NumbersMuted = isMuted ? muted[GroupsMutedActived.indexOf(from)].numbers : []
      if (isMuted && NumbersMuted.indexOf(sender) >= 0) {
        reply(`🐤😡 *Você deu um piu?* - Agora prepare-se para o seu julgamento!`)
        setTimeout(async () => {
          miwa.groupParticipantsUpdate(from, [sender], 'remove')
        }, 1000)
        return
      }

      //========(CONTADOR-DE-MENSAGENS)========\\
      var numbersIds = []
      if (isGroup && groupIdscount.indexOf(from) >= 0) {
        var ind = groupIdscount.indexOf(from)
        for (let obj of countMessage[ind].numbers) { numbersIds.push(obj.id) }
        if (numbersIds.indexOf(sender) >= 0) {
          var indnum = numbersIds.indexOf(sender)
          var RSM_CN = countMessage[ind].numbers[indnum]
          type == "stickerMessage" ? "" : RSM_CN.messages += isCmd ? 0 : 1
          type == "stickerMessage" ? "" : RSM_CN.cmd_messages += isCmd ? 1 : 0
          type == "stickerMessage" ? "" : RSM_CN.aparelho = adivinha
          RSM_CN.figus += type == "stickerMessage" ? 1 : 0
          fs.writeFileSync('./settings/media/countmsg.json', JSON.stringify(countMessage, null, 2) + '\n')
        } else {
          const messages = isCmd ? 0 : 1
          const cmd_messages = isCmd ? 1 : 0
          var figus = type == "stickerMessage" ? 1 : 0
          countMessage[ind].numbers.push({
            id: sender,
            messages: messages,
            cmd_messages: cmd_messages,
            aparelho: adivinha,
            figus: figus
          })
          fs.writeFileSync('./settings/media/countmsg.json', JSON.stringify(countMessage, null, 2) + '\n')
        }
      } else if (isGroup) {
        countMessage.push({
          groupId: from,
          numbers: [{
            id: sender,
            messages: 2,
            figus: 0,
            cmd_messages: isCmd ? 1 : 0,
            aparelho: adivinha
          }]
        })
        fs.writeFileSync('./settings/media/countmsg.json', JSON.stringify(countMessage, null, 2) + '\n')
      }

      const pickRandom = (arr) => {
        return arr[Math.floor(Math.random() * arr.length)]
      }


      //============(EVAL-EXECUÇÕES)===========\\

      if (budy.startsWith('>')) {
        try {
          if (info.key.fromMe) return
          if (!SoDono && !isnit && !issupre && !ischyt && !issupre && !ischyt) return
          console.log('[', colors.cyan('EVAL'), ']', colors.yellow(moment(info.messageTimestamp * 1000).format('DD/MM HH:mm:ss')), colors.green(budy))
          return await miwa.sendMessage(from, { text: JSON.stringify(eval(budy.slice(2)), null, '\t') }).catch(e => {
            return reply(String(e))
          })
        } catch (e) {
          return reply(String(e))
        }
      }

      if (budy.startsWith('(>')) {
        try {
          if (info.key.fromMe) return
          if (!SoDono && !isnit && !issupre && !ischyt && !issupre && !ischyt) return
          var konsol = budy.slice(3)
          Return = (sul) => {
            var sat = JSON.stringify(sul, null, 2)
            bang = util.format(sat)
            if (sat == undefined) {
              bang = util.format(sul)
            }
            return miwa.sendMessage(from, { text: bang }, { quoted: info })
          }

          await miwa.sendMessage(from, { text: util.format(eval(`;(async () => { ${konsol} })()`)) }).catch(e => {
            return reply(String(e))
          })
          console.log('\x1b[1;37m>', '[', '\x1b[1;32mEXEC\x1b[1;37m', ']', time, colors.green(">"), 'from', colors.green(sender.split('@')[0]), 'args :', colors.green(args.length))
        } catch (e) {
          return reply(String(e))
          console.log(e)
        }
      }


      if (body.startsWith('$')) {
        if (info.key.fromMe) return
        if (!SoDono && !isnit) return
        exec(q, (err, stdout) => {
          if (err) return reply(`${err}`)
          if (stdout) {
            reply(stdout)
          }
        })
      }

      //======================================\\


      //======(ANTI-IMAGEM)========\\
      if (isAntiImg && isBotGroupAdmins && type == 'imageMessage') {
        if (info.key.fromMe) return
        if (isGroupAdmins) return await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, porém é admin logo a punição será anulada.' }, { quoted: info })
        if (dataGp[0].legenda_imagem != "0") {
          await miwa.sendMessage(from, { text: dataGp[0].legenda_imagem }, { quoted: info })
        }
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      //======(ANTI-STICKER)========\\
      if (isAntiSticker && isBotGroupAdmins && type == 'stickerMessage') {
        if (info.key.fromMe) return
        if (isGroupAdmins) return await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, porém é admin logo a punição será anulada.' }, { quoted: info })
        await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, banindo o infrator...' }, { quoted: info })
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      if (Antidoc && isBotGroupAdmins && type == 'documentMessage') {
        if (info.key.fromMe) return
        if (isGroupAdmins) return await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, porém é admin logo a punição será anulada.' }, { quoted: info })
        if (dataGp[0].legenda_documento != "0") {
          await miwa.sendMessage(from, { text: dataGp[0].legenda_documento }, { quoted: info })
        }
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      let isTrueFalse = Array('tiktok', 'facebook', 'instagram', 'twitter', 'ytmp3', 'ytmp4', 'play', 'play_audio', 'play_video', 'play').some(item => item === command)

      if (isUrl(PR_String) && isAntiLinkHard && !isGroupAdmins && isBotGroupAdmins && !info.key.fromMe) {
        if (Procurar_String.includes("chat.whatsapp.com")) {
          link_dgp = await miwa.groupInviteCode(from)
          if (Procurar_String.match(link_dgp)) return reply('Link do nosso grupo, não irei remover.. ')
        }
        if (isCmd && isTrueFalse) return
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        miwa.groupSettingUpdate(from, 'announcement')
        setTimeout(() => {
          miwa.groupSettingUpdate(from, 'not_announcement')
        }, 1200)
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      // ANTI NOTAS FAKES ======================>

      if (isAntiNotas && budy2.toString().match(/(💳|💎|💸|💵|💷|💶|🪙|💰|🤑|⚖️)/gi) && isBotGroupAdmins && !isGroupAdmins && !SoDono && !info.message?.reactionMessage?.text && budy2.length > 20) {
        let verificar = budy2.toString().match(/(💳|💎|💸|💵|💷|💶|🪙|💰|🤑|⚖️)/gi)
        if (verificar && budy.length < 100) return
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      //FINALZIN ==============================>


      //======(ANTI-VIDEO)========\\

      if (isAntiVid && isBotGroupAdmins && type == 'videoMessage') {
        if (isGroupAdmins) return await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, porém é admin logo a punição será anulada.' }, { quoted: info })
        if (dataGp[0].legenda_video == "0") {
          await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, banindo o infrator...' }, { quoted: info })
        } else {
          await miwa.sendMessage(from, { text: dataGp[0].legenda_video }, { quoted: info })
        }
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      //======(ANTI-AUDIO)=======\\
      if (isAntiAudio && isBotGroupAdmins && type == 'audioMessage') {
        if (isGroupAdmins) return await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, porém é admin logo a punição será anulada.' }, { quoted: info })
        await miwa.sendMessage(from, { text: 'Mensagem proibida detectada, banindo o infrator...' }, { quoted: info })
        if (IS_DELETE) {
          setTimeout(() => {
            miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
          }, 500)
        }
        if (!JSON.stringify(groupMembers).includes(sender)) return
        miwa.groupParticipantsUpdate(from, [sender], 'remove')
      }

      //========(ANTI-PV-QUE-BLOQUEIA)======\\

      if (isAntiPv) {
        if (!isGroup && !SoDono && !isnit && !isPremium) {
          await sleep(2500)
          msgpvblock = `./database/func/call/msg_block-${sender}.json`
          fs.writeFileSync(msgpvblock, JSON.stringify("Olá amigo, o *ANTI-PV* está ativo no momento, ou seja, estou recebendo as ordens de bloquear os usuários que entrar em contato comigo no privado.", null, 2))
          msgmsglbl = JSON.parse(fs.readFileSync(msgpvblock))
          reply(msgmsglbl)
          DLT_FL(msgpvblock)
          setTimeout(async () => {
            miwa.updateBlockStatus(sender, 'block')
          }, 2000)
          return
        }
      }

      const antispam = JSON.parse(fs.readFileSync('./settings/media/antispam.json'));

      const isAntiSpam = isGroup ? dataGp[0].antispam : undefined
      //======================================\\

      {
        var hora_ = moment.tz('America/Sao_Paulo').format('HH:mm');
        var hora_2 = moment.tz('America/Sao_Paulo').format('mm');
        for (i of black_) {
          if (i.hora == hora_) { var blu_dc = true } else { var blu_dc = false }
        }
        if (blu_dc == true) {
          for (i of black_) {
            if (i.hora == hora_) var ik = i
          }
          for (i of ik?.PUXAR) {
            if (i.avisou == true) return
            if (i.length == 0) return
            await miwa.sendMessage(i.idgp, { text: i.msg })
            i.avisou = true
            fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
          }
        }; for (i of black_) {
          if (hora_2 >= i.hora.split(":")[1] + parseInt(1)) {
            var ik2 = i
            var ik_r = true
          } else { var ik_r = false }
        }; if (ik_r == true) {
          for (i of ik2.PUXAR) {
            if (i.avisou == true) {
              i.avisou = false
              fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
            }
          }
        }
      }

      //==========(REGISTRO)==================\\
      

      //=========(ANTIPV-QUE-SÓ-FALA)==========\\

      if (!isGroup && !isPremium && !SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe && isAntiPv2) return reply(`Olá, sou uma inteligência artificial, programado(a) para realizar ações, por adms e o dono, se você está enviando mensagem, provavelmente você não sabe disso, eu removo diariamente pessoas por enviar links e muito mais..`)

      //======================================\\
      var username = "Yuki"
      var apikey = "dark_key:pho2udb0"
      const API_KEY_MIWA = "Yukidev"

      // ANTI_LIGAR \\

      if (!isGroup && isAnticall) {
        miwa.ws.on('CB:call', async (B) => {
          var msgcallblock = `./database/func/call/msg_block-${sender}.json`
          if (!fs.existsSync(msgcallblock)) {
            fs.writeFileSync(msgcallblock, JSON.stringify("Olá amigo, o *ANTI-CALL* está ativo no momento, ou seja, estou recebendo as ordens de bloquear aqueles que efetuarem ligações para mim.", null, 2))
            var msgcallbl = JSON.parse(fs.readFileSync(msgcallblock))
            if (B.content[0].tag == 'offer') {
              await miwa.sendMessage(B.content[0].attrs['call-creator'], { text: msgcallbl }).then(() => {
                miwa.updateBlockStatus(B.content[0].attrs['call-creator'], "block")
                DLT_FL(msgcallblock)
              })
            }
          }
        })
      }

      //======================================\\
      var i9 = countMessage.map(i => i.groupId).indexOf(from)
      var idgrupo = groupIdscount.indexOf(from)

      var idusu = numbersIds?.indexOf(sender)

      if (isGroup && JSON.stringify(countMessage).includes(from) && JSON.stringify(countMessage[i9]).includes(sender)) {

        try {
          var qnt_msg = countMessage[idgrupo].numbers[idusu].messages
        } catch {
          var qnt_msg = 0
        }

        var patente = "Aspirante"

        var level_up = 0

        if (qnt_msg >= 0 && qnt_msg < 20) { var patente = "Aspirante"; var level_up = 0 }; if (qnt_msg >= 20 && qnt_msg < 50) { var patente = "Recruta"; var level_up = 1 }; if (qnt_msg >= 50 && qnt_msg < 100) { var patente = "Soldado"; var level_up = 2 }; if (qnt_msg >= 100 && qnt_msg < 200) { var patente = "Cabo"; var level_up = 3 }; if (qnt_msg >= 200 && qnt_msg < 300) { var patente = "Sargento"; var level_up = 4 }; if (qnt_msg >= 300 && qnt_msg < 400) { var patente = "Sargento I"; var level_up = 5 }; if (qnt_msg >= 400 && qnt_msg < 500) { var patente = "Sargento II"; var level_up = 6 }; if (qnt_msg >= 500 && qnt_msg < 600) { var patente = "Sargento III"; var level_up = 7 }; if (qnt_msg >= 600 && qnt_msg < 700) { var patente = "Sargento IV"; var level_up = 8 }; if (qnt_msg >= 700 && qnt_msg < 800) { var patente = "Sargento V"; var level_up = 9 }; if (qnt_msg >= 800 && qnt_msg < 900) { var patente = "Sargento VI"; var level_up = 10 }; if (qnt_msg >= 900 && qnt_msg < 1000) { var patente = "Sargento VII"; var level_up = 11 }; if (qnt_msg >= 1000 && qnt_msg < 1100) { var patente = "Sargento VII"; var level_up = 12 }; if (qnt_msg >= 1100 && qnt_msg < 1200) { var patente = "Sargento VIII"; var level_up = 13 }; if (qnt_msg >= 1200 && qnt_msg < 1500) { var patente = "Sargento IX"; var level_up = 14 }; if (qnt_msg >= 1500 && qnt_msg < 2000) { var patente = "Sargento X"; var level_up = 15 }; if (qnt_msg >= 2000 && qnt_msg < 2500) { var patente = "Tenente I"; var level_up = 16 }; if (qnt_msg >= 2500 && qnt_msg < 2600) { var patente = "Tenente II"; var level_up = 17 }; if (qnt_msg >= 2600 && qnt_msg < 2700) { var patente = "Tenente III"; var level_up = 18 }; if (qnt_msg >= 2700 && qnt_msg < 2800) { var patente = "Tenente III"; var level_up = 19 }; if (qnt_msg >= 2800 && qnt_msg < 2900) { var patente = "Tenente IV"; var level_up = 20 }; if (qnt_msg >= 2900 && qnt_msg < 3000) { var patente = "Tenente V"; var level_up = 21 }; if (qnt_msg >= 3000 && qnt_msg < 3200) { var patente = "Capitão I"; var level_up = 22 }; if (qnt_msg >= 3200 && qnt_msg < 3400) { var patente = "Capitão II"; var level_up = 23 }; if (qnt_msg >= 3400 && qnt_msg < 3800) { var patente = "Capitão III"; var level_up = 24 }; if (qnt_msg >= 3800 && qnt_msg < 4000) { var patente = "Capitão IV"; var level_up = 25 }; if (qnt_msg >= 4000 && qnt_msg < 5000) { var patente = "Capitão V"; var level_up = 26 }; if (qnt_msg >= 5000 && qnt_msg < 5500) { var patente = "Major I"; var level_up = 27 }; if (qnt_msg >= 5500 && qnt_msg < 6000) { var patente = "Major II"; var level_up = 28 }; if (qnt_msg >= 6000 && qnt_msg < 6500) { var patente = "Major III"; var level_up = 29 }; if (qnt_msg >= 6500 && qnt_msg < 8000) { var patente = "Major IV"; var level_up = 30 }; if (qnt_msg >= 8000 && qnt_msg < 9000) { var patente = "Major V"; var level_up = 31 }; if (qnt_msg >= 9000 && qnt_msg < 10000) { var patente = "Tenente C I"; var level_up = 32 }; if (qnt_msg >= 10000 && qnt_msg < 11000) { var patente = "Tenente C II"; var level_up = 33 }; if (qnt_msg >= 11000 && qnt_msg < 12000) { var patente = "Tenente C II"; var level_up = 34 }; if (qnt_msg >= 12000 && qnt_msg < 13000) { var patente = "Tenente C III"; var level_up = 35 }; if (qnt_msg >= 13000 && qnt_msg < 15000) { var patente = "Tenente C IV"; var level_up = 36 }; if (qnt_msg >= 15000 && qnt_msg < 17000) { var patente = "Tenente C V"; var level_up = 37 }; if (qnt_msg >= 17000 && qnt_msg < 20000) { var patente = "Coronel I"; var level_up = 38 }; if (qnt_msg >= 20000 && qnt_msg < 23000) { var patente = "Coronel II"; var level_up = 39 }; if (qnt_msg >= 25000 && qnt_msg < 28000) { var patente = "Coronel III"; var level_up = 40 }; if (qnt_msg >= 28000 && qnt_msg < 30000) { var patente = "Coronel IV"; var level_up = 41 }; if (qnt_msg >= 30000 && qnt_msg < 35000) { var patente = "Coronel V"; var level_up = 42 }

        if (isLevelingOn && !type == "stickerMessage") {
          switch (qnt_msg) {
            case 20: case 50: case 100: case 200: case 300: case 400:
            case 500: case 600: case 700: case 800: case 900: case 1000:
            case 1100: case 1200: case 1500: case 2000: case 2500: case 2600:
            case 2700: case 2800: case 2900: case 3000: case 3200: case 3400:
            case 3600: case 3800: case 4000: case 5000: case 5500: case 6000:
            case 6500: case 8000: case 9000: case 10000: case 11000: case 12000:
            case 13000: case 15000: case 17000: case 20000: case 23000:
            case 25000: case 28000: case 30000:
              await miwa.sendMessage(from, {
                text: `✥ Parabéns: @${sender.split("@")[0]}
Você upou de level e também de patente por completar ${qnt_msg} mensagens, veja as informações abaixo...
￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣￣
✧ Patente: ${patente} - ✧ Level: ${level_up}`
                , mentions: [sender]
              })
              break
          }
        }
      }

      if (isGroup) {
        if (!JSON.stringify(patentes).includes(from)) {
          patentes.push({
            grupoID: from,
            usus: [{
              id: sender,
              level_usu: level_up,
              patente_usu: patente
            }]
          })
          fs.writeFileSync("./settings/media/patentes.json", JSON.stringify(patentes))
        }
        var i8 = patentes.map(i => i.grupoID).indexOf(from)
        if (!JSON.stringify(patentes[i8].usus).includes(sender)) {
          patentes[i8].usus.push({
            id: sender,
            level_usu: level_up,
            patente_usu: patente
          })
          fs.writeFileSync("./settings/media/patentes.json", JSON.stringify(patentes))
        }
        var i9 = patentes[i8].usus.map(i => i.id).indexOf(sender)
        if (patentes[i8].usus[i9].patente_usu != patente) {
          patentes[i8].usus[i9].patente_usu = patente
          fs.writeFileSync("./settings/media/patentes.json", JSON.stringify(patentes))
        }
        if (patentes[i8].usus[i9].level_usu != level_up) {
          patentes[i8].usus[i9].level_usu = level_up
          fs.writeFileSync("./settings/media/patentes.json", JSON.stringify(patentes))
        }
      }

      if (isX9VisuUnica) {
        if (info.message?.viewOnceMessageV2 || type == "viewOnceMessage") {
          if (JSON.stringify(info).includes("videoMessage")) {
            var px = info.message?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessage?.message?.videoMessage
            px.viewOnce = false
            px.video = { url: px.url }
            px.caption += "Revelando o vídeo na visualização única enviada.."
            await miwa.sendMessage(from, px)
          } else {
            var px = info.message?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessage?.message?.imageMessage
            px.viewOnce = false
            px.image = { url: px.url }
            px.caption += "Revelando a imagem na visualização única enviada..."
            await miwa.sendMessage(from, px)
          }
        }
      }

      /////\\\\\\//////\\\\\\////\\\\////\\\///\\\///\\\\

      if (isBanned) return BannedExpired(ban)

      var palavrasfr = JSON.parse(fs.readFileSync("./database/grupos/palavras_forca.json"))

      var palavrasfrc = palavrasfr[Math.floor(Math.random() * palavrasfr.length)]

      var ALT_FR = palavrasfrc.plvr.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");

      async function rv_forca() {
        var blue = []
        for (let i = 0; i < ALT_FR.length; i++) {
          if (ALT_FR[i] == ' ') {
            blue.push(' ')
          } else {
            blue.push('_')
          }
        }
        dataGp[0].forca_ofc = [{ acertos: 0, erros: 0, palavra: blue, escreveu: [], palavra_ofc: ALT_FR, dica: palavrasfrc.dica, tema: palavrasfrc.tema }]
        dataGp[0].forca_inc = false
        setGp(dataGp)
      }
      //===================================



      //=========================

      //== BLOQUIO PRIVADO PARA O DONO [: creditos: by @Vitinho :] ==
      if (!isPremium && isCmd && muteall && banChatss && !SoDono && banChatss === true) return m.reply(`Olá *${pushname}*, o bot está privado temporariamente pra o meu mestre\n\nMotivo: Atualizando para um novo bot\n saiba mais: ${global.linkgrupss}`)

      //=================================

      //== EVIANDO MENSAGEM VIA LINK GP //\\
      
      //=========================

      const sendVideo = (id, link, desc, hehe) => {
        return miwa.sendMessage(id, { video: { url: link }, caption: desc, mimetype: 'video/mp4' }, { quoted: hehe })
      }

      const sendAudio = (id, link, tipo, hehe) => {
        return miwa.sendMessage(id, { audio: { url: link }, mimetype: tipo }, { quoted: hehe })
      }

      //2 
      
      //============================

      //REPLY INSTA
       

      // funções rpg

      const familiasPath = './funções_rpg/familias.json';
      const loadFamilias = () => {//criador: Ryuufranky x
        try {
          return JSON.parse(fs.readFileSync(familiasPath));
        } catch (err) {
          console.error(err);
          return { familias: [] };
        }
      };
      const saveFamilias = (familias) => {
        fs.writeFileSync(familiasPath, JSON.stringify(familias, null, 2));
      };
      const isUserInFamily = (sender) => {
        let familias = loadFamilias();
        return familias.familias.some(f => f.membros.includes(sender));
      };
      const criarFamilia = (sender, nomeFamilia) => {
        let familias = loadFamilias();
        if (isUserInFamily(sender)) {
          return 'Você já faz parte de uma família.';
        }
        const novaFamilia = {
          chefe: sender,
          nome: nomeFamilia,
          membros: [sender]
        };
        familias.familias.push(novaFamilia);
        saveFamilias(familias);
        return `Família '${nomeFamilia}' criada com sucesso!`;
      };//criador: Ryuufranky x
      const adicionarFamilia = (sender, membroParaAdicionar) => {
        let familias = loadFamilias();
        if (isUserInFamily(membroParaAdicionar)) {
          return 'Este membro já faz parte de uma família.';
        }
        const familia = familias.familias.find(f => f.chefe === sender);
        if (!familia) {
          return 'Você precisa criar uma família primeiro.';
        }
        familia.membros.push(membroParaAdicionar);
        saveFamilias(familias);
        return `Membro adicionado à família '${familia.nome}' com sucesso!`;
      };
      const sairFamilia = (sender) => {
        let familias = loadFamilias();
        const familiaIndex = familias.familias.findIndex(f => f.membros.includes(sender));
        if (familiaIndex === -1) {
          return 'Você não está em uma família.';
        }
        const familia = familias.familias[familiaIndex];
        familia.membros = familia.membros.filter(m => m !== sender);
        if (familia.membros.length === 0 || familia.chefe === sender) {
          familias.familias.splice(familiaIndex, 1);
          saveFamilias(familias);
          return `Você saiu e a família '${familia.nome}' foi desfeita.`;
        }
        saveFamilias(familias);
        return `Você saiu da família '${familia.nome}'.`;
      };
      const verFamilia = (sender) => {
        let familias = loadFamilias();
        const familia = familias.familias.find(f => f.membros.includes(sender));
        if (!familia) {
          return 'Você não está em uma família.';
        }
        const membrosFamilia = familia.membros.map(member => `@${member.split('@')[0]}`).join(', ');
        return `Família '${familia.nome}':\nMembros: ${membrosFamilia}`;
      };
      const verTodasFamilias = () => {//criador: Ryuufranky x
        let familias = loadFamilias();
        if (familias.familias.length === 0) {
          return 'Nenhuma família foi criada ainda.';
        }
        let resultado = '👨‍👩‍👧‍👦 Todas as Famílias:\n\n';
        familias.familias.forEach(familia => {
          const membrosFamilia = familia.membros.map(member => `@${member.split('@')[0]}`).join(', ');
          resultado += `Família '${familia.nome}':\nChefe: @${familia.chefe.split('@')[0]}\nMembros: ${membrosFamilia}\n\n`;
        });
        return resultado.trim();
      };

      const empresasPath = './funções_rpg/empresas.json';
      const loadEmpresas = () => {
        try {
          return JSON.parse(fs.readFileSync(empresasPath));
        } catch (err) {
          console.error(err);
          return { empresas: [] };
        }
      };
      const saveEmpresas = (empresas) => {
        fs.writeFileSync(empresasPath, JSON.stringify(empresas, null, 2));
      };

      // Criar uma empresa
      const criarEmpresa = (sender, nomeEmpresa, tipoEmpresa) => {
        let empresas = loadEmpresas();
        const precoBase = 30000; // Custo fixo para abrir uma empresa
        const dificuldade = tipoEmpresa === 'basica' ? 1 : 2; // 1 para básica, 2 para avançada
        const valorEmpresa = precoBase * dificuldade;

        if (isUserInEmpresa(sender)) {
          return 'Você já possui uma empresa.';
        }

        const novaEmpresa = {
          dono: sender,
          nome: nomeEmpresa,
          tipo: tipoEmpresa,
          valor: valorEmpresa,
          produtos: [],
          lucro: 0
        };

        empresas.empresas.push(novaEmpresa);
        saveEmpresas(empresas);
        addKoinUser(sender, -valorEmpresa); // Deduzir o valor ao criar a empresa
        return `Empresa '${nomeEmpresa}' criada com sucesso! Você gastou ${valorEmpresa} coins.`;
      };

      // Verificar se o usuário já possui uma empresa
      const isUserInEmpresa = (sender) => {
        let empresas = loadEmpresas();
        return empresas.empresas.some(e => e.dono === sender);
      };

      // Adicionar um produto à empresa
      const adicionarProduto = (sender, nomeProduto, valorProduto) => {
        let empresas = loadEmpresas();
        const empresa = empresas.empresas.find(e => e.dono === sender);

        if (!empresa) {
          return 'Você não possui uma empresa.';
        }

        empresa.produtos.push({
          nome: nomeProduto,
          valor: valorProduto
        });

        saveEmpresas(empresas);
        return `Produto '${nomeProduto}' adicionado à empresa '${empresa.nome}' com sucesso!`;
      };

      // Vender um produto
      const venderProduto = (sender, nomeProduto) => {
        let empresas = loadEmpresas();
        const empresa = empresas.empresas.find(e => e.dono === sender);

        if (!empresa) {
          return 'Você não possui uma empresa.';
        }

        const produtoIndex = empresa.produtos.findIndex(p => p.nome === nomeProduto);
        if (produtoIndex === -1) {
          return 'Produto não encontrado na sua empresa.';
        }

        const produto = empresa.produtos[produtoIndex];
        const comissao = produto.valor * 0.1; // 10% de comissão
        const lucro = produto.valor + comissao;

        empresa.lucro += lucro;
        empresa.produtos.splice(produtoIndex, 1); // Remove o produto vendido
        saveEmpresas(empresas);
        addKoinUser(sender, lucro); // Adicionar lucro ao saldo do usuário

        return `Produto '${nomeProduto}' vendido por ${lucro} coins! Comissões incluídas.`;
      };

      // Vender a empresa
      const venderEmpresa = (sender) => {
        let empresas = loadEmpresas();
        const empresaIndex = empresas.empresas.findIndex(e => e.dono === sender);

        if (empresaIndex === -1) {
          return 'Você não possui uma empresa.';
        }

        const empresa = empresas.empresas[empresaIndex];
        const valorVenda = empresa.valor + empresa.lucro;

        empresas.empresas.splice(empresaIndex, 1); // Remove a empresa
        saveEmpresas(empresas);
        addKoinUser(sender, valorVenda); // Adicionar valor de venda ao saldo do usuário

        return `Empresa '${empresa.nome}' vendida por ${valorVenda} coins!`;
      };

      // Visualizar a empresa do usuário
      const verEmpresa = (sender) => {
        let empresas = loadEmpresas();
        const empresa = empresas.empresas.find(e => e.dono === sender);

        if (!empresa) {
          return 'Você não possui uma empresa.';
        }

        const produtos = empresa.produtos.map(p => `${p.nome} - ${p.valor} coins`).join('\n') || 'Nenhum produto';
        return `Empresa: ${empresa.nome}\nTipo: ${empresa.tipo}\nValor: ${empresa.valor} coins\nLucro acumulado: ${empresa.lucro} coins\nProdutos:\n${produtos}`;
      };

      // Visualizar todas as empresas
      const verTodasEmpresas = () => {
        let empresas = loadEmpresas();

        if (empresas.empresas.length === 0) {
          return 'Nenhuma empresa foi criada ainda.';
        }

        let resultado = '🏢 Todas as Empresas:\n\n';
        empresas.empresas.forEach(empresa => {
          const produtos = empresa.produtos.map(p => `${p.nome} - ${p.valor} coins`).join('\n') || 'Nenhum produto';
          resultado += `Empresa: ${empresa.nome}\nDono: @${empresa.dono.split('@')[0]}\nTipo: ${empresa.tipo}\nValor: ${empresa.valor} coins\nLucro acumulado: ${empresa.lucro} coins\nProdutos:\n${produtos}\n\n`;
        });

        return resultado.trim();
      };

      const dindin = JSON.parse(fs.readFileSync("./funções_rpg/dinheiro/dindin.json"));

      const addATM = (sender) => {

        const obj = {
          id: sender,
          dindin: 1500
        };
        dindin.push(obj)
        fs.writeFileSync('./funções_rpg/dinheiro/dindin.json', JSON.stringify(dindin))
      }

      const addKoinUser = (sender, amount) => {

        let position = false
        Object.keys(dindin).forEach((i) => {
          if (dindin[i].id === sender) {
            position = i
          }
        })
        if (position !== false) {
          dindin[position].dindin += amount
          fs.writeFileSync('./funções_rpg/dinheiro/dindin.json', JSON.stringify(dindin))
        }
      }

      const checkATMuser = (sender) => {

        let position = false
        Object.keys(dindin).forEach((i) => {
          if (dindin[i].id === sender) {
            position = i
          }
        })
        if (position !== false) {
          return dindin[position].dindin
        }
      }

      const confirmATM = (sender, amount) => {

        let position = false
        Object.keys(dindin).forEach((i) => {
          if (dindin[i].id === sender) {
            position = i
          }
        })
        if (position !== false) {
          dindin[position].dindin -= amount
          fs.writeFileSync('./funções_rpg/dinheiro/dindin.json', JSON.stringify(dindin))
        }
      }
      const checkATM = checkATMuser(sender)
      try {
        if (checkATM === undefined) addATM(sender)
        const dinheirosaku = Math.floor(Math.random() * 0) + 0//GANHA ENTRA 10 * 50 POR CADA MSG
        addKoinUser(from, dinheirosaku)
      } catch (err) {
        console.error(err)
      }

      const arma = JSON.parse(fs.readFileSync('./funções_rpg/arma/arma.json'));

      const isarma = arma.includes(sender);

      const tesla = JSON.parse(fs.readFileSync('./funções_rpg/tesla/tesla.json'));

      const istesla = tesla.includes(sender)


      const churrasqueira = JSON.parse(fs.readFileSync('./funções_rpg/churrasqueira/churrasqueira.json'));

      const ishasChurrasqueira = churrasqueira.includes(sender);

      const diamondsPath = './funções_rpg/diamonds.json';

      // Load diamond data
      const loadDiamonds = () => {
        try {
          return JSON.parse(fs.readFileSync(diamondsPath));
        } catch (err) {
          console.error(err);
          return { diamonds: {} };
        }
      };

      // Save diamond data
      const saveDiamonds = (diamonds) => {
        fs.writeFileSync(diamondsPath, JSON.stringify(diamonds, null, 2));
      };

      const mineDiamonds = (sender) => {
        let diamondsData = loadDiamonds();
        if (!diamondsData.diamonds[sender]) {
          diamondsData.diamonds[sender] = 0;
        }

        const minedDiamonds = Math.floor(Math.random() * 5) + 1; // Randomly mine 1-5 diamonds
        diamondsData.diamonds[sender] += minedDiamonds;
        saveDiamonds(diamondsData);

        return `⛏️ Você minerou ${minedDiamonds} diamantes! Agora você tem ${diamondsData.diamonds[sender]} diamantes.`;
      };

      const sellDiamonds = (sender) => {
        let diamondsData = loadDiamonds();
        if (!diamondsData.diamonds[sender] || diamondsData.diamonds[sender] === 0) {
          return '💎 Você não tem diamantes para vender.';
        }

        const diamondCount = diamondsData.diamonds[sender];
        const diamondValue = 100;
        const totalValue = diamondCount * diamondValue;

        // Update user's currency balance
        addKoinUser(sender, totalValue);

        // Reset user's diamond count
        diamondsData.diamonds[sender] = 0;
        saveDiamonds(diamondsData);

        return `💰 Você vendeu ${diamondCount} diamantes por ${totalValue} moedas!`;
      };

      const casamentosPath = './funções_rpg/casamentos.json';

      // Carregar dados dos casamentos
      const loadCasamentos = () => {
        try {
          return JSON.parse(fs.readFileSync(casamentosPath));
        } catch (err) {
          console.error(err);
          return { casamentos: [] };
        }
      };

      // Salvar dados dos casamentos
      const saveCasamentos = (casamentos) => {
        fs.writeFileSync(casamentosPath, JSON.stringify(casamentos, null, 2));
      };

      // Verificar se um usuário já está casado
      const isUserMarried = (sender) => {
        let casamentos = loadCasamentos();
        return casamentos.casamentos.some(c => c.parte1 === sender || c.parte2 === sender);
      };

      // Realizar casamento
      const casar = (sender, parceiro) => {
        let casamentos = loadCasamentos();
        if (isUserMarried(sender)) {
          return 'Você já está casado.';
        }
        if (isUserMarried(parceiro)) {
          return 'Seu parceiro já está casado.';
        }
        const novoCasamento = {
          parte1: sender,
          parte2: parceiro,
          data: new Date().toISOString()
        };
        casamentos.casamentos.push(novoCasamento);
        saveCasamentos(casamentos);
        return `Você e @${parceiro.split('@')[0]} agora estão casados!`;
      };

      // Ver casamentos


      const verCasamento = (sender) => {
        let casamentos = loadCasamentos();
        const casamento = casamentos.casamentos.find(c => c.parte1 === sender || c.parte2 === sender);
        if (!casamento) {
          return 'Você não está casado.';
        }
        const parceiroa = casamento.parte1 === sender ? casamento.parte2 : casamento.parte1;
        return `Você está casado com @${parceiroa.split('@')[0]} desde ${new Date(casamento.data).toLocaleDateString()}.`;
      };

      // Divorciar
      const divorciar = (sender) => {
        let casamentos = loadCasamentos();
        const casamentoIndex = casamentos.casamentos.findIndex(c => c.parte1 === sender || c.parte2 === sender);
        if (casamentoIndex === -1) {
          return 'Você não está casado.';
        }
        const casamento = casamentos.casamentos[casamentoIndex];
        const parceiroqkf = casamento.parte1 === sender ? casamento.parte2 : casamento.parte1;
        casamentos.casamentos.splice(casamentoIndex, 1);
        saveCasamentos(casamentos);
        return `Você se divorciou de @${parceiroqkf.split('@')[0]}.`;
      };

      // Ver todos os casamentos
      const verTodosCasamentos = () => {
        let casamentos = loadCasamentos();
        if (casamentos.casamentos.length === 0) {
          return 'Nenhum casamento foi registrado ainda.';
        }
        let resultado = '👰‍💍 Todos os Casamentos:\n\n';
        casamentos.casamentos.forEach(casamento => {
          resultado += `💍 | @${casamento.parte1.split('@')[0]} ❤️ @${casamento.parte2.split('@')[0]} \n| 📅 Data: ${new Date(casamento.data).toLocaleDateString()}\n\n—————————————\n\n`;
        });
        return resultado.trim();
      };

      const tinderPath = './funções_rpg/tinder.json';

      const loadTinder = () => {
        try {
          const data = fs.readFileSync(tinderPath);
          if (data.length === 0) {
            return { perfis: [] }; // Retorna um objeto vazio se o arquivo estiver vazio
          }
          return JSON.parse(data);
        } catch (err) {
          console.error(err);
          return { perfis: [] }; // Retorna um objeto vazio em caso de erro de leitura
        }
      };

      const saveTinder = (perfis) => {
        fs.writeFileSync(tinderPath, JSON.stringify(perfis, null, 2));
      };

      const criarPerfilTinder = (sender, nomePerfil, descricao) => {
        let perfis = loadTinder();
        // Verificar se o usuário já tem um perfil
        if (perfis.perfis.some(p => p.usuario === sender)) {
          return 'Você já tem um perfil no Tinder.';
        }
        const novoPerfil = {
          usuario: sender,
          nome: nomePerfil,
          descricao: descricao,
          likes: [],
          dislikes: [],
          comentarios: []
        };
        perfis.perfis.push(novoPerfil);
        saveTinder(perfis);
        return `Perfil '${nomePerfil}' criado com sucesso no Tinder!`;
      };

      const excluirPerfilTinder = (sender) => {
        let perfis = loadTinder();
        const perfilIndex = perfis.perfis.findIndex(p => p.usuario === sender);
        if (perfilIndex === -1) {
          return 'Você ainda não criou um perfil no Tinder.';
        }
        perfis.perfis.splice(perfilIndex, 1);
        saveTinder(perfis);
        return 'Seu perfil no Tinder foi excluído com sucesso.';
      };

      const todosPerfisTinder = () => {
        let perfis = loadTinder();
        if (perfis.perfis.length === 0) {
          return 'Nenhum perfil encontrado no Tinder.';
        }
        // Selecionar um perfil aleatório
        const perfilAleatorio = perfis.perfis[Math.floor(Math.random() * perfis.perfis.length)];
        return `🔥 Perfil Aleatório no Tinder:\nNome: ${perfilAleatorio.nome}\nDescrição: ${perfilAleatorio.descricao}`;
      };

      const verMeuPerfilTinder = (sender) => {
        let perfis = loadTinder();
        const meuPerfil = perfis.perfis.find(p => p.usuario === sender);
        if (!meuPerfil) {
          return 'Você ainda não criou um perfil no Tinder.';
        }
        let perfilInfo = `👤 Seu Perfil no Tinder:\nNome: ${meuPerfil.nome}\nDescrição: ${meuPerfil.descricao}\n`;
        perfilInfo += `Likes Recebidos: ${meuPerfil.likes.length}\nDislikes Recebidos: ${meuPerfil.dislikes.length}\n\n`;
        if (meuPerfil.comentarios.length > 0) {
          perfilInfo += `Comentários Recebidos:\n`;
          meuPerfil.comentarios.forEach((comentario, index) => {
            perfilInfo += `${index + 1}. De @${comentario.autor.split('@')[0]}: ${comentario.texto}\n`;
          });
        } else {
          perfilInfo += 'Nenhum comentário recebido ainda.\n';
        }
        return perfilInfo.trim();
      };

      const curtirPerfilTinder = (sender, perfilCurtido) => {
        let perfis = loadTinder();
        const meuPerfil = perfis.perfis.find(p => p.usuario === sender);
        const perfilAlvo = perfis.perfis.find(p => p.nome.toLowerCase() === perfilCurtido.toLowerCase());
        if (!meuPerfil || !perfilAlvo) {
          return 'Perfil não encontrado.';
        }
        meuPerfil.likes.push(perfilAlvo.usuario);
        saveTinder(perfis);
        return `Você curtiu o perfil de ${perfilAlvo.nome}.`;
      };

      const descurtirPerfilTinder = (sender, perfilDescurtido) => {
        let perfis = loadTinder();
        const meuPerfil = perfis.perfis.find(p => p.usuario === sender);
        const perfilAlvo = perfis.perfis.find(p => p.nome.toLowerCase() === perfilDescurtido.toLowerCase());
        if (!meuPerfil || !perfilAlvo) {
          return 'Perfil não encontrado.';
        }
        meuPerfil.dislikes.push(perfilAlvo.usuario);
        saveTinder(perfis);
        return `Você descurtiu o perfil de ${perfilAlvo.nome}.`;
      };

      const comentarPerfilTinder = (sender, perfilComentado, textoComentario) => {
        let perfis = loadTinder();
        const meuPerfil = perfis.perfis.find(p => p.usuario === sender);
        const perfilAlvo = perfis.perfis.find(p => p.nome.toLowerCase() === perfilComentado.toLowerCase());
        if (!meuPerfil || !perfilAlvo) {
          return 'Perfil não encontrado.';
        }
        const novoComentario = {
          autor: sender,
          texto: textoComentario
        };
        perfilAlvo.comentarios.push(novoComentario);
        saveTinder(perfis);
        return `Você comentou no perfil de ${perfilAlvo.nome}.`;
      };

      //==========================

      // ÍNICIO: CASES / COMANDOS COM PREFIXO:
      switch (command) {

        case 'divu_criar':
          if (fs.existsSync('./database/divulga-' + from + '.json')) return reply("*voce ja criou seu banco de divulgação")
          try {
            ppimg = await miwa.profilePictureUrl(`${sender.split('@')[0]}@c.us`, 'image')
          } catch {
            ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
          }
          divulga = {
            "divulgar": {
              "perfil": `${ppimg}`,
              "id": `${from}`,
              "zap": `wa.me/+${sender.split("@")[0]}`,
              "nick": `${pushname}`,
              "frase": `Olá me chamo ${pushname} preciso de novos amigos, vamos amigar? esse aqui é meu número: wa.me/+${sender.split("@")[0]} me manda um up no pv pra me salvar o seu contato, não esquece de salvar o meu, escrevi essa biografía para você:`,
              "biografia": []
            }
          }
          fs.writeFileSync('./database/divulga-' + from + '.json', JSON.stringify(divulga, null, 2))
          reply("*Olá ${pushname}🤗*\n\n*a sua divulgação foi criada com susseso*\n\n*agora basta adicionar uma biografía com o comando ${prefix}criar_biografia*")
          break

        
        case '002':
          reply2("salve familias")
          break

        case '001':
          reply("a index atualizou")
          break




        case 'privado':
        case 'muteallon':
          if (!SoDono) return m.reply(`<❗> Somente meu dono pode usar esse comando.`)
          if (banChatss) return await m.reply('O modo privado já está ativo.')
          banChatss = true
          nescessario.banChatss = banChatss
          fs.writeFileSync('./settings/nescessario.json', JSON.stringify(nescessario, null, '\t'))
          await miwa.sendMessage(from, { text: "Mudança bem-sucedida para uso privado - apenas meu dono pode me usar." })
          break

        case 'publico':
        case 'mutealloff':
          if (!SoDono) return m.reply(`<❗> Somente meu dono pode usar esse comando.`)
          if (!banChatss) return await m.reply('Não está ativado ainda.')
          banChatss = false
          nescessario.banChatss = banChatss
          fs.writeFileSync('./settings/nescessario.json', JSON.stringify(nescessario, null, '\t'))
          await miwa.sendMessage(from, { text: "Mudança bem-sucedida para o uso público - todos podem usar meus comandos.*" })
          break

        case 'cotacao': {
          if (!isPremium) return reply(enviar.msg.premium)
          moedas = ["dolar", "euro", "bitcoin", "libra", "ethereum"]
          if (!moedas.includes(q_2)) return reply("A moeda está inexistente em meu banco de dados!\n*Disponíveis:* dolar, euro, bitcoin, libra, ethereum\n*Observação:* Use letras minúsculas para não ocorrer erros!")
          if (encodeURIComponent(q) == "dolar") {
            var money = "USD-BRL";
          } else if (encodeURIComponent(q) == "euro") {
            var money = "EUR-BRL";
          } else if (encodeURIComponent(q) == "bitcoin") {
            var money = "BTC-BRL";
          } else if (encodeURIComponent(q) == "libra") {
            var money = "GBP-BRL";
          } else if (encodeURIComponent(q) == "ethereum") {
            var money = "ETH-BRL";
          }
          axios.get(`https://economia.awesomeapi.com.br/last/${money}`)
            .then((response) => {
              if (encodeURIComponent(q) == "dolar") {
                var resposta = response.data.USDBRL;
              } else if (encodeURIComponent(q) == "euro") {
                var resposta = response.data.EURBRL;
              } else if (encodeURIComponent(q) == "bitcoin") {
                var resposta = response.data.BTCBRL;
              } else if (encodeURIComponent(q) == "ethereum") {
                var resposta = response.data.ETHBRL;
              } else if (encodeURIComponent(q) == "libra") {
                var resposta = response.data.GBPBRL;
              }
              msgSemQuoted(`🏦 COTAÇÃO - Últimas 24h: 💱\n- Moeda: ${resposta.name}\n- Valor mais alto: ${Number(resposta.high).toFixed(2)}\n- Valor mais baixo: ${Number(resposta.low).toFixed(2)}\n- Valor atual: ${Number(resposta.bid).toFixed(2)}`);
            }).catch((response) => {
              reply("❌️ Erro ao obter informações! ❌️");
            });
        }
          break;

        
        case 'lista_aluguel':
          if (!SoDono && !info.key.fromMe) return reply(mess.onlyOwner())
          bla = "*⏳️ Lista de [ Grupos Alugados ] ⚠️*\n\n"
          for (i = 0; i < rg_aluguel.length; i++) {
            bla += `[ ${i + 1} ] - Data de vencimento: ${rg_aluguel[i].data}\nId: ${rg_aluguel[i].grupo}\nGrupo: ${rg_aluguel[i].nome_do_gp}\nTexto informando sobre o dono do grupo alugado: ${rg_aluguel[i].texto}\n──────────────────────────\n`
          }
          reply(bla)

        case 'rm_aviso':
        case 'rm_avisos':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          for (i of black_) { var RDFA = i }
          if (!JSON.stringify(RDFA.PUXAR).includes(from)) return reply(`Nenhum aviso foi registrado nesse grupo, utilize o comando ${prefix}rg_aviso`)
          RDFA.PUXAR.splice(RDFA.PUXAR.indexOf(from))
          fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
          reply("Avisos referente a esse grupo, foi tirado de todos os horários registrados..")
          break

        case 'rg_aviso':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          var [hr, ms] = q.trim().split("|")
          if (!q.trim().includes(":") && !q.trim().includes("|")) return reply(`Exemplo: ${prefix + command} 12:00|Boa tarde a todos, prestem atenção nas regras do grupo\n\neste exemplo.. Ele vai enviar todos os dias as 12:00 da tarde a mensagem que você registrou, já se você quer trocar o horário.. Só refazer o comando\nSe você quer apagar o aviso do grupo, apenas coloque ${prefix}rm_aviso`)
          var i5 = black_?.map(i => i?.hora)?.indexOf(hr)
          if (JSON.stringify(black_[i5]?.PUXAR)?.includes(from)) {
            black_[i5].PUXAR.splice(black_[i5].PUXAR.map(i => i.idgp).indexOf(from))
            fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
            setTimeout(() => {
              msgSemQuoted(`O registro anterior foi apagado e recriou um novo, se deseja continuar, clique no botão abaixo..\n- Lembre-se que há avisos programados em outros horários, se quiser limpar todos, digite: ${prefix}rm_avisos`)
            }, 500)
          } else if (!JSON.stringify(black_).includes(hr)) {
            black_.push({ hora: hr, PUXAR: [{ idgp: from, msg: ms, avisou: false }] })
            fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
            reply("Aviso Criado com sucesso..")
          } else if (!JSON.stringify(black_[i5].PUXAR).includes(from)) {
            black_[i5].PUXAR.push({ idgp: from, msg: ms, avisou: false })
            fs.writeFileSync("./database/grupos/avisos.json", JSON.stringify(black_, null, 2))
            reply("Aviso Criado com sucesso..")
          }
          break

        case 'rg_aluguel':
          if (!SoDono) return reply(mess.onlyOwner())
          if (JSON.stringify(rg_aluguel).includes(from)) return reply("Este grupo ja foi registrado")
          var [data, texto] = q.trim().split("|")
          if (!q.trim().includes("|")) return reply(`Cade a |\nExemplo: ${prefix + command} 01/01|Dono do grupo: 555555555 / Pra cobrar o aluguel..`)
          rg_aluguel.push({ grupo: from, data: data, texto: texto, nome_do_gp: groupName, cobrou: false })
          fs.writeFileSync("./settings/media/rg_aluguel.json", JSON.stringify(rg_aluguel))
          reply("Registro de aluguel deste grupo, foi feito com sucesso...")
          break

        case 'iddogrupo':
          if (!SoDono) return reply(mess.onlyOwner())
          reply(from)
          break

        case 'rm_aluguel':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!q.trim().includes("g.us")) return reply(`Digite o ID do grupo que deseja tirar da lista de aluguel, fórma mais fácil de achar o id é consultando o comando lista_aluguel, ou então executando o comando iddogrupo dentro do grupo que deseja tirar da lista de aluguel, e copiando o id, e executando dessa forma.\nExemplo: ${prefix + command} 120363343392567405@g.us`)
          var i6 = rg_aluguel.map(i => i.grupo).indexOf(q.trim())
          rg_aluguel.splice(i6, 1)
          fs.writeFileSync("./settings/media/rg_aluguel.json", JSON.stringify(rg_aluguel))
          reply("Grupo tirado do registro de aluguel com sucesso..")
          break

        //=========== [ ÍNICIO JOGOS ] ========= //

        case 'addpalavras_forca':
        case 'addpalavras_f':
          if (!SoDono) return reply(mess.onlyOwner())
          var [ttl, tema, dc] = q.toLowerCase().trim().split("|")
          if (!q.includes("|")) return reply(`Faltanda a primeira |\nExemplo: ${prefix + command} titulo|tema|dica`)
          if (q.lastIndexOf("|") < 0) return reply(`Faltando a segunda |\nExemplo: ${prefix + command} titulo|tema|dica`)
          kir = []
          for (i of palavrasfr) { kir.push(i.plvr) }
          if (kir.indexOf(ttl.toLowerCase().trim()) >= 0) return reply("Este título já foi adicionado/existente...")
          palavrasfr.push({ plvr: ttl, tema: tema, dica: dc })
          fs.writeFileSync("./database/grupos/palavras_forca.json", JSON.stringify(palavrasfr, null, 2))
          reply("Palavra adicionada ao jogo da forca com sucesso...")
          break

        case 'rmpalavra_f':
        case 'rmpalavra_forca':
          if (!SoDono) return reply(mess.onlyOwner())
          var i5 = palavrasfr.map(i => i.plvr).indexOf(q.trim().toLowerCase())
          palavrasfr.splice(i5, 1)
          fs.writeFileSync("./database/grupos/palavras_forca.json", JSON.stringify(palavrasfr, null, 2))
          reply("Palavra tirada do jogo da forca com sucesso...")
          break

        case 'rv-forca': case 'resetforca':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isGroup) return reply(mess.onlyGroup())
          if (dataGp[0].forca_inc == false) return reply(`O jogo não foi iniciado.\nDigite ${prefix}iniciar_forca`)
          rv_forca()
          reply("Forca resetada com sucesso...")
          break

        case 'mostrar_forca':
        case 'ver_forca':
        case 'iniciar_forca':
        case 'jogodaforca':
          if (!isGroup) return reply(mess.onlyGroup())
          try {
            if (dataGp[0].forca_inc) return reply(`Jogo já está em andamento, caso queira resetar, fale com um adm para executar ${prefix}resetforca, ou tente acertar o jogo da forca que deve está logo a cima.`)
            if (!dataGp[0].forca_inc) {
              rv_forca()
              var DM_FR = dataGp[0].forca_ofc[0]
              dataGp[0].forca_inc = true
              setGp(dataGp)
              await sleep(300)
              linha_fr = " "
              for (i of DM_FR.palavra) { linha_fr += ` ${i}` }
              rsp_fr = `- Jogo da forca - ${DM_FR.palavra_ofc.length} Letras\n\nTema: ${DM_FR.tema}\n\nDica: ${DM_FR.dica}\n
|________
       _¦_\n\n\n\n\n\n\n
${linha_fr}\n
_____________________
\n_- JOGO INICIADO -_
\nUse ${prefix}r-f letra que talvez exista por sua observação.\n\nOu ${prefix}r-f nome todo\n
_____________________
`
              reply(rsp_fr)
            }
          } catch (e) {
            console.log(e)
          }
          break

        case 'r-forca':
        case 'r-f':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!dataGp[0].forca_inc) return reply(`O jogo não foi iniciado.\nDigite ${prefix}iniciar_forca`)
          if (!q.toLowerCase().trim()) return reply("Digite a letra que deseja responder..")
          var q2 = q_2.trim().toLowerCase()
          if (ANT_LTR_MD_EMJ(q2) || Number(q2)) return reply("Não pode letras modificadas, nem emoji, nem números..")
          if (q.trim().length == 2) return reply("Digite letra por letra para tentar adivinhar, ou acerte a palavra toda, boa sorte...")
          DM_FR = dataGp[0].forca_ofc[0]
          if (DM_FR.escreveu.indexOf(q2) >= 0) return reply("Esta letra já foi utilizada..")
          var ERRQ = DM_FR.palavra_ofc.includes(q2) ? 0 : 1
          var ERROS = dataGp[0].forca_ofc[0].erros
          DM_FR.escreveu.push(q2); setGp(dataGp)
          PSC = []
          if (DM_FR.palavra_ofc.indexOf(q2) >= 0) {
            for (i = 0; i < DM_FR.palavra_ofc.length; i++) {
              if (DM_FR.palavra_ofc[i] == q2) {
                PSC.push(i)
                DM_FR.acertos += 1
              }
            }
            setGp(dataGp)
            for (i of PSC) {
              DM_FR.palavra[i] = q2; setGp(dataGp)
            }
          }
          await sleep(300)
          linha_fr = " "
          for (i of DM_FR.palavra) { linha_fr += ` ${i}` }
          letra_ut = " "
          for (i of DM_FR.escreveu) { letra_ut += `${i}, ` }
          var RST_T = `- Jogo da forca - ${DM_FR.palavra_ofc.length} Letras\n\nTema: ${DM_FR.tema}\n\nDica: ${DM_FR.dica}\n
__________-_
         _|_\n
        ${ERROS + ERRQ >= 1 ? "🤡" : ""}\n      ${ERROS + ERRQ >= 2 ? "👈" : ""} ${ERROS + ERRQ >= 3 ? "👉" : ""}  \n         ${ERROS + ERRQ >= 4 ? "👖" : ""}\n         ${ERROS + ERRQ >= 5 ? "👞" : ""} ${ERROS + ERRQ >= 6 ? "👞" : ""}
\n${linha_fr}\n
___-________-_____\n
Letras ja utilizadas: ${letra_ut}
___-________-_____
`
          if (q.length > 2) { reply("Humm, espertinho quer acertar a palavra toda") }
          await sleep(500)
          if (DM_FR.palavra_ofc.indexOf(q2) >= 0 || q2.length > 2 && q2 == DM_FR.palavra_ofc) {
            reply(`${q2.length > 2 ? `Você acertou a palavra toda e ganhou bom menino(a), irei resetar o jogo...` : DM_FR.acertos == DM_FR.palavra_ofc.length ? `Parabéns, toda palavra foi concluída : < ${DM_FR.palavra_ofc} > irei resetar o jogo..` : `Você acertou uma letra e ganhou continue assim..`}`)
            if (q2.length > 2 || DM_FR.acertos == DM_FR.palavra_ofc.length) { return rv_forca() }
            await sleep(200)
            reply(RST_T)
          } else {
            reply(`${q2.length > 2 ? `Infelizmente você perdeu, errou a palavra toda, deveria ter tentado letra por letra né, irei resetar o jogo..` : ERROS + ERRQ == 6 ? `Aa, você completou 6 Erros, e perdeu irei resetar o jogo..` : `Você Errou, e perdeu 😥..`}`)
            dataGp[0].forca_ofc[0].erros += 1
            setGp(dataGp)
            if (q2.length > 2 || ERROS + ERRQ == 6) { return rv_forca() }
            await sleep(200)
            reply(RST_T)
          }
          break
        
        

        case 'carteira':
          var salldo = VerSaldo(sender)
          reply(`Dinheiro em conta: R$${salldo},00`)
          break

        case 'saldo':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!q) return reply(`ඬ⃟   Para adicionar saldo a uma pessoa, use a seguinte forma:
✧ *Exemplo:* ${prefix + command} add @pessoa 1

ඬ⃟   Para remover o saldo bancário da SabBank de um usuário, use a seguinte forma:
✧ *Exemplo:* ${prefix + command} del @pessoa 1`)
          if (args[0] === 'add') {
            if (info.message.extendedTextMessage != undefined) {
              mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
              valoh = Number(args[2])
              AdicionarSaldo(mentioned[0], valoh)
              reply(`*「 SALDO ADICIONADO COM SUCESSO 」*\n➸ *ID*: ${mentioned[0]}`)
            } else {
              valoh = Number(args[2])
              AdicionarSaldo(args[1] + '@s.whatsapp.net', valoh)
              reply(`*「 SALDO ADICIONADO COM SUCESSO 」*\n➸ *ID*: ${args[1]}@s.whatsapp.net`)
            }
          } else if (args[0] === 'del') {
            if (info.message.extendedTextMessage != undefined) {
              mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
              valoh = Number(args[2])
              ConfirmarPagamento(mentioned[0], valoh)
              reply(`*「 SALDO RETIRADO COM SUCESSO 」*\n➸ *ID*: ${mentioned[0]}`)
            } else {
              valoh = Number(args[2])
              ConfirmarPagamento(args[1] + '@s.whatsapp.net', valoh)
              reply(`*「 SALDO RETIRADO COM SUCESSO 」*\n➸ *ID*: ${args[1]}@s.whatsapp.net`)
            }
          }
          break

        case 'vercarteira': {
          if (!SoDono) return reply(mess.onlyOwner())
          if (info.message.extendedTextMessage != undefined) {
            mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
            carteirauser = VerSaldo(mentioned[0])
            reply(`- Aqui está a carteira do usuário: [ ${mentioned[0].split("@")[0]} ] atualizado agora!\nSaldo atual do Usuário: R$${carteirauser},00`)
          } else {
            carteirauser2 = VerSaldo(args[1] + '@s.whatsapp.net')
            reply(`- Aqui está a carteira do usuário: [ ${mentioned[0].split("@")[0]} ] atualizado agora!\nSaldo atual do Usuário: R$${carteirauser},00`)
          }
        }
          break

        case 'transferir': {
          txt = q.replace(" /", "/").replace("/ ", "/").replace(" / ", "/")
          // @usuário que vai receber o <valor>
          var [receber, valor] = txt.split("/")
          // valor ou tipo, inválido 
          if (!q.includes('/')) return reply(`Opa, você digitou o <Tipo> ou <Valor> inválido, tenha em mente que você só pode transferir com o <Tipo> ou <Valor> válido. um bom exemplo disso: ${prefix + command} @55/20`)
          // somente número! nada de letras! 
          if (isNaN(valor)) return await reply('Use apenas números nada de letras. <3>')
          // valor mínimo da transferência 
          if (valor < 3) return reply(`Transfrência mínima é de <3> reais`)
          // checar se o usuário tem ou não tem dinheiro 
          if (VerSaldo(sender) < valor) return reply(`🪙 [SEM SABCASH] 🪙\n - Infelizmente você não possui este valor ${valor}, para realizar esta transferência você precisa ter no máximo ${valor}. Quando estiver o valor volte aqui e tente novamente.`)
          const recebidor = `${receber.split("@")[0]}@s.whatsapp.net`
          taxa = 0.00 * valor
          taxado = valor - taxa
          // pagar, receber, evoluir.
          if (command === "transferir") {
            AdicionarSaldo(recebidor, taxado)
            ConfirmarPagamento(sender, valor)
            reply(`💠 *[TRANSFERÊNCIA REALIZADA]*
✧:ඬ A transferência foi realizada pelo usuário: wa.me/${sender.split("@")[0]}
✧:ඬ Destino de recebimento ao usuário: ${receber}
✧:ඬ Valor da Transferência: ${valor}`)
          } else if (command === "pix") {
            AdicionarSaldo(recebidor, taxado)
            ConfirmarPagamento(sender, valor)
            reply(`💠 *[TRANSFERÊNCIA REALIZADA]*
✧:ඬ A transferência foi realizada pelo usuário: wa.me/${sender.split("@")[0]}
✧:ඬ Destino de recebimento ao usuário: ${receber}`)
          }
        }
          break

        case 'apostar': {
          if (!isGroup) return reply('Comando apenas para grupo!')
          const dinheiro_ = VerSaldo(sender)
          const checkxpr = VerSaldo(sender, dinheiro_)
          const quantidader = `50`
          if (checkxpr <= quantidader) return reply(`Desculpa você ainda não pode apostar!😕 somente com: ${quantidader} de COINS.\n\nSeu saldo atual: R$${checkxpr},00`)
          if (Number(args[0]) >= checkxpr || Number(args[0]) >= dinheiro_) return reply(`Você não pode apostar uma quantidade de dinheiro maior do que a você tem, e nosso limite de apostas é de ${quantidader} dinheiro por vez!\n\nSeu dinheiro: ${checkxpr}`)
          if (Number(args[0]) < 1) return reply(`Qual o valor que você deseja apostar?`)
          if (isNaN(args[0])) return reply(`Digite "${prefix}apostar 100" (desse jeito sem nenhuma vírgula ou letras por favor.`)
          const double = Math.floor(Math.random() * 7) + 1
          const nrolxp = Number(-args[0])
          const prolxp = double + Number(args[0])
          if (double == 1) {
            await reply(`🔪BANG!!!💣\n\nVocê perdeu na roleta-russa, causando uma perca de ${nrolxp} em seu dinheiro.`)
            valoh1 = Number(args[0])
            ConfirmarPagamento(sender, valoh1)
          } else if (double == 2) {
            await reply(`*Você Ganhou! Parabéns.. 🥳*\nSobreviveu ao tiro e recebeu ${prolxp} COINS!`)
            AdicionarSaldo(sender, prolxp, dinheiro_)
          } else if (double == 3) {
            await reply(`Poxa você está sem sorte😓\n\nVocê perdeu ${nrolxp}\nNão desista continue apostando😎🤙`)
            valoh2 = Number(args[0])
            ConfirmarPagamento(sender, valoh2)
          } else if (double == 4) {
            await reply(`Essa foi por pouco!!😬\n\nVocê consegiu concluir o golpe e ganhou ${prolxp} COINS`)
            AdicionarSaldo(sender, prolxp, dinheiro_)
          } else if (double == 5) {
            await reply(`Você errou o cavalo 🐴! :(\n\nAcabou perdendo ${nrolxp} em seu dinheiro, que tal.. apostar mais alto??🙈.`)
            valoh3 = Number(args[0])
            ConfirmarPagamento(sender, valoh3)
          } else if (double == 6) {
            await reply(`*🥳 FINALMENTE, DEU BOM PA VC!* ✅️\n\nVocê finalmente ganhou, receba seus ${prolxp} COINS!️`)
            AdicionarSaldo(sender, prolxp, dinheiro_)
          }
        }
          break

        case 'churrasco': case 'açougue': case 'vendas': //@Vitinho 
          let picanha = Math.floor(Math.random() * 19) + 10
          let contrafl = Math.floor(Math.random() * 10) + 17
          let frangoassa = Math.floor(Math.random() * 15) + 20
          let migilhon = Math.floor(Math.random() * 40) + 60
          let resultFinal = picanha + contrafl + frangoassa + migilhon
          reply(`Aguarde 9 segundos para sair os resultados da peças de carnes vendidas!`)
          await delay(9000)
          var logochurras = "https://telegra.ph/file/96a9f0a48bb9f81b30ede.jpg"
          let enviarText = `┏ *「️🍖 𝐂 𝐇 𝐔 𝐑 𝐑 𝐀 𝐒 𝐂 𝐎 🍖」* ┓
│▢ Carne - Picanha Argentina: ${picanha}
│▢ Carne - Contra Filé: ${contrafl}
│▢ Carne - Asinhas de Frango: ${frangoassa}
│▢ Carne - Filé Mignon: ${migilhon}
┗ *「️🍖 𝐂 𝐇 𝐔 𝐑 𝐑 𝐀 𝐒 𝐂 𝐎 🍖」* ┛
[㕚] Foram vendidas hoje por você em nosso açougue: ${resultFinal} peças de carne por você. Parabéns!
[㕚] Isso significa que foi adicionado em sua carteira R$${resultFinal},00 em coins!`
          await miwa.sendMessage(from, { image: { url: `${logochurras}` }, caption: enviarText }, { quoted: info })
          AdicionarSaldo(sender, resultFinal)
          break

        case 'pescar': case 'pesca': //@Vitinho 
          let lagostas = Math.floor(Math.random() * 19) + 10
          let caranguejos = Math.floor(Math.random() * 10) + 17
          let camaroes = Math.floor(Math.random() * 15) + 20
          let mexilhao = Math.floor(Math.random() * 40) + 60
          let fdskk = lagostas + caranguejos + camaroes + mexilhao
          reply(`Aguarde 9 segundos para sair os resultados da pesca!`)
          await delay(9000)
          var logopescad = "https://telegra.ph/file/e0346a4d7a27cde1fd5cd.jpg"
          let teksehmazeh = `┏━── *「️ 🎣️ 𝐏 𝐄 𝐒 𝐂 𝐀 🎣 」*  ─━┓\n│▢ Total de Lagostas: ${lagostas}\n│▢ Total de Caranguejos: ${caranguejos}\n│▢ Total de Camarões: ${camaroes}\n│▢ Total de Mexilhão: ${mexilhao}\n│▢ *Resultado Final: ${fdskk}*\n┗━── *「️ 🎣️ 𝐏 𝐄 𝐒 𝐂 𝐀 🎣 」*  ─━┛\n[㕚] Isso significa que foi adicionado em sua carteira R$${fdskk},00 em coins!`
          await miwa.sendMessage(from, { image: { url: `${logopescad}` }, caption: teksehmazeh }, { quoted: info })
          AdicionarSaldo(sender, fdskk)
          break

        case 'minerar': //@Vitinho 
          if (!isGroup) return reply('Comando apenas para grupo')
          let minerar = Math.floor(Math.random() * 30)
          let textmi = [`Você minerando nas ilhas savitas encontrou ${minerar} Coins!👷⛏\n[㕚] Foi adicionado em seu saldo: R$${minerar},00 por meio da sua mineração!️️`, `Você minerando no seu quintal achou ${minerar} Coins\n[㕚] Foi adicionado em seu saldo: R$${minerar},00 por meio da sua mineração!️`, `Parabéns você achou ${minerar} Coin no quintal da vizinha?;-;\n[㕚] Foi adicionado em seu saldo: R$${minerar},00 por meio da sua mineração!️`, `Você invadiu mina proibida, e quando tava fazendo mineração achou ${minerar} Coins!⛏\n[㕚] Foi adicionado em seu saldo: R$${minerar},00 por meio da sua mineração!️`, `Você roubou ${minerar} Coins na mina de Minas gerais!👷⛏️💰\n[㕚] Foi adicionado em seu saldo: R$${minerar},00 por meio da sua mineração!`];
          const minerarresp = textmi[Math.floor(Math.random() * textmi.length)]
          AdicionarSaldo(sender, minerar)
  
          break

        case 'steal': //@Vitinho 
          try {
            if (!isGroup) return reply('Comando apenas para grupo')
            if (!q) return reply(`*❗ Marque a pessoa que deseja que eu faça isso! ❗*`)
            const XPs = VerSaldo(sender)
          const  ganhoXPs = Math.floor(Math.random() * 300) + 300
            AdicionarSaldo(sender, ganhoXPs)
           const mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
          const perdaXPs = Math.floor(Math.random() * -300) + -300
            open = [`*🕵🏼‍♂️[ ROUBOU-BEM-SUCEDIDO ]🕵🏼‍♂️*\nVocê roubou com sucesso a casa de @${mentioned[0].split('@')[0]} achando ${ganhoXPs} coins em um baú.`, `*👨🏼‍✈️[ PRISÃO ]👨🏼‍✈️*\n@${mentioned[0].split('@')[0]} te pegou no flagra e chamou a polícia, você teve que pagar ${perdaXPs} coins em indenizações para ele.`]
          const  clos = open[Math.floor(Math.random() * open.length)]
            mentions(clos, mentioned, true)
            ConfirmarPagamento(sender, perdaXPs, XPs)
          } catch {
            reply(`*❗ Tem que marcar seu alvo ❗*`)
          }
          break

        case 'quando': //@Vitinho
          if (args.length < 1) return reply('Digite a pergunta!')
          const meupirul = ['Hoje', 'Amanhã', 'Nunca', 'dia', 'semana', 'mês', 'ano']
          const meupirul2 = ['dias', 'semanas', 'meses', 'anos']
          randomm = meupirul[Math.floor(Math.random() * meupirul.length)]
          random2 = `${Math.floor(Math.random() * 11) + 1}`
          if (randomm == 'Hoje' || randomm == 'Amanhã' || randomm == 'Nunca') {
            texto = `Pergunta: ${body.slice(1)}\nResposta: ${randomm}`
          } else if (random2 == 1) {
            texto = `Pergunta: ${body.slice(1)}\nResposta:  1 ${randomm}`
          } else {
            random3 = meupirul2[Math.floor(Math.random() * meupirul2.length)]
            texto = `Pergunta: ${body.slice(1)}\nResposta: ${random2} ${random3}`
          }
          reply(texto)
          break

        //=========== [ FINAL JOGOS ] ========= //

        case 'limpar_mortos-cnt':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isGroup) return reply(mess.onlyOwner())
          bla = []
          var CNT_RS = countMessage[countMessage.map(i => i.groupId).indexOf(from)].numbers
          for (i = 0; i < CNT_RS.map(i => i.id).length; i++) { bla.push(CNT_RS.map(i => i.id)[i]) };
          for (i of groupMembers) { bla.splice(bla.indexOf(i.id), 1) };
          for (i of bla) { CNT_RS.splice(CNT_RS.indexOf(i), 1) };
          fs.writeFileSync("./settings/media/countmsg.json", JSON.stringify(countMessage))
          reply("Usuários que já foi removido, ou saiu do grupo, foi tirado do contador de mensagens..")
          break

        case 'tirar_docnt':
          if (!SoDono) return
          if (!isGroup) return reply(mess.onlyOwner())
          var i2 = countMessage.map(i => i.groupId).indexOf(from)
          var i = countMessage[i2].numbers.map(i => i.id).indexOf(q.trim() + "@s.whatsapp.net")
          countMessage[i2].numbers.splice(i, 1)
          fs.writeFileSync("./settings/media/countmsg.json", JSON.stringify(countMessage))
          reply("Usuário tirado do contador de mensagens com sucesso...")
          break
console.log('passou aqui linha 3068')
        case 'anotar':
        case 'tirar_nota':
        case 'rmnota':
          if (!isGroup) return reply(`Só em grupo pode utilizar este comando.`)
          if (!isGroupAdmins) return reply(`Só adm pode utilizar este tipo de comando.`)
          if (command == "anotar") {
            var [q5, q10] = q.trim().split("|")
            if (!q5 || !q10 || !q.includes("|")) return reply(`Digite o título da anotação e o texto que deseja anotar..\nExemplo: ${prefix}anotar Cachorro|Cachorros são bom pra comer na Venezuela...`)
            if (JSON.stringify(anotar).includes(from)) {
              var i2 = anotar.map(i => i.grupo).indexOf(from)
              if (JSON.stringify(anotar[i2].puxar).includes(q5)) {
                var i3 = anotar[i2].puxar.map(i => i.nota).indexOf(q5)
                if (anotar[i2].puxar[i3].nota == q5) return reply(`Esta anotação já está inclusa, utilize outro título.. Ou você pode tirar com\n${prefix}tirar_nota ${q5}`)
              }
            }
            if (!JSON.stringify(anotar).includes(from)) {
              anotar.push({ grupo: from, puxar: [{ nota: q5, anotacao: q10 }] })
              fs.writeFileSync("./database/func/tabela/anotar.json", JSON.stringify(anotar))
              reply("Anotação registrada com sucesso...")
            } else {
              anotar[i2].puxar.push({ nota: q5, anotacao: q10 })
              fs.writeFileSync("./database/func/tabela/anotar.json", JSON.stringify(anotar))
              reply("Anotação registrada com sucesso...")
            }
          } else {
            if (!q) return reply("Digite qual anotação deseja tirar pelo título..")
            if (JSON.stringify(anotar).includes(from)) {
              var i2 = anotar.map(i => i.grupo).indexOf(from)
              if (JSON.stringify(anotar[i2].puxar).includes(q)) {
                var i3 = anotar[i2].puxar.map(i => i.nota).indexOf(q)
              }
            }
            if (0 > anotar[i2].puxar.map(i => i.nota).indexOf(q)) return reply("Esta nota não está inclusa, verifique com atenção...")
            anotar[i2].puxar.splice(i3, 1)
            fs.writeFileSync("./database/func/tabela/anotar.json", JSON.stringify(anotar))
            reply(`Anotação ${q} tirada com sucesso...`)
          }
          break

        case 'anotacao':
        case 'anotacoes':
        case 'nota':
        case 'notas':
          if (!isGroup) return reply(`Só em grupo pode utilizar este comando.`)
          if (command == "anotacao" || command == "nota") {
            if (!q) return reply("Digite o título da anotação que deseja puxar..")
            if (!JSON.stringify(anotar).includes(from)) return reply("Este grupo não tem nenhuma anotação...")
            var i2 = anotar.map(i => i.grupo).indexOf(from)
            if (!JSON.stringify(anotar[i2].puxar).includes(q)) return reply("Não contém nenhuma anotação com este título.")
            var i3 = anotar[i2].puxar.map(i => i.nota).indexOf(q)
            mentions(`〈 ${anotar[i2].puxar[i3].anotacao} 〉`)
          } else {
            var i2 = anotar.map(i => i.grupo).indexOf(from)
            if (anotar[i2].puxar.length == 0) return reply("Este grupo não tem nenhuma anotação...")
            var i2 = anotar.map(i => i.grupo).indexOf(from)
            var antr = anotar[i2].puxar
            txtin = `Aqui está todas as anotações registradas em minha database do grupo: *[ ${groupName} ]*\n`
            for (i = 0; i < antr.length; i++) {
              txtin += `\n↝ Anotação: ⟮ ${anotar[i2].puxar[i].nota} ⟯ - 〈 ${anotar[i2].puxar[i].anotacao} 〉\n`
            }
            txtin += ""
            mentions(txtin)
          }
          break

        
         
           
          
        

        case 'signo':
          try {
            if (!q) return reply(`Digite seu signo, exemplo: ${prefix + command} Virgem`);
            signos = ["Áries", "Touro", "Gêmeos", "Câncer", "Leão", "Virgem", "Libra", "Escorpião", "Sagitário", "Capricórnio", "Aquário", "Peixes", "aries", "touro", "gemeos", "cancer", "leao", "virgem", "libra", "escorpiao", "sagitario", "capricornio", "aquario", "peixes"]
            if (!signos.includes(q_2)) return reply("Este signo não existe...")
            ABC = await fetchJson(`https://miwa-apis.online/api/horoscopo/v2?signo=${q}&apikey=` + API_KEY_MIWA)
            await miwa.sendMessage(from, { image: { url: ABC.resultado.imagem }, caption: `Signo: ${q}\n${ABC.resultado.inform}` }).catch(e => {
              return reply(`Erro..`)
            })
          } catch (e) {
            return reply(`Erro..`)
          }
          break

        case 'menuaga':
          const cell = `${info.key.id.length > 21 ? 'Android' : info.key.id.substring(0, 2) == '3A' ? 'iOS' : 'WhatsWeb'}`
          const userst = JSON.parse(fs.readFileSync("./database/usuarios/Registros/total.json"));
          const hora = moment.tz('America/Sao_Paulo').format('HH:mm:ss')
          const date = moment.tz('America/Sao_Paulo').format('DD/MM/YY')
          rr = (Date.now() / 1000) - info.messageTimestamp
          const ping = `${String(rr.toFixed(3))}`
          uptime = process.uptime()
          const momen = require('moment-timezone');
          momen.tz.setDefault('America/Sao_Paulo');
          const diaDaSemanaHoje = momen().locale('pt-br').format('dddd');
          var getGroups = await miwa.groupFetchAllParticipating()
          var groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
          const ingfoog = groups.map(v => v)
          miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: `┌────────────────┈ ⳹
│        𝑴𝑨𝑰 𝑩𝑶𝑻
│  ◦ *INFORMAÇÕES! ℹ️*
│  ◦ User: ${pushname} 🌷
│  ◦ Uptime : ${kyun(uptime)}
│  ◦ Velocidade :「${ping}」
│  ◦ Dispositivo: ${cell}
│  ◦ Hora : ${hora} 
│  ◦ Usuários: ${userst}
│  ◦ Data : ${date} - ${diaDaSemanaHoje}
│  ◦ Biblioteca: Baileys
│  ◦ Funcionando em: ${ingfoog.length} Grupos
└──────────────────☉`,
                },
                "footer": {
                  "text": "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒"
                },
                nativeFlowMessage: {
                  buttons: [{


                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "🌷𝐋𝐈𝐒𝐓𝐀 𝐃𝐄 𝐌𝐄𝐍𝐔𝐒🌷",
                      sections: [{

                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "💎 𝐌𝐄𝐍𝐔 💎",
                            id: `${prefix}menu`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🎗 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌 🎗",
                            id: `${prefix}menuadm`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🎮 𝐌𝐄𝐍𝐔 𝐉𝐎𝐆𝐎𝐒 🎮",
                            id: `${prefix}menubrincadeiras`
                          }
                        ],
                      },


                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🏫 𝐌𝐄𝐍𝐔 𝐑𝐏𝐆 🏫",
                            id: `${prefix}menurpg`
                          }
                        ],
                      },


                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🔍 𝐌𝐄𝐍𝐔 𝐏𝐄𝐒𝐐𝐔𝐈𝐒𝐀𝐒 🔍",
                            id: `${prefix}menupesquisa`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "⚜️ 𝐌𝐄𝐍𝐔 𝐄𝐅𝐄𝐈𝐓𝐎𝐒 ⚜️",
                            id: `${prefix}menuefeitos`
                          }
                        ],
                      },



                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🪬 𝐌𝐄𝐍𝐔 𝐀𝐋𝐓𝐄𝐑𝐀𝐃𝐎𝐑𝐄𝐒 🪬",
                            id: `${prefix}alteradores`
                          }
                        ],
                      },



                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🔞 𝐌𝐄𝐍𝐔 +𝟏𝟖 🔞",
                            id: `${prefix}menu+18`
                          }
                        ],
                      },



                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "👑 𝐌𝐄𝐍𝐔 𝐃𝐎𝐍𝐎 👑",
                            id: `${prefix}menudono`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🍄‍🟫 𝐌𝐄𝐍𝐔 𝐋𝐎𝐆𝐎𝐒 🍄‍🟫",
                            id: `${prefix}menulogos`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "🎖 𝐌𝐄𝐍𝐔 𝐕𝐈𝐏 🎖",
                            id: `${prefix}menupremium`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "𝐏𝐈𝐍𝐆",
                            id: `${prefix}ping`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "𝐈𝐍𝐅𝐎-𝐁𝐎𝐓",
                            id: `${prefix}infobot`
                          }
                        ],
                      },

                      {
                        title: "",
                        highlight_label: "𝐁𝐘 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒",
                        rows: [
                          {

                            title: "𝐈𝐍𝐅𝐎-𝐃𝐎𝐍𝐎",
                            id: `${prefix}criador`
                          }
                        ],
                      },

                      ]
                    })
                  }
                  ],
                  messageParamsJson: "",
                },
              },
            },
            {}
          )
          break

        case "botoes":
          if (!SoDono) return reply(mess.onlyOwner());
          if (botoes) {
            botoes = false
            nescessario.botoes = false
            setNes(nescessario)
            reply("- Botões desativado com sucesso, para ativar novamente só digitar o comando denovo.");
          } else if (!botoes) {
            botoes = true
            nescessario.botoes = true
            setNes(nescessario)
            reply("- Botões ativado com sucesso, para desativar novamente só digitar o comando denovo.");
          }
          break;



        case 'verificado-global':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isVerificado) {
            nescessario.verificado = true
            setNes(nescessario)
            reply(`- O verificado foi ativado de todos os comandos que tem, para tirar novamente só digitar o comando novamente..`)
          } else if (isVerificado) {
            nescessario.verificado = false
            setNes(nescessario)
            reply(`- O verificado de todos os comandos, foi desativado, para ativar novamente só digitar o comando novamente..`)
          }
          break



        case 'audio-menu':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isAudioMenu) {
            nescessario.menu_audio = true
            setNes(nescessario)
            reply(`- O áudio foi ativado para o menu com sucesso, se quiser desativar é só digitar o comando novamente.`)
          } else if (isAudioMenu) {
            nescessario.menu_audio = false
            setNes(nescessario)
            reply(`- O áudio foi desativado para o menu com sucesso, se quiser ativar é só digitar o comando novamente.`)
          }
          break

        case 'console':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isConsole) {
            nescessario.consoleoff = true
            setNes(nescessario)
            reply(`- O comando de tirar o console foi ativado com sucesso. Agora não verá mais os comandos nem mensagem dadas no console, mas funcionará perfeitamente, ok?, é bom para evitar banimento de spam no heroku.\n\nSe quiser desativar - Só digitar o comando novamente`)
          } else if (isConsole) {
            nescessario.consoleoff = false
            setNes(nescessario)
            reply(`- O comando de tirar o console foi desativado com sucesso. Agora verá os comandos e mensagens dadas no console, mas se for utilizar no heroku, recomendo ativar. é bom para evitar banimento de spam no heroku.\n\nSe quiser ativar - Só digitar o comando novamente`)
          }
          break

        case 'menu':
            const  rr = (Date.now() / 1000) - info.messageTimestamp
           const ping2 = `${String(rr.toFixed(3))}`

          
          miwa.sendMessage(from, { react: { text: `💦`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menu(prefix, NomeDoBot, sender, NickDono, packname, ping2), mentions: [sender] }, { quoted: selocontato })
          break

        case 'logos':
        case 'menulogo':
        case 'menulogos':
          miwa.sendMessage(from, { react: { text: `🎨`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menulogos(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'menuadm':
        case 'menuadms':
        case 'adm':
          await miwa.sendMessage(from, { react: { text: `👺`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menuadm(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case '18':
        case 'menuadulto':
        case 'menu+18':
          await miwa.sendMessage(from, { react: { text: `🔞`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menu18(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'scraper':
        case 'menuscraper':
        case 'menusc':
        case 'menupesquisas':
          await miwa.sendMessage(from, { react: { text: `👺`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menusc(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'menudono':
        case 'donomenu':
          await miwa.sendMessage(from, { react: { text: `🙇‍♀️`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menudono(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'efeitosimg':
        case 'menuefeitos':
        case 'efeitos':
        case 'efeitoimg':
        case 'efeitosmarcar':
          await miwa.sendMessage(from, { react: { text: `✨`, key: info.key } })
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.efeitos(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'alteradores':
        case 'menualteradores':
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.alteradores(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'menubrincadeiras':
        case 'brincadeiras':
        case 'brincadeira':

          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.brincadeiras(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'menupremium':
        case 'menuprem':
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menuprem(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'menurpg':
        case 'rpg':
          /*await miwa.sendMessage(from, { image: { url: logoslink.logo }*/await miwa.sendMessage(from, {image: fs.readFileSync('./fotos/menu.jpg'), caption: linguagem.menurpg(prefix, NomeDoBot, sender, NickDono, packname), mentions: [sender] }, { quoted: selo })
          break

        case 'configurarbot':
          await miwa.sendMessage(from, { text: getInfo.configbot(prefix) }, { quoted: info })
          break

        case 'destrava':
          if (!isPremium && !isGroupAdmins) return reply(enviar.msg.premium)
          await miwa.sendMessage(from, { text: destrava(prefix) }, { quoted: info })
          break

        case 'perfil':
          try {
            ppimg = await miwa.profilePictureUrl(`${sender.split('@')[0]}@c.us`, 'image')
          } catch {
            ppimg = 'https://telegra.ph/file/b5427ea4b8701bc47e751.jpg'
          }
          try {
            var conselho = palavrasc[Math.floor(Math.random() * palavrasc.length)]
            const nivelgado = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nivelgado2 = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const nivelgador = nivelgado[Math.floor(Math.random() * (nivelgado.length))]
            const nivelgado2r = nivelgado2[Math.floor(Math.random() * (nivelgado2.length))]
            const puta = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const puta2 = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const putar = puta[Math.floor(Math.random() * (puta.length))]
            const putar2 = puta2[Math.floor(Math.random() * (puta2.length))]
            const gostosura = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const gostosura2 = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            const gostosurar = gostosura[Math.floor(Math.random() * (gostosura.length))]
            const gostosurar2 = gostosura2[Math.floor(Math.random() * (gostosura2.length))]
            gadop = `${Math.floor(Math.random() * 100)}`
            const programa = Math.ceil(Math.random() * 10000)
            const dptr = `〘 🔥 𝐈𝐍𝐅𝐎 𝐏𝐄𝐑𝐅𝐈𝐋 💎 〙

● き⃟❈ Nome: ${pushname}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Número: @${sender.split("@")[0]}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Seu dispositivo: ${info.key.id.length > 21 ? 'Android' : info.key.id.substring(0, 2) == '3A' ? 'iOS' : 'Zap zap web 😂☝🏼'}
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Nível de prostituição: ${putar}${putar2}%
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Nível de gostosura: *${gostosurar}${gostosurar2}%*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Nível do gadometro: *${nivelgador}${nivelgado2r}%*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
● き⃟❈ Valor do programa: *R$${programa}*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬

➻ *~_CONSELHO_~* :
${conselho}`
            await miwa.sendMessage(from, { image: { url: ppimg }, caption: dptr, mentions: [sender] }, { quoted: selo })
          } catch (e) {
            console.log(e)
          }
          break

        case 'conselhobiblico':
        case 'conselhosbiblico':
        case 'conselhosb':
        case 'conselhob':
          var conselhosb = conselhob[Math.floor(Math.random() * conselhob.length)]
          jr = `${tempo} ${pushname} 

Conselhos Bíblico para você: 

- ${conselhosb} 

> Bot: ${NomeDoBot}
> Grupo: ${groupName}`
          await miwa.sendMessage(from, { text: jr }, { quoted: info, contextInfo: { "mentionedJid": jr } })
          break

        case 'tabela':
          await miwa.sendMessage(from, { text: tabela(prefix, NomeDoBot) }, { quoted: selo })
          break

        case 'destrava2':
          if (!isPremium && !isGroupAdmins) return reply(enviar.msg.premium)
          await miwa.sendMessage(from, { text: destrava2(prefix) }, { quoted: info })
          break

        case 'idiomas':
        case 'idioma':
          txt = `  
IDIOMAS DO GTTS OU DO TRADUTOR

EXEMPLO :

>> ${prefix}gtts pt (texto)

o PT que coloquei, é a linguagem, então pode por no lugar as 2 letras que define a linguagem, iguais os exemplos e os idiomas abaixo.

'af': 'Afrikaans',
'sq': 'Albanian',
'ar': 'Arabic',
'hy': 'Armenian',
'ca': 'Catalan',
'hr': 'Croatian',
'cs': 'Czech',
'da': 'Danish',
'nl': 'Dutch',
'en': 'English',
'eo': 'Esperanto',
'fi': 'Finnish',
'fr': 'French',
'de': 'German',
'el': 'Greek',
'ht': 'Haitian Creole',
'hi': 'Hindi',
'hu': 'Hungarian',
'is': 'Icelandic',
'id': 'Indonesian',
'it': 'Italian',
'ja': 'Japanese',
'ko': 'Korean',
'la': 'Latin',
'lv': 'Latvian',
'mk': 'Macedonian',
'no': 'Norwegian',
'pl': 'Polish',
'pt': 'Portugues',
'ro': 'Romanian',
'ru': 'Russian',
'sr': 'Serbian',
'sk': 'Slovak',
'es': 'Spanish',
'sw': 'Swahili',
'sv': 'Swedish',
'ta': 'Tamil',
'th': 'Thai',
'tr': 'Turkish',
'vi': 'Vietnamese',
'cy': 'Welsh'
 
🔥${NomeDoBot}🔥`

          await miwa.sendMessage(from, { text: txt }, { quoted: selo })
          break

        //========(FUNÇÕES-PREMIUM-AQUI)=======\\

        case 'ler':
        case 'ocr':
        case 'lerfoto':
          if (!isPremium && !SoDono) return reply("Só usuário premium pode utilizar este comando..")
          if ((isMedia && !info.message.videoMessage || isQuotedImage) && !q.length <= 1) {
            encmedia = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
            rane = getRandom('.' + await getExtension(encmedia.mimetype))
            buffimg = await getFileBuffer(encmedia, 'image')
            fs.writeFileSync(rane, buffimg)
            media = rane
            reply(mess.wait())
            await recognize(media, { lang: 'eng+ind', oem: 1, psm: 3 })
              .then(teks => {
                reply(teks.trim())
                DLT_FL(media)
              })
              .catch(err => {
                reply(err.message)
                DLT_FL(media)
              })
          } else {
            reply('Somente fotos!')
          }
          break

        case 'premiumlist':
          if (!isPremium) return reply(enviar.msg.premium)
          tkks = '╭────*「 *PREMIUM USER👑* 」\n'
          for (let V of premium) {
            tkks += `│+  @${V.split('@')[0]}\n`
          }
          tkks += `│+ Total : ${premium.length}\n╰──────*「 *${NomeDoBot}* 」*────`
          mention(tkks.trim())
          break

        case 'getquoted2':
        case 'getinfo':
        case 'get':
          reply(JSON.stringify(info.message.extendedTextMessage.contextInfo, null, 3))
          break

        case 'get-txt':
          reply(JSON.stringify(info.message.extendedTextMessage.contextInfo.quotedMessage.conversation, null, 2))
          break

        case 'gerarcpf':
          if (!isPremium) return reply(enviar.msg.premium)
          cp1 = `${Math.floor(Math.random() * 300) + 600}`
          cp2 = `${Math.floor(Math.random() * 300) + 600}`
          cp3 = `${Math.floor(Math.random() * 300) + 600}`
          cp4 = `${Math.floor(Math.random() * 30) + 60}`
          cpf = `${cp1}.${cp2}.${cp3}-${cp4}`
          await miwa.sendMessage(from, { text: `CPF gerado com sucesso : ${cpf}` }, { quoted: info })
          break

        case 'ddd':
          if (!isPremium) return reply(enviar.msg.premium)
          if (args.length < 1) return reply(`Use ${prefix + command} 81`)
          ddd = body.slice(5)
          ddds = await axios.get(`https://brasilapi.com.br/api/ddd/v1/${ddd}`)
          dddlist = `Lista de Cidades de ${ddds.data.state} com este DDD ${q}>\n\n`
          for (let i = 0; i < ddds.data.cities.length; i++) { dddlist += `${i + 1} ⪧ *${ddds.data.cities[i]}*\n` }
          await miwa.sendMessage(from, { text: dddlist }, { quoted: info })
          break

        //===========(ADMS-FUNÇÕES-AKI)=========\\

        case 'calculadora':
        case 'calcular':
        case 'calc':
          rsp = q.replace("x", "*").replace('"', ":").replace(new RegExp("[()abcdefghijklmnopqrstwuvxyz]", "gi"), "").replace("÷", "/")
          return reply(JSON.stringify(eval(rsp, null, '\t')))
          break

        case 'nomegp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          blat = args.join(" ")
          miwa.groupUpdateSubject(from, `${blat}`)
          await miwa.sendMessage(from, { text: 'Sucesso, alterou o nome do grupo' }, { quoted: info })
          break

        case 'descgp':
        case 'descriçãogp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(mess.onlyAdmins())
          blabla = args.join(" ")
          miwa.groupUpdateDescription(from, `${blabla}`)
          await miwa.sendMessage(from, { text: 'Sucesso, alterou a descrição do grupo' }, { quoted: info })
          break

        case 'setfotogp':
        case 'fotogp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!isQuotedImage) return reply(`Use: ${prefix + command} <Marque uma foto>`)
          ftgp = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
          rane = getRandom('.' + await getExtension(ftgp.mimetype))
          buffimg = await getFileBuffer(ftgp, 'image')
          fs.writeFileSync(rane, buffimg)
          medipp = rane
          miwa.updateProfilePicture(from, { url: medipp })
          reply(`Foto do grupo alterada com sucesso`)
          break

        case 'linkgp':
        case 'linkgroup':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          linkgc = await miwa.groupInviteCode(from)
          reply('https://chat.whatsapp.com/' + linkgc)
          break

        case 'recrutar':
          if (!isGroupAdmins && !isPremium) return reply("Só ADM ou premium")
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          rcrt = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`
          linkgc = await miwa.groupInviteCode(from)
          await miwa.sendMessage(rcrt, {
            image: { url: logoslink.logo }, caption: "Clique no símbolo a cima da imagem para entrar no grupo...", contextInfo: {
              externalAdReply: {
                title: "- Clique aqui para participar do grupo",
                body: "",
                reviewType: "PHOTO",
                thumbnailUrl: logoslink.logo,
                sourceUrl: `https://chat.whatsapp.com/` + linkgc,
                mediaType: 2
              }
            }
          })
          reply("Convite de recrutamento do usuário, foi enviado para o privado dele com sucesso...")
          break

        case 'listatm':
          if (!SoDono) return reply(mess.onlyOwner())
          rgp = JSON.parse(fs.readFileSync("./database/func/tmgroup.json"))
          if (rgp.length == 0) return reply(`Não contém nenhum registro de transmissão, utilize ${prefix}rgtm no grupo que deseja que ele receba as transmissões do bot..`)
          bl = "_-_-_-_-_-_-_-_-_-_-_-_-\n\n";
          for (i = 0; i < rgp.length; i++) {
            bl += `${i + 1} - ID: ${rgp[i].id}\n\n- NOME DO USUÁRIO OU GRUPO: ${rgp[i].infonome}\n\n`
          }
          reply(bl)
          break

        case 'rgtm':
          if (!SoDono) return reply(mess.onlyOwner())
          rgp = JSON.parse(fs.readFileSync("./database/func/tmgroup.json"))
          if (JSON.stringify(rgp).includes(from)) return reply("Este grupo ja está registrado na lista de transmissão")
          rgp.push({ id: from, infonome: `${isGroup ? groupName : pushname}` })
          fs.writeFileSync("./database/func/tmgroup.json", JSON.stringify(rgp))
          reply("Registrado com sucesso, quando for realizada as transmissões, esse grupo/usuário estará na lista.")
          break

        case 'tirardatm':
          if (!SoDono) return reply(mess.onlyOwner())
          rgp = JSON.parse(fs.readFileSync("./database/func/tmgroup.json"))
          if (!JSON.stringify(rgp).includes(from)) return reply("Este grupo não está registrado para ser tirado da lista de transmissão")
          if (q.trim().length > 4) {
            var ustm = rgp.map(i => i.id).indexOf(q.trim())
          } else {
            var ustm = rgp.map(i => i.id).indexOf(from)
          }
          rgp.splice(ustm, 1)
          fs.writeFileSync("./database/func/tmgroup.json", JSON.stringify(rgp))
          reply("Grupo/Usuário tirado da lista de transmissão com sucesso")
          break

        case 'fazertm':
          if (!SoDono) return reply(mess.onlyOwner())
          var rgp = JSON.parse(fs.readFileSync("./database/func/tmgroup.json"))
          if (rgp.lengh == 0) return reply("Não contém nenhum grupo registrado para realizar transmissão")
          await sleep(1000);
          var DFC = "";
          var rsm = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
          var pink = isQuotedImage ? rsm?.imageMessage : info.message?.imageMessage
          var blue = isQuotedVideo ? rsm?.videoMessage : info.message?.videoMessage
          var red = isQuotedMsg ? rsm?.textMessage : info.message?.textMessage
          var purple = isQuotedDocument ? rsm?.documentMessage : info.message?.documentMessage
          var yellow = isQuotedDocW ? rsm?.documentWithCaptionMessage?.message?.documentMessage : info.message?.documentWithCaptionMessage?.message?.documentMessage
          var aud_d = isQuotedAudio ? rsm.audioMessage : ""
          var figu_d = isQuotedSticker ? rsm.stickerMessage : ""
          var red = isQuotedMsg && !aud_d && !figu_d && !pink && !blue && !purple && !yellow ? "Transmissão Do Dono: " + rsm.conversation : info.message?.conversation
          var green = isQuotedMsg2 && !aud_d && !figu_d && !red && !pink && !blue && !purple && !yellow ? "Transmissão Do Dono: " + rsm.extendedTextMessage?.text : info?.message?.extendedTextMessage?.text
          if (pink) {
            var DFC = pink
            pink.caption = q.length > 1 ? "Transmissão Do Dono: " + q : pink.caption.replace(new RegExp(prefix + command, "gi"), `TRANSMISSÃO DO DONO: ${NickDono}\n\n`)
            pink.image = { url: pink.url }
          } else if (blue) {
            var DFC = blue
            blue.caption = q.length > 1 ? "Transmissão Do Dono: " + q : blue.caption.replace(new RegExp(prefix + command, "gi"), `TRANSMISSÃO DO DONO: ${NickDono}\n\n`)
            blue.video = { url: blue.url }
          } else if (red) {
            black = {}
            black.text = red.replace(new RegExp(prefix + command, "gi"), `TRANSMISSÃO DO DONO: ${NickDono}\n\n`)
            var DFC = black
          } else if (!aud_d && !figu_d && green) {
            brown = {}
            brown.text = green.replace(new RegExp(prefix + command, "gi"), `TRANSMISSÃO DO DONO: ${NickDono}\n\n`)
            var DFC = brown
          } else if (purple) {
            var DFC = purple
            purple.document = { url: purple.url }
          } else if (yellow) {
            var DFC = yellow
            yellow.caption = q.length > 1 ? "Transmissão Do Dono: " + q : yellow.caption.replace(new RegExp(prefix + command, "gi"), `TRANSMISSÃO DO DONO: ${NickDono}\n\n`)
            yellow.document = { url: yellow.url }
          } else if (figu_d) {
            var DFC = figu_d
            figu_d.sticker = { url: figu_d.url }
          } else if (aud_d) {
            var DFC = aud_d
            aud_d.audio = { url: aud_d.url }
          }
          for (i = 0; i < rgp.length; i++) {
            await miwa.sendMessage(rgp[i].id, DFC)
          }
          break

        case 'grupo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args[0] === 'a') {
            reply(`- Como pedido senhor(a), o grupo foi aberto com sucesso..`)
            miwa.groupSettingUpdate(from, 'not_announcement')
          } else if (args[0] === 'f') {
            reply(`- Como pedido senhor(a), o grupo foi fechado com sucesso..`)
            miwa.groupSettingUpdate(from, 'announcement')
          }
          break

        case 'grupoinfo':
        case 'infogrupo':
        case 'infogp':
        case 'gpinfo':
        case 'regras':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          try {
            var ppUrl = await miwa.profilePictureUrl(from, 'image')
          } catch {
            var ppUrl = `https://telegra.ph/file/6ca032835ed7a16748b6f.jpg`
          }
          await miwa.sendMessage(from, { image: { url: ppUrl }, caption: `*NOME* : ${groupName}\n*MEMBRO* : ${groupMembers.length}\n*ADMIN* : ${groupAdmins.length}\n*DESCRIÇÃO* : ${groupDesc}`, thumbnail: null }, { quoted: info })
          break

        case 'totag':
        case 'cita':
        case 'hidetag':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          var DFC = "";
          var rsm = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
          var pink = isQuotedImage ? rsm?.imageMessage : info.message?.imageMessage
          var blue = isQuotedVideo ? rsm?.videoMessage : info.message?.videoMessage
          var purple = isQuotedDocument ? rsm?.documentMessage : info.message?.documentMessage
          var yellow = isQuotedDocW ? rsm?.documentWithCaptionMessage?.message?.documentMessage : info.message?.documentWithCaptionMessage?.message?.documentMessage
          var aud_d = isQuotedAudio ? rsm.audioMessage : ""
          var figu_d = isQuotedSticker ? rsm.stickerMessage : ""
          var red = isQuotedMsg && !aud_d && !figu_d && !pink && !blue && !purple && !yellow ? rsm.conversation : info.message?.conversation
          var green = rsm?.extendedTextMessage?.text || info?.message?.extendedTextMessage?.text
          var MRC_TD = groupMembers.map(i => i.id)
          if (pink && !aud_d && !purple) {
            var DFC = pink
            pink.caption = q.length > 1 ? "Marcação do Adminstrador: " + q : pink.caption.replace(new RegExp(prefix + command, "gi"), `Marcação do Adminstrador: ${pushname}\n\n`)
            pink.image = { url: pink.url }
            pink.mentions = MRC_TD
          } else if (blue && !aud_d && !purple) {
            var DFC = blue
            blue.caption = q.length > 1 ? "Marcação do Adminstrador: " + q.trim() : blue.caption.replace(new RegExp(prefix + command, "gi"), `Marcação do Adminstrador: ${pushname}\n\n`).trim()
            blue.video = { url: blue.url }
            blue.mentions = MRC_TD
          } else if (red && !aud_d && !purple) {
            black = {}
            black.text = red.replace(new RegExp(prefix + command, "gi"), `Marcação do Adminstrador: ${pushname}\n\n`).trim()
            black.mentions = MRC_TD
            var DFC = black
          } else if (!aud_d && !figu_d && green && !purple && !purple) {
            brown = {}
            brown.text = green.replace(new RegExp(prefix + command, "gi"), `Marcação do Adminstrador: ${NickDono}\n\n`).trim()
            brown.mentions = MRC_TD
            var DFC = brown
          } else if (purple) {
            var DFC = purple
            purple.document = { url: purple.url }
            purple.mentions = MRC_TD
          } else if (yellow && !aud_d) {
            var DFC = yellow
            yellow.caption = q.length > 1 ? "Marcação do Adminstrador: " + q.trim() : yellow.caption.replace(new RegExp(prefix + command, "gi"), `Marcação do Adminstrador: ${pushname}\n\n`).trim()
            yellow.document = { url: yellow.url }
            yellow.mentions = MRC_TD
          } else if (figu_d && !aud_d) {
            var DFC = figu_d
            figu_d.sticker = { url: figu_d.url }
            figu_d.mentions = MRC_TD
          } else if (aud_d) {
            var DFC = aud_d
            aud_d.audio = { url: aud_d.url }
            aud_d.mentions = MRC_TD
            aud_d.ptt = true
          }
          await miwa.sendMessage(from, DFC).catch(e => {
            console.log(e)
          })
          break

        case 'marcar':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          async function marcac() {
            bla = []
            blad = `• Mencionando os membros comuns do grupo ou de uma comunidade. ${!q ? "" : `\n💬 *Mensagem:* ${q}`}\n\n`
            for (let i of somembros) {
              blad += `» @${i.split("@")[0]}\n`
              bla.push(i)
            }
            blam = JSON.stringify(somembros)
            if (blam.length == 2) return reply(`❌️ Olá *${pushname}* - Não contém nenhum membro comum no grupo, é sim apenas administradores. `)
            mentions(blad, bla, true)
          }
          marcac().catch(e => {
            console.log(e)
          })
          break

        case 'marcar2':
          try {
            if (!isGroup) return reply(mess.onlyGroup())
            if (!isGroupAdmins) return reply(mess.onlyAdmins())
            if (q.includes(`${prefix}`)) return reply("Não pode utilizar comandos nesse comando.")
            members_id = []
            teks = (args.length > 1) ? body.slice(8).trim() : ''
            teks += ''
            for (let mem of groupMembers) {
              teks += `╠➥ @${mem.id.split('@')[0]}\n`
              members_id.push(mem.id)
            }
            reply(teks)
          } catch {
            reply('ERROR!!')
          }
          break

        case 'marcarwa':
          try {
            if (!isGroup) return reply(mess.onlyGroup())
            if (!isGroupAdmins) return reply(mess.onlyAdmins())
            if (q.includes(`${prefix}`)) return reply("Não pode utilizar comandos nesse comando")
            members_id = []
            teks = (args.length > 1) ? body.slice(10).trim() : ''
            teks += ''
            for (let mem of groupMembers) {
              teks += `╠➥ https://wa.me/${mem.id.split('@')[0]}\n`
              members_id.push(mem.id)
            }
            await miwa.sendMessage(from, { text: teks }, { quoted: info })
          } catch {
            reply('ERROR!!')
          }
          break

        case 'reviverqr':
          if (!SoDono && !isnit) return
          exec(`cd ${folderUserAuth} && rm -rf pre-key* sender* session*`)
          setTimeout(async () => {
            reply("Reiniciando..")
            setTimeout(async () => {
              process.exit()
            }, 1200)
          }, 1000)
          break

        case 'reviver':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono) return reply("Comando Desativado pelo dono...")
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('Marque uma mensagem do alvo!')
          sleep(5000)
          response2 = await miwa.groupParticipantsUpdate(from, [menc_prt], "add")
          reply('Usuario Adicionado de volta ao grupo.')
          break

        case 'sairgp':
          if (isGroup && !SoDono && !info.key.fromMe) return reply("Este comando só o bot ou o dono pode executar..")
          try {
            miwa.groupLeave(from)
          } catch (erro) {
            reply(String(erro))
          }
          break

        case 'seradm':
          if (!SoDono && !isnit) return reply("Só dono pode executar este comando.")
          mentions(`@${sender.split("@")[0]} Pronto - Agora você é um administrador..`, [sender], true)
          miwa.groupParticipantsUpdate(from, [sender], "promote")
          break

        case 'sermembro':
          if (!SoDono && !isnit) return reply("Só dono pode executar este comando.")
          mentions(`@${sender.split("@")[0]} Pronto - Agora você é um membro comum novamente..`, [sender], true)
          miwa.groupParticipantsUpdate(from, [sender], "demote")
          break


        case 'rmadv':
          if (!isGroup) return reply(enviar.msg.grupo)
          if (!isGroupAdmins) return reply(enviar.msg.adm)
          if (!marc_tds) return reply("Cadê o alvo que você deseja retirar a advertência")
          adv = dataGp[0].advertir.map(i => i).indexOf(marc_tds)
          if (adv < 0) return reply(`${tempo} ${pushname} esse usuário não tem nenhuma advertência`)
          dataGp[0].advertir.splice(adv, 1)
          setGp(dataGp)
          reply(`*Advertência retira com sucesso vossa majestade: ${pushname}*`)
          break

        case 'adv':
        case 'advertir':
        case 'adverter':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (menc_os2 == botNumber) return reply("Não pode advertir o próprio bot.");
          if (menc_os2 == nmrdn) return reply("Não pode advertir o próprio dono do bot.");
          if (groupAdmins.includes(menc_os2)) return reply("Não é possível advertir adminstrador do grupo.");
          if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Não tem como advertir um usuário que não se encontra mais no grupo.")
          ADVT.push(menc_os2); setGp(dataGp)
          setTimeout(async () => {
            var dfqn = ADVT.filter(x => x == menc_os2).length
            var dfntxt = `Olá @${menc_os2.split("@")[0]} - Você foi advertido ${dfqn}/3, tome cuidado com 3 advertências, você será removido...`
            if (!dfntxt.includes("3/3")) {
              if (!JSON.stringify(ADVT).includes(sender)) {
                await sleep(1500); mentions(dfntxt, [menc_os2])
              } else if (dfqn == 2) {
                await sleep(1500); mentions(dfntxt, [menc_os2])
              }
            } else {
              await miwa.sendMessage(from, { text: `👋🏻 Adeus usuário: [ @${menc_os2.split("@")[0]} ] - Você completou 3 advertências, fale com a administração do grupo para ter noção do que foi ocorrido.`, mentions: [menc_os2] })
              await sleep(1500)
              miwa.groupParticipantsUpdate(from, [menc_os2], "remove")
              var i = ADVT.indexOf(menc_os2); ADVT.splice(i, 3); setGp(dataGp)
            }
          }, 3000)
          break

        //======≠(INFOS/EXECUÇÃO/DONO)≠=========\\

        case 'apresentar':
        case 'apr':
          inff = `Bem vindo(a) ao grupo : ${groupName}


👾 •𝑬𝑵𝑻𝑹𝑶𝑼 𝑺𝑬 𝑨𝑷𝑹𝑬𝑺𝑬𝑵𝑻𝑨•
📸 •F𝜣T𝜣
👻 •N𝜣ME
📌 •CID∆DE
🗓️ •ID∆DE
⚠️ •LEI∆ ∆S REGR∆S D𝜣 GRUP𝜣

*APROVEITE O GRUPO!*`
          await miwa.sendMessage(from, { text: inff }, { quoted: selo })
          break

        case 'papof':
        case 'regraspp':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          txtz = `【᯽𒋨📷:𝑆𝑒 𝑎𝑝𝑟𝑒𝑠𝑒𝑛𝑡𝑒𝑚 𝑙𝑖𝑥𝑜𝑠🌚»°】
𒋨·࣭࣪̇🔥ɴᴏᴍᴇ:
𒋨·࣭࣪̇🔥ɪᴅᴀᴅᴇ:
𒋨·࣭࣪̇🔥ʀᴀʙᴀ:
*Aᴘʀᴇsᴇɴᴛᴇ-sᴇ sᴇ ǫᴜɪsᴇʀ.*
𝙏𝘼𝙂𝙎➭᜔ׂ࠭ ⁸₈⁸|𝟖𝟖𝟖|𝟠𝟠𝟠| ེི⁸⁸⁸
 ──╌╌╌┈⊰★⊱┈╌╌╌┈─
❌ ENTROU NO 
GRUPO INTERAJA, NÃO PRECISAMOS DE ENFEITES,INATIVOS SERAO REMOVIDOS ❌* 

/﹋<,︻╦╤─ ҉ - -----💥 
/﹋ 🅴 🅱🅴🅼 🆅🅸🅽🅳🅾 🆂🅴🆄🆂 🅵🅸🅻🅷🅾🆂 🅳🅰 🅿🆄🆃🅰`
          await miwa.sendMessage(from, { text: txtz }, { quoted: selo })
          break

        case 'digt':
          bla = `🔥↯𝐉𝐀 𝐄𝐍𝐓𝐑𝐀 𝐃𝐈𝐆𝐈𝐓𝐀𝐍𝐃𝐎 𝚽𝐈 ↯°🌚💕
           ི⋮ ྀ🌴⏝ ི⋮ ྀ🚸 ི⋮ ྀ⏝🌴 ི⋮ ྀ 

🐼🍧↯𝖠𝖰𝖴𝖨 𝖵𝖮𝖢𝖤̂ 𝖯𝖮𝖣𝖤 𝖲𝖤𝖱↯🍧🐻
ㅤㅤㅤㅤ  ◍۫❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ⟅◌ٜ🛸◌⟆࣭࣭ٜ໑⃕ꔷ⃘࣭࣭࣭࣭ٜ❀۫◍ི࣭࣭࣭࣭ ུ
    【✔】ᴘʀᴇᴛᴀ👩🏾‍🦱 【✔】ʙʀᴀɴᴄᴀ👩🏼
    【✔】ᴍᴀɢʀᴀ🍧【✔】ɢᴏʀᴅᴀ🍿
    【✔】ᴘᴏʙʀᴇ🪙 【✔】ʀɪᴄᴀ💳
    【✔】ʙᴀɪᴀɴᴀ💌【✔】ᴍᴀᴄᴏɴʜᴇɪʀᴀ🍁
    【✔】ᴏᴛᴀᴋᴜ🧧【✔】ᴇ-ɢɪʀʟ🦄
    【✔】ʟᴏʟɪ🍭    【✔】ɢᴀᴅᴏ🐃
    【✔】ɢᴀʏ🏳️‍🌈     【✔】ʟᴇsʙɪᴄᴀ✂️
    【✔】ᴠᴀᴅɪᴀ💄  【✔】ᴛʀᴀᴠᴇᴄᴏ🍌
                【✔】ɴɪɴɢᴜᴇᴍ ʟɪɢᴀ📵
. ☪︎ • ☁︎. . •.
【 𝐕𝐄𝐌 𝐆𝐀𝐋𝐄𝐑𝐀, 𝐒𝐄 𝐃𝐈𝐕𝐄𝐑𝐓𝐈𝐑 𝐄 𝐅𝐀𝐙𝐄𝐑 𝐏𝐀𝐑𝐓𝐄 𝐃𝐀 𝐅𝐀𝐌𝐈𝐋𝐈𝐀.】🥂`
          await miwa.sendMessage(from, { text: bla }, { quoted: selo })
          break

        case 'sairdogp':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!q) return reply(`Você deve visualizar o comando ${prefix}listagp e olhar de qual o grupo quer sair, e veja a numeração dele, e só digitar\nExemplo: ${prefix}sairdogp 0\nesse comando é para o bot sair do grupo que deseja..`)
          var getGroups = await miwa.groupFetchAllParticipating()
          var groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
          var ingfoo = groups.map(v => v)
          try {
            await miwa.sendMessage(ingfoo[q].id, { text: "Irei sair do grupo, por ordem do meu dono, adeus..." })
            setTimeout(() => {
              miwa.groupLeave(ingfoo[q].id)
            }, 5000)
          } catch (erro) {
            reply(String(erro))
          }
          reply("Pronto meu dono, sair do grupo que você queria, em caso de dúvidas acione o comando listagp pra verificar..")
          break

        case 'listagp':
          if (!SoDono && !isnit && !info.key.fromMe) return reply('```SOMENTE MEU DONO LINDÃO```')
          var getGroups = await miwa.groupFetchAllParticipating()
          var groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
          var ingfoo = groups.map(v => v)
          ingfoo.sort((a, b) => (a[0] < b.length))
          teks1 = `*LISTA DE GRUPOS*\n*Total de Grupos* : ${ingfoo.length}\n\n`
          for (let i = 0; i < ingfoo.length; i++) {
            var metadt = await miwa.groupMetadata(ingfoo[i].id)
            try {
              var linkdogp = await miwa.groupInviteCode(ingfoo[i].id)
            } catch {
              var linkdogp = "Não foi possivel puxar o link"
            }
            teks1 += `• *Grupo* : ${i}\n• *Nome do Grupo* : ${ingfoo[i].subject}\n• *Id do Grupo* : ${ingfoo[i].id}\n• Link do grupo: https://chat.whatsapp.com/${linkdogp}\n• *Dono_Ofc*: ${metadt.subjectOwner}\n• *Criado* : ${moment(`${ingfoo[i].creation}` * 1000).tz('America/Sao_Paulo').format('DD/MM/YYYY HH:mm:ss')}\n• *Total de Membros* : ${ingfoo[i].participants.length}\n\n`
          }
          reply(teks1)
          break

        case 'atividade':
        case 'atividades':
          try {
            if (!isGroupAdmins && !issupre && !ischyt) return reply(mess.onlyAdmins())
            if (isGroup && JSON.stringify(countMessage).includes(from)) {
              var i6 = countMessage.map(i => i.groupId).indexOf(from)
              if (countMessage[i6].numbers.length == 0) return
              teks = `*Atividade dos membros do grupo:*\n\n`
              for (i = 0; i < countMessage[i6].numbers.length; i++) {
                var i8 = countMessage[i6].numbers.map(i => i.id).indexOf(countMessage[i6].numbers[i].id)
                var uscnt = countMessage[i6].numbers[i]
                teks += `*• Membro:* @${uscnt.id.split('@')[0]}\n*• Comandos:* ${uscnt.cmd_messages}*\n*• Mensagens:* ${uscnt.messages}*\n*• Aparelho:* ${uscnt.aparelho}*\n\n----------------------------------\n\n`
              }
              mention(teks)
            } else return reply('*Nada foi encontrado*')
          } catch (e) {
            console.log(e)
          }
          break

        case 'inativos':
        case 'inativo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (q.match(/[a-z]/i) || !q) return reply(`Exemplo: ${prefix + command} 0\nIsso mostrará quantas pessoas tem 0 mensagens no grupo, e se usar 5, vai mostrar quantos usuários tem 5 mensagens ou menos..`)
          var i2 = countMessage?.map(x => x.groupId)?.indexOf(from)
          blue = []; for (i of countMessage[i2].numbers) {
            if (i.messages <= q.trim())
              if (i.figus <= q.trim())
                if (i.cmd_messages <= q.trim())
                  if (!groupAdmins.includes(i.id))
                    if (!numerodono.includes(i.id))
                      if (i.id != botNumber)
                        if (groupMembers.map(i => i.id).includes(i.id))
                          blue.push(i.id)
          }; for (i of countMessage[i2].numbers) {
            if (!groupMembers.map(i => i.id).includes(i.id))
              if (i.id.length > 5)
                blue.push(i.id)
          }
          if (blue.length == 0) return reply(`Não tem pessoas com ${q}  mensagens..`)
          bli = `Usuários com ${q.trim()} mensagem(ns) pra baixo..\n\n`
          for (ac = 0; ac < blue.length; ac++) {
            bli += `${ac + 1} - Usuário: @${blue[ac].split("@")[0]}\n\n`
          }
          mention(bli)
          break

        case 'banghost':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono) return reply(mess.onlyOwner())
          if (q.match(/[a-z]/i) || !q || q.length > 3) return reply(`Digite a partir de quantas mensagens pra baixo você deseja remover (que não interaje no grupo).\nExemplo: ${prefix + command} 0`)
          var i2 = countMessage?.map(x => x.groupId)?.indexOf(from)
          blue = []; for (i of countMessage[i2].numbers) {
            if (i.messages <= Number(q.trim()))
              if (i.figus <= Number(q.trim()))
                if (i.cmd_messages <= Number(q.trim()))
                  if (!groupAdmins.includes(i.id))
                    if (!numerodono.includes(i.id))
                      if (i.id != botNumber)
                        if (groupMembers.map(i => i.id).includes(i.id))
                          blue.push(i.id)
          }; for (i of countMessage[i2].numbers) {
            if (!groupMembers.map(i => i.id).includes(i.id))
              if (i.id.length > 5)
                blue.push(i.id)
          }
          if (blue.length == 0) return reply(`Não tem mais pessoas com ${q.trim()} mensagem(ns) para eu remover..`)
          for (i = 0; i < blue.length; i++) {
            await sleep(1000)
            miwa.groupParticipantsUpdate(from, [blue[i]], "remove")
          }
          break

        case 'correio':
          txt = body.slice(10)
          txtt = args.join(" ")
          txt1 = txt.split("/")[0];
          txt2 = txtt.split("/")[1];
          if (!txt) return reply('Cade o número da pessoa?')
          if (!txtt) return reply('Cade a mensagem do correio??')
          if (txt.includes("-")) return reply('Tem que ser o número junto sem +, e não pode tá separado da /')
          if (txtt.includes("+")) return reply('Tem que ser o número junto sem +, e não pode tá separado da /')
          if (!txtt.includes("/")) return reply(`Exemplo: ${prefix}correio 558198923680/Oi Amor, sdds`)
          bla =
            `╭┄━┄━┄━┄━┄━╮
┞┧ ⸙. ͎۪۫          💌  ː͡₊ꞋꞌꞋꞌ
┞┧Correio anônimo. 
┞┧Msg: ${txt2}
┞┧
╰┄━┄━┄━┄━┄━╮`
          await miwa.sendMessage(`${txt1}@s.whatsapp.net`, { text: bla })
          break

        case 'nome-bot':
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          NomeDoBot = q.trim()
          setting.NomeDoBot = q.trim()
          fs.writeFileSync('./settings/settings.json', JSON.stringify(setting, null, 2))
          reply(`O nome do seu bot foi alterado com sucesso para : ${q}`)
          break

        case 'nick-dono':
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          setting.NickDono = q.trim()
          NickDono = setting.NickDono
          fs.writeFileSync('./settings/settings.json', JSON.stringify(setting, null, 2))
          reply(`O Nick Do Dono foi configurado para : ${q}`)
          break

        case 'numero-dono':
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          if (q.match(/[a-z]/i)) return reply("É apenas números..")
          reply(`O número dono foi configurado com sucesso para : ${q}`)
          setting.numerodono = q.trim().replace(new RegExp("[()+-/ +/]", "gi"), "");
          numerodono[0] = setting.numerodono
          numerodn = setting.numerodono
          numerodono_ofc = setting.numerodono
          fs.writeFileSync('./settings/settings.json', JSON.stringify(setting, null, 2))
          break

        case 'prefixo-bot': case 'setprefix':
          if (args.length < 1) return
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          setting.prefix = q
          fs.writeFileSync('./settings/settings.json', JSON.stringify(setting, null, 2))
          reply(`O prefixo foi alterado com sucesso para: ${setting.prefix}`)
          break

        case 'fotomenu':
        case 'fundomenu':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isQuotedImage) return reply("Marque uma imagem")
          if ((isMedia && !info.message.videoMessage || isQuotedImage) && !q.length <= 1) {
            reply(`- Calma ae amigo(a), já estou trocando a foto do menu para você..`)
            boij = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
            owgi = await getFileBuffer(boij, 'image')
            res = await upload(owgi)
            logoslink.logo.splice([])
            fs.writeFileSync('./settings/logos.json', JSON.stringify(logoslink, null, 2))
            setTimeout(() => {
              logoslink.logo.push(res)
              fs.writeFileSync('./settings/logos.json', JSON.stringify(logoslink, null, 2))
              reply(`A foto do menu foi alterada com sucesso para: ${logoslink.logo}`)
            }, 1000)
          } else {
            reply(`Mande uma imagem com o comando ${prefix + command} para trocar a foto de todos menu..`)
          }
          break

        case 'privphotobot': {
          if (!SoDono) return reply(mess.onlyOwner())
          if (!q) return reply(`• ${prefix + command} all - Minha foto de perfil visível a todos que entrarem em contato comigo.\n\n• ${prefix + command} cntt - Minha foto de perfil visível somenre aos meus contatos salvos.\n\n• ${prefix + command} ngm - Ninguém verá a minha foto de perfil, ou seja, estará oculta a todos.`)
          if (args[0] === 'all') {
            reply(`- A minha foto do perfil agora está visível à todos.`)
            await miwa.updateProfilePicturePrivacy('all')
          } else if (args[0] === 'cntt') {
            reply(`- A minha foto do perfil agora está visível somente aos meus contatos.`)
            await miwa.updateProfilePicturePrivacy('contacts')
          } else if (args[0] === 'ngm') {
            reply(`- A foto do meu perfil está privada a todos, até mesmo ao senhor mestre.`)
            await miwa.updateProfilePicturePrivacy('none')
          }
        }
          break

        case 'setprefix':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          prefix = args[0]
          setting.prefix = prefix
          fs.writeFileSync('./settings/settings.json', JSON.stringify(setting, null, 2))
          reply(`O prefixo foi alterado com sucesso para: ${prefix}`)
          break

        case 'nomegp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          miwa.groupUpdateSubject(from, `${body.slice(9)}`)
          await miwa.sendMessage(from, { text: 'Sucesso, alterou o nome do grupo' }, { quoted: info })
          break

        case 'fotobot':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isQuotedImage) return reply(`Envie fotos com legendas ${prefix}fotobot ou tags de imagem que já foram enviadas`)
          buff = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage, 'image')
          miwa.updateProfilePicture(botNumber, buff)
          reply('Obrigado pelo novo perfil😗')
          break

        case 'clonar':
          if (!SoDono && !isnit && !issupre && !ischyt) return reply('Você quem é o proprietário?')
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('Marque a pessoa que você quer clonar\n\n*EXEMPLO:* clone @')
          if (!menc_jid2[0] || menc_jid2[1]) return reply("Marque o @ do usuário para roubar a foto do perfil dele, para a do bot..")
          let { jid, id, notify } = groupMembers.find(x => x.id === menc_jid2[0])
          try {
            pp = await miwa.profilePictureUrl(id)
            buffer = await getBuffer(pp)
            miwa.updateProfilePicture(botNumber, buffer)
            mentions(`Foto do perfil atualizada com sucesso, usando a foto do perfil @${id.split('@')[0]}`, [id], true)
          } catch (e) {
            reply('Putz, deu erro, a pessoa deve estar sem foto 😔')
          }
          break

        case 'envmsg':
          if (!SoDono && !isnit) return
          var [tx1, tx2] = q.split("/")
          await miwa.sendMessage(tx1, { text: tx2 })
          break

        case 'bcgp':
        case 'bcgc':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!q) return reply('Cade o texto?')
          var nomor = info.participant
          if (isMedia && !info.message.videoMessage || isQuotedImage) {
            encmedia = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage, 'image')
            for (i = 0; i < groupMembers.length; i++) {
              await sleep(2000)
              await miwa.sendMessage(groupMembers[i].id, { image: buff }, { caption: `*「 TRANSMISSÃO 」*\n\nGrupo: ${groupName}\n Número: wa.me/${sender.split('@')[0]}\nMensagem : ${body.slice(6)}` })
            }
            reply('Transmissão enviada..')
          } else {
            for (i = 0; i < groupMembers.length; i++) {
              await sleep(2000)
              sendMess(groupMembers[i].id, `*「 TRANSMISSÃO 」*\n\nGrupo : ${groupName}\nNúmero : wa.me/${sender.split('@')[0]}\nMensagem : ${body.slice(6)}`)
            }
            reply('Grupo de transmissão bem-sucedido')
          }
          break

        case 'dono1':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono1 = q.trim()
          dono1 = nescessario.dono1
          setNes(nescessario)
          reply(`Agora contem um segundo dono(a) alterado com sucesso para: ${q}`)
          break

        case 'dono2':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono2 = q.trim()
          dono2 = nescessario.dono2
          setNes(nescessario)
          reply(`Agora contem um segundo dono(a) alterado com sucesso para: ${dono2}`)
          break

        case 'dono3':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono3 = q.trim()
          dono3 = nescessario.dono3
          setNes(nescessario)
          reply(`Agora contem um terceiro dono(a) alterado com sucesso para: ${dono3}`)
          break

        case 'dono4':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono4 = q.trim()
          dono4 = nescessario.dono4
          setNes(nescessario)
          reply(`Agora contem um quarto dono(a) alterado com sucesso para: ${dono4}`)
          break

        case 'dono5':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono5 = q.trim()
          dono5 = nescessario.dono5
          setNes(nescessario)
          reply(`Agora contem um quinto dono(a) alterado com sucesso para: ${dono5}`)
          break

        case 'dono6':
          if (args.length < 1) return
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          nescessario.dono6 = q.trim()
          dono6 = nescessario.dono6
          setNes(nescessario)
          reply(`Agora contem um quinto dono(a) alterado com sucesso para: ${dono6}`)
          break

        case 'getquoted':
          reply(JSON.stringify(info.message.extendedTextMessage.contextInfo, null, 3))
          break

        case 'donos':
          p = `[ Lista de donos do bot ${NomeDoBot} ] 

Dono Oficial do bot: ${numerodono_ofc}

- [ 1 ] ${dono1}\n- [ 2 ] ${dono2}\n- [ 3 ] ${dono3}\n- [ 4 ] ${dono4}\n- [ 5 ] ${dono5}\n- [ 6 ] ${dono6}`
          reply(p)
          break

        case 'admins':
        case 'listadmins':
        case 'listaadmins':
          if (!isGroup) return reply(mess.onlyGroup())
          ytb = `Lista de admins do grupo *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`
          no = 0
          for (let admon of groupAdmins) {
            no += 1
            ytb += `[${no.toString()}] @${admon.split('@')[0]}\n`
          }
          mentions(ytb, groupAdmins, true)
          break

        case 'criartabela': case 'criartbl': case 'criartab':
          if (!isGroupAdmins && !SoDono) return reply("Só adm ou dono pode utilizar este comando.")
          if (!q.trim()) return reply("Digite o que deseja colocar na tabela do grupo..")
          msgz = args.join(" ")
          msgtmpol = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
          datinhaofc = moment.tz('America/Sao_Paulo').format('DD/MM/YY');
          fs.writeFileSync(`./database/func/tabela/tabela-${from}.json`,
            JSON.stringify({ Horario: msgtmpol, Data: datinhaofc, Tabela: msgz }, null, 2));
          reply(`Tabela do grupo foi criada com sucesso..`)
          break

        case 'tabelagp': case 'tabeladogp': case 'tabelinha':
          if (!fs.existsSync(`./database/func/tabela/tabela-${from}.json`)) {
            reply(`Cade a tabela, cria ela com o comando\nExemplo : ${prefix}criartabela lindas do grupo : e etc ..`)
          }
          const tabelagpofc = JSON.parse(fs.readFileSync(`./database/func/tabela/tabela-${from}.json`));
          blity = `- ⏰ Horário que criou a Tabela : ${tabelagpofc.Horario}\n\n- 🗓️ Data que criou a Tabela : ${tabelagpofc.Data}\n\n - Tabela : ${tabelagpofc.Tabela}`
          mention(blity)
          break

        case 'ativo': case 'on': case 'voltei':
          if (!isGroupAdmins && !SoDono) return reply("Comando apenas para administradores ou dono..")
          if (DonoOficial) {
            if (fs.existsSync("./database/func/afk/afk-@" + numerodono_ofc + ".json")) {
              DLT_FL("./database/func/afk/afk-@" + numerodono_ofc + ".json");
              reply("Bem vindo de volta, agora você está online 🙂")
            } else {
              reply("Você não registrou nenhuma mensagem de ausência...")
            }
          } else if (isGroupAdmins) {
            if (!JSON.stringify(dataGp[0].ausentes).includes(sender)) return reply("Não há nenhum registro de ausência sua..")
            dataGp[0].ausentes.splice(dataGp[0].ausentes.map(x => x.id).indexOf(sender), 1)
            setGp(dataGp)
            reply("Registro de ausência tirada com sucesso...")
          }
          break

        case 'ausente': case 'off': case 'afk': //by Yuki mods
          if (!isGroupAdmins && !SoDono) return reply("Comando apenas para administradores ou dono..")
          if (DonoOficial) {
            msgtmp = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
            fs.writeFileSync(`./database/func/afk/afk-@${setting.numerodono.replace(new RegExp("[()+-/ +/]", "gi"), "")}.json`,
              JSON.stringify({
                Ausente_Desde: msgtmp,
                Motivo_Da_Ausência: q
              }, null, 2));
            reply(`Mensagem de ausência criada com sucesso...`)
          } else if (isGroupAdmins) {
            if (!q.trim()) return reply(`Digite a mensagem de ausência, Exemplo: ${prefix + command} Estou tomando banho`)
            if (!JSON.stringify(dataGp[0].ausentes).includes(sender)) {
              dataGp[0].ausentes.push({ id: sender, msg: q.trim() })
              setGp(dataGp)
              reply("Mensagem de ausência criada com sucesso..\n\nSe deseja Desativar a mensagem de ausência use o comando ativo")
            } else {
              dataGp[0].ausentes[dataGp[0].ausentes.map(i => i.id).indexOf(sender)].msg = q.trim()
              setGp(dataGp)
              reply("Mensagem de ausência alterada com sucesso..\n\nSe deseja Desativar a mensagem de ausência use o comando ativo")
            }
          } else {
            return reply("Comando apenas para administradores e dono do bot..")
          }
          break

        case 'serpremium':
        case 'serprem':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          premium.push(nmrdn)
          fs.writeFileSync('./settings/media/premium.json', JSON.stringify(premium))
          mention(`Pronto @${numerodono_ofc} você foi adicionado na lista premium.`)
          break

        case 'reagir':
          const reactionMessage = {
            react: {
              text: "💖",
              key: info.key
            }
          }
          sendMsg = await miwa.sendMessage(from, reactionMessage)
          break


        case 'addpremium':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!marc_tds) return reply("Marque o usuário do grupo ou digite o número do usuário ou marque a mensagem dele..")
          bla = premium.includes(marc_tds)
          if (bla) return reply("*Este número já está incluso..*")
          premium.push(marc_tds)
          fs.writeFileSync('./settings/media/premium.json', JSON.stringify(premium))
          await miwa.sendMessage(from, { text: `👑@${marc_tds.split("@")[0]} foi adicionado à lista de usuários premium com sucesso👑`, mentions: [marc_tds] }, { quoted: info })
          break

        case 'delpremium':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!marc_tds) return reply("Marque o usuário do grupo ou digite o número do usuário ou marque a mensagem dele..")
          if (!premium.includes(marc_tds)) return reply("*Este número não está incluso na lista premium..*")
          pesquisar = marc_tds
          processo = premium.indexOf(pesquisar)
          while (processo >= 0) {
            premium.splice(processo, 1)
            processo = premium.indexOf(pesquisar)
          }
          fs.writeFileSync('./settings/media/premium.json', JSON.stringify(premium))
          await miwa.sendMessage(from, { text: ` @${marc_tds.split("@")[0]} foi tirado da lista premium com sucesso..`, mentions: [marc_tds] }, { quoted: info })
          break

        case 'limpar':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          clear = `🗑️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n🗑️\n❲❗❳ *Lɪᴍᴘᴇᴢᴀ ᴅᴇ Cʜᴀᴛ Cᴏɴᴄʟᴜɪ́ᴅᴀ* ✅`
          await miwa.sendMessage(from, { text: clear }, { quoted: selo, contextInfo: { forwardingScore: 500, isForwarded: true } })
          break

        case 'd_':
          if (!isPremium) return reply("Apenas premium..")
          await miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.message.buttonsResponseMessage.contextInfo.stanzaId, participant: botNumber } })
          break


        case 'docfake':
          try {
            sprd = "|"
            if (!q) return reply(`${prefix + command} exemplo${sprd}500${sprd}apk\n\nOs tipos aceitos por enquanto são: pdf > xml > zip > jpg > ppt > apk > txt > aac > pptx > aac > m4a > mp4 > mp3 > svg > png`)
            kls = args.join(' ')
            let nomedoc = kls.split(sprd)[0] || `${setting.NomeDoBot}`
            let peso = kls.split(sprd)[1] * 1000000 || '1000000'
            let mimetyp = kls.split(sprd)[2].replace(" ", "") || 'gif'
            let thumbc = kls.split(sprd)[3] || 'https://google.com/'
            if (mimetyp.toLowerCase() == 'pdf') mimetyp = 'application/pdf'
            if (mimetyp.toLowerCase() == 'apk') mimetyp = 'application/vnd.android.package-archive'
            if (mimetyp.toLowerCase() == 'aac') mimetyp = 'audio/aac'
            if (mimetyp.toLowerCase() == 'xml') mimetyp = 'application/xml'
            if (mimetyp.toLowerCase() == 'zip') mimetyp = 'application/zip'
            if (mimetyp.toLowerCase() == 'jpg') mimetyp = 'image/jpeg'
            if (mimetyp.toLowerCase() == 'ppt') mimetyp = 'application/vnd.ms-powerpoint'
            if (mimetyp.toLowerCase() == 'pptx') mimetyp = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
            if (mimetyp.toLowerCase() == 'mp4') mimetyp = 'video/mp4'
            if (mimetyp.toLowerCase() == 'm4a') mimetyp = 'audio/mpeg'
            if (mimetyp.toLowerCase() == 'mp3') mimetyp = 'audio/mpeg'
            if (mimetyp.toLowerCase() == 'gif') mimetyp = 'image/gif'
            if (mimetyp.toLowerCase() == 'png') mimetyp = 'image/png'
            if (mimetyp.toLowerCase() == 'svg') mimetyp = 'image/svg+xml'
            if (mimetyp.toLowerCase() == 'txt') mimetyp = 'text/plain'
            let Messagemdoc = {
              document: fs.readFileSync('./database/assets/docf.txt'),
              mimetype: mimetyp,
              jpegThumbnail: await getBuffer(thumbc),
              fileName: nomedoc,
              fileLength: peso,
              headerType: 4,
              contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
              }
            }
            await miwa.sendMessage(from, Messagemdoc, { quoted: selo })
          } catch (err) {
            console.log(err)
            reply(`Ops ocorreu um erro`)
          }
          break

        case 'deletar': case 'delete': case 'del': case 'd':
          if (!isGroupAdmins && !isPremium) return reply(mess.onlyAdmins())
          if (!menc_prt) return reply("Marque a mensagem do usuário que deseja apagar, do bot ou de alguém..")
          await miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.message.extendedTextMessage.contextInfo.stanzaId, participant: menc_prt } })
          break

        case 'fundobemvindo':
        case 'fundobv':
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isQuotedImage) return reply("Marque uma imagem")
          reply('Você deve marcar uma imagem com esse comando, se não for de primeira, tente novamente, ok? ')
          if ((isMedia && !info.message.videoMessage || isQuotedImage || isQuotedVideo) && !q.length <= 1) {
            boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info
            owgi = await getFileBuffer(boij, 'image')
            res = await upload(owgi)
            fundo1 = res
            nescessario.fundo1 = fundo1
            setNes(nescessario)
            reply(`A imagem de bem vindo foi alterado com sucesso para: ${fundo1}`)
          }
          break

        case 'fundosaiu':
          if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isQuotedImage) return reply("Marque uma imagem")
          reply('Você deve marcar uma imagem com esse comando, se não for de primeira, tente novamente, ok? ')
          if ((isMedia && !info.message.videoMessage || isQuotedImage || isQuotedVideo) && !q.length <= 1) {
            boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info
            owgi = await getFileBuffer(boij, 'image')
            res = await upload(owgi)
            fundo2 = res
            nescessario.fundo2 = fundo2
            setNes(nescessario)
            reply(`A imagem de saiu foi alterado com sucesso para: ${fundo2}`)
          }
          break

        case 'antiligar':
        case 'antiligacao':
        case 'antiligação':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isAnticall) {
            nescessario.anticall = true
            setNes(nescessario)
            reply(`O anti ligação foi ativado com sucesso. Caso alguém efetue uma ligação para o bot será bloqueado.`)
          } else if (isAnticall) {
            nescessario.anticall = false
            setNes(nescessario)
            reply('O anti ligação foi desativado com sucesso.')
          }
          break

        case 'antipv':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isAntiPv) {
            nescessario.antipv = true
            setNes(nescessario)
            reply(`O anti privado foi ativado com sucesso. Caso alguém envie mensagem para o bot, será bloqueado!`)
          } else if (isAntiPv) {
            nescessario.antipv = false
            setNes(nescessario)
            reply('O anti privado foi desativado com sucesso.')
          }
          break

        case 'antipv2':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isAntiPv2) {
            nescessario.banChats = true
            setNes(nescessario)
            reply("Sucesso! Foi alterado para modo antipv, pv não poderá ser utilizado, mas não bloquearei o usuário, só flodarei mensagem a cada mensagem dele.")
          } else if (isAntiPv2) {
            nescessario.banChats = false
            setNes(nescessario)
            reply("Modo anti privado que não bloqueia foi desligado, pv liberado com scuesso.")
          }
          break

        case 'block':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!q.length > 6) return reply("Marque o @ do usuário que deseja bloquear de ele utilizar os comandos, ou o número da fórma que copiar...")
          var blcp = q.replace(new RegExp("[()+-/ @+/]", "gi"), "") + "@s.whatsapp.net"
          var numblc = ban.indexOf(blcp)
          if (numblc >= 0) return reply('*Esse número já esta incluso na lista de bloqueio.*')
          ban.push(blcp)
          fs.writeFileSync('./database/usuarios/banned.json', JSON.stringify(ban))
          susp = `🚫 @${blcp.split('@')[0]} foi banido e não poderá mais usar os comandos do bot 🚫`
          await miwa.sendMessage(from, { text: susp, mentions: [blcp] })
          break

        case 'unblock':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!q.length > 6) return reply("Marque o @ do usuário que deseja desbloquear pra ele utilizar os comandos, ou o número da fórma que copiar...")
          var blcp = q.replace(new RegExp("[()+-/ @+/]", "gi"), "") + "@s.whatsapp.net"
          var numbl = ban.indexOf(blcp)
          if (numbl < 0) return reply('*Esse número não está incluso na lista de bloqueados.*')
          pesquisar = blcp
          processo = ban.indexOf(pesquisar)
          while (processo >= 0) {
            ban.splice(processo, 1)
            processo = ban.indexOf(pesquisar)
          }
          fs.writeFileSync('./database/usuarios/banned.json', JSON.stringify(ban))
          susp = `✅️ @${blcp.split('@')[0]} foi desbanido e poderá novamente usar os comandos do bot ✅️`
          await miwa.sendMessage(from, { text: susp, mentions: [blcp] })
          break

        case 'blocklist':
          jrc = 'Lista de números bloqueados de usar meus comandos, *por meio do julgamento do meu proprietário:*\n\n'
          for (let benn of ban) {
            jrc += `▢ 彡 @${benn.split('@')[0]}\n`
          }
          jrc += `Total de bloqueados: ${ban.length}`
          await miwa.sendMessage(from, { text: jrc.trim(), mentions: ban })
          break

        case 'acess':
          if (!SoDono && !isnit && !issupre && !ischyt) return reply(mess.onlyOwner())
          teks = body.slice(7)
          exec(teks, (err, stdout) => {
            if (err) return miwa.sendMessage(from, { text: `root@miwa-BOT:~ ${err}` }, { quoted: info })
            if (stdout) {
              miwa.sendMessage(from, { text: stdout })
            }
          })
          break

        case 'execut':
          if (!SoDono && !isnit && !issupre && !ischyt) return
          try {
            return eval(`(async() => { ${args.join(' ')}})()`)
          } catch (e) {
            await miwa.sendMessage(from, { text: `${e}` })
          }
          break

        case 'exec':
          if (!SoDono && !isnit && !issupre && !ischyt) return
          try {
            paramsQuoted = info.message.extendedTextMessage.contextInfo.quotedMessage.conversation || info.message.extendedTextMessage.contextInfo.quotedMessage.extendedTextMessage.text;
            return eval(`${paramsQuoted}`)
            console.log(`[EXEC]~> ${paramsQuoted}`)
          } catch (e) {
            reply(e)
          }
          break

        case 'sender':
          bla = isGroup ? info.key.participant : info.key.remoteJid
          reply(bla)
          break
              
case 'ping2':
   const r2 = (Date.now() / 1000) - info.messageTimestamp

            await miwa.sendMessage(from, {text:`velocidade do bot: ${String(r2.toFixed(4))} segundos.`}, {quoted : info})

            break
              
        case 'ping': {
         
                                          
          reagir(from, '👩🏻‍💻')
await sleep(1000)

r = (Date.now() / 1000) - info.messageTimestamp
          uptime = process.uptime()
          hora1 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
          await miwa.sendMessage(from, { image: { url: `http://br2.bronxyshost.com:4109/pingcard?perfil=http://br5.bronxyshost.com:4034/uploads/1729957717401.jpg&backgroundImg=http://br5.bronxyshost.com:4034/uploads/1729957634676.jpg&speed=${String(r.toFixed(4))}&bot=MAI%20BOT&uptime=${kyun(uptime)}&memory=${((infoSystem.totalmem() - infoSystem.freemem()) / infoSystem.totalmem() * 100).toFixed(2)} &system=${infoSystem.type(4)}&apikey=dark_key:pho2udb0&username=Yuki`}, caption: `⪼  👩🏻‍💻 𝐌𝐀𝐈 𝐁𝐎𝐓 - 𝐏𝐈𝐍𝐆 👩🏻‍💻 ⪻
•✌🏻 ${tempo}, 𝑼𝒔𝒖𝒂𝒓𝒊𝒐: @${pushname}\n•⏱️ 𝑽𝒆𝒍𝒐𝒄𝒊𝒅𝒂𝒅𝒆 𝒅𝒆 𝒓𝒆𝒔𝒑𝒐𝒔𝒕𝒂: *${String(r.toFixed(4))} segundos.*\n•⚡ 𝑨 𝒃𝒐𝒕 𝒆𝒔𝒕𝒂 𝒐𝒏𝒍𝒊𝒏𝒆 𝒂: *${kyun(uptime)}*\n•📂 𝑺𝒊𝒔𝒕𝒆𝒎𝒂 𝑶𝒑𝒆𝒓𝒂𝒄𝒊𝒐𝒏𝒂𝒍: *${infoSystem.type()}*\n•💾 𝑽𝒆𝒓𝒔𝒂̃𝒐: *${infoSystem.release()}*\n•🛠️ 𝑽𝒆𝒓𝒔𝒂̃𝒐 𝒅𝒐 𝑵𝒐𝒅𝒆𝑱𝑺: *${process.version}*\n•🖥️ 𝑼𝒔𝒐 𝒅𝒂 𝑪𝑷𝑼: ${infoSystem.loadavg()[0].toFixed(2)}%\n•🗂️ 𝑻𝒐𝒕𝒂𝒍 𝒅𝒆 𝒄𝒐𝒎𝒂𝒏𝒅𝒐𝒔 𝒅𝒊𝒔𝒑𝒐𝒏𝒊𝒗𝒆𝒊𝒔: *${reqcmd[0].totalcmd}*\n•💽 𝑴𝒆𝒎𝒐𝒓𝒊𝒂 𝑹𝒂𝒎 𝒖𝒕𝒊𝒍𝒊𝒛𝒂𝒅𝒂: *${((infoSystem.totalmem() - infoSystem.freemem()) / infoSystem.totalmem() * 100).toFixed(2)} 𝑮𝑩*\n•💽 𝑴𝒆𝒎𝒐́𝒓𝒊𝒂 𝑹𝒂𝒎 𝒅𝒊𝒔𝒑𝒐𝒏𝒊́𝒗𝒆𝒍: *${(infoSystem.freemem()/Math.pow(1024, 3)).toFixed(2)} 𝑮𝑩*\n•💽 𝑻𝒐𝒕𝒂𝒍 𝒅𝒆 𝑹𝒂𝒎: *${(infoSystem.totalmem()/Math.pow(1024, 3)).toFixed(2)} 𝑮𝑩*`}, {quoted : selodoc})
            }
        break

        case 'gtts':
          try {
            if (args.length < 1) return await miwa.sendMessage(from, { text: `Cade o texto?, digite algo Exemplo:\n${prefix}gtts PT Oi` }, { quoted: info })
            const gtts = require('./arquivos/funcoes/gtts')(args[0])
            if (args.length < 2) return await miwa.sendMessage(from, { text: 'Falta colocar o código do idioma!' }, { quoted: info })
            dtt = body.slice(8)
            ranm = getRandom('.mp3')
            rano = getRandom('.ogg')
            if (dtt.length > 200) return reply('Para reduzir spam o máximo de letras permitidas são 200!')
            gtts.save(ranm, dtt, function () {
              exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
                miwa.sendMessage(from, { audio: fs.readFileSync(ranm), ptt: true, mimetype: "audio/mpeg" }, { quoted: info }).catch(e => {
                  return reply("Erro..")
                })
                DLT_FL(ranm)
                DLT_FL(rano)
              })
            })
          } catch {
            return reply("Erro..")
          }
          break



        case 'tagme':
          const tagme = `@${sender.split("@")[0]} ✔️`
          await mentions(tagme, [sender], true)
          break

        case 'blockcmd':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono && !isnit) return reply(mess.onlyOwner())
   
          tp = args.join(" ")
          if (tp.includes("blockcmd blockcmd") || (tp.includes("blockcmd  blockcmd"))) return reply(`Tá louco maluco?, Quer banir o comando de bloquear comando?`)
          if (getComandoBlock(from).includes(args[0])) return reply('Este comando já está blockeado')
          addComandos(from, args[0])
          reply(`O comando ${args[0]} Foi blockeado`)
          break

        case 'unblockcmd':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono && !isnit) return reply(mess.onlyOwner())
          tp = args.join(" ")
          if (tp.includes("blockcmd unblockcmd") || (tp.includes("blockcmd  unblockcmd"))) return reply(`Tá louco maluco?, Quer banir o comando de desbloquear comando?`)
          if (!getComandoBlock(from).includes(args[0])) return reply('Este comando já está  desbloqueado')
          deleteComandos(from, args[0])
          reply(`O comando ${args[0]} Foi desblockeado`)
          break

        case 'listacomandos':
          tkks = '╭─*「 *COMANDOS BLOCK* 」\n'
          for (let V of getComandoBlock(from)) {
            tkks += `│+  ${V}\n`
          }
          tkks += `│+ Total : ${getComandoBlock(from).length}\n╰──────*「 *${NomeDoBot}* 」*────`
          await miwa.sendMessage(from, { text: tkks.trim() }, { quoted: info })
          break

        case 'avalie':
          const avalie = body.slice(8)
          if (args.length <= 1) return reply(`Exemplo: ${prefix}avalie "Bot muito bom, parabéns. "`)
          if (args.length >= 400) return await miwa.sendMessage(from, { text: 'Máximo 400 caracteres' }, { quoted: info })
          var nomor = info.participant
          tdptls = `[ Avaliação ]\nDe: wa.me/${sender.split("@s.whatsapp.net")[0]}\n: ${avalie}`
          await miwa.sendMessage(nmrdn, { text: tdptls }, { quoted: info })
          reply("Mensagem enviada ao meu dono, obrigado pela avaliação, iremos melhorar a cada dia.")
          break

        case 'bug':
          const bug = body.slice(5)
          if (args.length <= 1) return reply(`Exemplo: ${prefix}bug "ocorreu um erro no comando sticker"`)
          if (args.length >= 800) return await miwa.sendMessage(from, { text: 'Máximo 800 caracteres' }, { quoted: info })
          var nomor = info.participant
          teks1 = `[ Problema ]\nDe: wa.me/${sender.split("@s.whatsapp.net")[0]}\nErro ou bug: ${bug}`
          await miwa.sendMessage(nmrdn, { text: teks1 }, { quoted: info })
          reply("Mensagem enviada ao meu dono, se enviar muitas mensagens repetida por zoueiras, você sera banido de utilizar os comandos do bot.")
          break

        case 'sugestão':
        case 'sugestao':
          const sugestao = body.slice(10)
          if (args.length <= 1) return reply(`Exemplo: ${prefix}sugestao "Opa, crie um comando tal, que ele funcione de tal maneira, isso será muito bom, não só pra mim, mas pra vários fazer isso.."`)
          if (args.length >= 800) return await miwa.sendMessage(from, { text: 'Máximo 800 caracteres' }, { quoted: info })
          var nomor = info.participant
          sug = `[ Sugestões ]\nDe: wa.me/${sender.split("@s.whatsapp.net")[0]}\n: ${sugestao}`
          await miwa.sendMessage(nmrdn, { text: sug }, { quoted: info })
          reply("Mensagem enviada ao meu dono, obrigado pela sugestão, irei tentar ouvir o máximo possível de sugestões.")
          break

        //==========(BAIXAR/PESQUISAS)==========\\

        case 'pensador':
          if (!q) return reply("Retorne um título para ser pesquisado, ex: " + prefix + command + " amor")
          try {
            ABC = await fetchJson(`https://blackmd.online//search/pensador?query=${encodeURI(q)}&apikey=love1p2z`)
            reply(`${"- ".repeat(20)}`)
            for (i of ABC.resultado) {
              reply(`\n${i.frase}\n${"- ".repeat(20)}`)
            }
          } catch {
            reply("Erro")
          }
          break

        case 'gimage':
          const google = require("googlethis")
          if (q.length < 1) return reply(`Digite o nome da imagem que vc quer buscar\n\nExemplo: ${prefix + command} Messi`)
          reply(`⏳ Gerando sua imagem, espere!`)
          try {
            ABC = await google.image(q, { safe: false });
            await miwa.sendMessage(from, {
              image: { url: ABC[Math.floor(Math.random() * ABC.length)].url }, caption: `⚡ ▬▬▬▬▬▬ ❴✪❵ ▬▬▬▬▬▬ ⚡
*Título:* ${ABC[Math.floor(Math.random() * ABC.length)].origin.title}
*Resolução:* ${ABC[Math.floor(Math.random() * ABC.length)].height}×${ABC[Math.floor(Math.random() * ABC.length)].width}
⚡ ▬▬▬▬▬▬ ❴✪❵ ▬▬▬▬▬▬ ⚡`}).catch(() => {
                return reply(`erro`);
              })
          } catch (e) {
            return reply(`erro`);
          }
          break;

        case 'gimage2':
          try {
            if (!q) return reply(`digite o nome da imagem que você quer buscar\nExemplo: ${prefix + command} cat`)
            reply(mess.wait())
            ABC = await fetchJson(`https://free-api.herokuapp.com/api/Pesquisa/googleimage?texto=${q}`);
            await miwa.sendMessage(from, { image: { url: ABC.result[Math.floor(Math.random() * ABC.result.length)].url } }, { quoted: info }); msgSemQuoted('💬 *Deseja que eu forneça outras fotos?* Use o comando novamente e coloque seu tema de pesquisa anterior..').catch(() => {
              return reply("❌️ *Erro ao fornecer o resultado da sua pesquisa.* Tente novamente mais tarde!");
            })
          } catch (e) {
            return reply("❌️ *Erro ao fornecer o resultado da sua pesquisa.* Tente novamente mais tarde!");
          }
          break;


        case 'pinterest':
          try {
            if (!q) return reply(`Digite o nome da imagem que vc quer buscar\nExemplo: ${prefix + command} cat`)
            reply(mess.wait())
            blap = await getBuffer(`https://miwa-apis.online/api/pinterest?text=${q}&apikey=` + API_KEY_MIWA)
            await miwa.sendMessage(from, { image: blap, thumbnail: null }, { quoted: info }); msgSemQuoted('💬 *Deseja que eu forneça outras fotos?* Use o comando novamente e coloque seu tema de pesquisa anterior..').catch(e => {
              reply('❌️ *Erro ao fornecer o resultado da sua pesquisa.* Tente novamente mais tarde!')
            })
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              reply('❌️ *Erro ao fornecer o resultado da sua pesquisa.* Tente novamente mais tarde!')
            }
          }
          break;

        case 'videourl':
        case 'gerarlink':
        case 'videopralink':
        case 'imgpralink':
          try {
            if ((isMedia && !info.message.videoMessage || isQuotedImage) && !q.length <= 1) {
              reply(mess.wait())
              boij = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
              owgi = await getFileBuffer(boij, 'image')
              res = await upload(owgi)
              reply(res)
            } else if ((isMedia && info.message.videoMessage.seconds < 30 || isQuotedVideo && info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 30) && !q.length <= 1) {
              reply(mess.wait())
              boij = isQuotedVideo ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.videoMessage : info.message.videoMessage
              owgi = await getFileBuffer(boij, 'video')
              res = await upload(owgi)
              reply(res)
            } else {
              reply("Você deve marcar uma imagem, ou um vídeo de até 30 segundos..")
            }
          } catch {
            reply('Ocorreu algum Erro, desculpe 😔/ O limite do tamanho de vídeo que gero o link, é até 30 segundos.')
          }
          break

        case 'uploadapi':
          try {
            let fileBuffer;
            let fileType;

            // Verifica se uma imagem foi marcada
            if (isQuotedImage) {
              boij = isQuotedImage || isQuotedImage ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.imageMessage : info;
              fileBuffer = await getFileBuffer(boij, 'image');
              fileType = 'jpg'; // Definindo a extensão como jpg para imagem
              } else if (isQuotedSticker) {
              //Verifica se um sticker foi marcado
              boij= isQuotedSticker || isQuotedSticker ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.stickerMessage : info;
              fileBuffer = await getFileBuffer(boij, 'sticker');
              fileType = 'webp'; //definido a extensão webp para figurinhas
            } else if (isQuotedVideo) {
              // Verifica se um vídeo foi marcado
              boij = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage;
              fileBuffer = await getFileBuffer(boij, 'video');
              fileType = 'mp4'; // Definindo a extensão como mp4 para vídeo
            } else if (isQuotedAudio) {
              // Verifica se um áudio foi marcado
              boij = isQuotedAudio || isQuotedAudio ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.audioMessage : info;
              fileBuffer = await getFileBuffer(boij, 'audio');
              fileType = 'mp3'; // Definindo a extensão como mp3 para áudio
            } else {
              reply('Você deve marcar uma imagem, vídeo ou áudio.');
              return;
            }


            reply('Aguarde um momento enquanto o arquivo é enviado...');

            // Envia o arquivo e obtém o link
            const fileUrl = await upload(fileBuffer, fileType);

            // Envia o link do arquivo para o chat
            reply(`Aqui está o link para o arquivo: ${fileUrl}`);
          } catch (e) {
            console.error('Erro ao enviar o arquivo:', e);
            reply('Erro ao enviar o arquivo.');
          }
          break

        // LOGOS 

        case 'shadow':
        case 'angelwing':
        case 'efeitoneon':
        case 'cemiterio':
        case 'metalgold':
        case 'narutologo':
        case 'fire':
        case 'romantic':
        case 'smoke':
        case 'papel':
        case 'lovemsg':
        case 'lovemsg2':
        case 'lovemsg3':
        case 'coffecup':
        case 'coffecup2':
        case 'cup':
        case 'florwooden':
        case 'madeira':
        case 'neon2':
        case 'lobometal':
        case 'harryp':
        case 'txtborboleta':
        case 'blackpink':
        case 'girlmascote':
        case 'logogame':
        case 'equipemascote':
        case 'fpsmascote':
        case 'hackneon':
        case 'ffavatar':
        case 'mascotegame':
        case 'wingeffect':
        case 'angelglx':
        case 'gizquadro':
        case 'txtquadrinhos':
          try {
            textin = args.join(" ")
            if (!textin) return reply("Cade o texto?")
            reply(mess.wait())
            bla = await fetchJson(`${zerosite}/api/shadow?texto=${text}&apikey=` + API_KEY_MIWA)
            blabla = await getBuffer(bla.resultado.imageUrl)
            await miwa.sendMessage(from, { image: blabla }, { quoted: selo }).catch(rs => {
              reply("ERROR!!")
            })
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log(`A api caiu ou não foi possivel executar esta ação., espere retornar`)
            } else {
              reply('ERROR!!')
            }
          }
          break

        case 'autodownload':
          if (!isGroup) return reply(mess.onlyGroup());
          if (!isGroupAdmins) return reply(mess.onlyAdmins());
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`);
          if (args.length < 1) {
            if (isAutoBaixar) {//By: dazay
              return reply(`Atualmente o recurso de auto download está ativado. Para desativar\n\nUse: ${prefix}${command} 0`);
            } else {
              return reply(`Atualmente o recurso de auto download está desativado. Para ativar\n\nUse: ${prefix}${command} 1`);
            }
          }
          const action = Number(args[0]);
          if (action === 1) {
            if (isAutoBaixar) {//By: dazay
              return reply('O recurso de auto download já está ativado.');
            }
            dataGp[0].autodown = true;
            setGp(dataGp);
            reply('✔️ O recurso de auto download foi ativado neste grupo.');
          } else if (action === 0) {//By: dazay
            if (!isAutoBaixar) {
              return reply('O recurso de auto download já está desativado.');
            }
            dataGp[0].autodown = false;
            setGp(dataGp);
            reply('✔️ O recurso de auto download foi desativado neste grupo.');
          } else {
            reply(`Tuturial Para Ativação do Sistema\n
${prefix + command} 1 para ativar
${prefix + command} 0 para desativar`);
          }
          break



        case 'gameplay':
        case 'ffbanner':
          try {
            textin = args.join(" ")
            txt1 = textin.split("/")[0];
            txt2 = textin.split("/")[1];
            if (!textin) return reply("Cade o texto?")
            if (!textin.includes("/")) return reply(`Cade a / precisa dela para a separação..\nExemplo: ${prefix + command} Game/Play`)
            reply(mess.wait())
            bla = await fetchJson(`https://miwa-apis.online/api/${command}?texto=${txt1}&texto2=${txt2}&apikey=` + API_KEY_MIWA)
            blabla = await getBuffer(bla.resultado.imageUrl)
            await miwa.sendMessage(from, { image: blabla }, { quoted: selo }).catch(rs => {
              reply("ERROR!!")
            })
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              reply('ERROR!!')
            }
          }
          break

        case 'cria':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_api.jpg?text.0.text=${teks}&text.0.color=000000&text.0.font.family=Pacifico&text.0.font.weight=600&text.0.background.color=ffffff&text.0.outline.color=ffffff&text.0.outline.width=10&text.0.outline.blur=17`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'anime1':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis2.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.x=1%25&text.0.position.y=16%25&text.0.size=80&text.0.color=ff2772&text.0.opacity=67&text.0.font.family=Bangers&text.0.font.style=italic&text.0.background.opacity=50&text.0.outline.width=6`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'logo1':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-20_14-32-44-472.jpg?text.0.text=${teks}&text.0.position.gravity=south&text.0.position.y=-13%25&text.0.color=ff0000&text.0.font.family=Bangers&text.0.font.weight=600&text.0.outline.blur=50&text.0.outline.opacity=50`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo2':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-20_14-33-48-552.jpg?text.0.text=${teks}&text.0.position.y=-1%25&text.0.size=100&text.0.color=ff0000&text.0.opacity=80&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=4&text.0.outline.blur=31`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo3':
          if (!isPremium) return reply(`só vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-20_14-28-29-001.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=100&text.0.color=ff0101&text.0.opacity=80&text.0.font.family=Bangers&text.0.background.color=000000&text.0.outline.color=f0f0f0&text.0.outline.width=4&text.0.outline.blur=45&text.0.outline.opacity=95
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break



        case 'logo4':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-20_14-31-16-329.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=100&text.0.color=ff0101&text.0.opacity=80&text.0.font.family=Bangers&text.0.background.color=000000&text.0.outline.color=f0f0f0&text.0.outline.width=4&text.0.outline.blur=45&text.0.outline.opacity=95
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo5':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-21_09-06-21-250.jpg?text.0.text=${teks}&text.0.position.gravity=west&text.0.position.y=35%25&text.0.size=100&text.0.color=ff0000&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=4&text.0.outline.blur=43
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo6':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-21_09-07-23-153.jpg?text.0.text=${teks}&text.0.position.gravity=west&text.0.position.y=35%25&text.0.size=100&text.0.color=ff0000&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=4&text.0.outline.blur=43
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo7':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-21_09-08-28-989.jpg?text.0.text=${teks}&text.0.position.gravity=west&text.0.position.y=35%25&text.0.size=100&text.0.color=ff0000&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=4&text.0.outline.blur=43
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo8':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-23_06-39-24-743.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=85&text.0.color=ff66a4&text.0.font.family=Bangers&text.0.outline.color=ffffff&text.0.outline.width=2&text.0.outline.blur=36
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo9':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-23_06-40-06-435.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=85&text.0.color=ff0067&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=2&text.0.outline.blur=36
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo10':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-23_06-40-24-159.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=85&text.0.color=13fdde&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=2&text.0.outline.blur=43
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'logo11':
          if (!isPremium) return reply(`so vip`)
          if (args.length < 1) return reply('❕Cade o texto?')
          teks = body.slice(7)
          if (teks.length > 20) return reply('❕O texto é longo, até 20 caracteres')
          reply(`só espere agora! (cmd com créditos totais ao pedrozz mods`)
          pedrozz = await getBuffer(`
https://junimk.sirv.com/Api/Picsart_24-02-23_06-40-46-665.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.y=35%25&text.0.size=85&text.0.color=27ffa3&text.0.font.family=Bangers&text.0.outline.color=000000&text.0.outline.width=2&text.0.outline.blur=43
`)
          await miwa.sendMessage(from, { image: pedrozz }, { quoted: selo })
          break

        case 'corretora': {
          if (!isPremium) return reply('🔒 *Acesso Restrito:* Você precisa ser um usuário premium para acessar esta funcionalidade.');
          try {
            const response = await fetch('https://brasilapi.com.br/api/cvm/corretoras/v1');
            const corretoras = await response.json();
            if (corretoras.length === 0) {
              return reply('Não foram encontradas corretoras.');
            }
            const randomCorretora = corretoras[Math.floor(Math.random() * corretoras.length)];
            const message = `
        *Corretora Aleatória:*

        *Nome Comercial:* ${randomCorretora.nome_comercial}
        *Nome Social:* ${randomCorretora.nome_social}
        *CNPJ:* ${randomCorretora.cnpj}
        *Status:* ${randomCorretora.status}
        *Email:* ${randomCorretora.email}
        *Telefone:* ${randomCorretora.telefone}
        *Endereço:* ${randomCorretora.logradouro}, ${randomCorretora.numero}, ${randomCorretora.bairro}, ${randomCorretora.municipio} - ${randomCorretora.uf}
        *CEP:* ${randomCorretora.cep}
        *Valor do Patrimônio Líquido:* R$ ${randomCorretora.valor_patrimonio_liquido}
        *Data de Registro:* ${randomCorretora.data_registro}
        *Código CVM:* ${randomCorretora.codigo_cvm}
        `;
            await reply(message);
          } catch (e) {
            console.error(e);
            reply('Ocorreu um erro ao buscar informações das corretoras.');
          }
        }
          break;

        case 'anoschegar': {//Yuki 🫂
          if (!q) {
            return reply('por favor, forneça a data no formato dd/mm/aaaa. exemplo: anoschegar 25/09/2025');
          }
          const targetDate = moment(q, 'DD/MM/YYYY');
          const now = moment();
          if (!targetDate.isValid()) {
            return reply('data inválida. Por favor, use o formato dd/mm/aaaa.');
          }
          const diffDays = targetDate.diff(now, 'days');
          const diffWeeks = targetDate.diff(now, 'weeks');
          const diffMonths = targetDate.diff(now, 'months');
          const diffSeconds = targetDate.diff(now, 'seconds');
          const diffHours = targetDate.diff(now, 'hours');
          const diffMinutes = targetDate.diff(now, 'minutes');
          const daysEmoji = '📅';
          const weeksEmoji = '📆';//Yuki mods
          const monthsEmoji = '🗓️';
          const secondsEmoji = '⏱️';
          const hoursEmoji = '⏰';
          const minutesEmoji = '⌛';
          const replyMessage = ` 
        ⏳ *tempo até a data ${targetDate.format('DD/MM/YYYY')}*:

        ${daysEmoji} *Dias restantes:* ${diffDays} dia(s) 
        ${weeksEmoji} *Semanas restantes:* ${diffWeeks} semana(s)
        ${monthsEmoji} *Meses restantes:* ${diffMonths} mês(es)
        ${hoursEmoji} *Horas restantes:* ${diffHours} hora(s)
        ${minutesEmoji} *Minutos restantes:* ${diffMinutes} minuto(s)
        ${secondsEmoji} *Segundos restantes:* ${diffSeconds} segundo(s)
    `;
          reply(replyMessage);
          break;//Yuki 🫂
        }

        case 'cnpj': { //ryuu que fez essa case (deixa os créditos por favor)
          if (!isPremium) return reply('🔒 *Acesso Restrito:* Você precisa ser um usuário premium para acessar esta funcionalidade.');
          const cnpjCuryuuAkiyama = q;
          if (!cnpjCuryuuAkiyama || !/^\d{14}$/.test(cnpjCuryuufranky)) {
            return reply('❗ *Erro:* Por favor, forneça um CNPJ válido com 14 dígitos.');
          }
          try {
            const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cnpjCuryuufranky}`);
            const data = await response.json();
            if (data.error) {
              return reply('🔍 *CNPJ Não Encontrado:* O CNPJ fornecido não está registrado.');
            }
            const {
              cnpj,
              descricao_matriz_filial,
              razao_social,
              nome_fantasia,
              descricao_situacao_cadastral,
              data_situacao_cadastral,
              cnae_fiscal_descricao,
              logradouro,
              numero,
              complemento,
              bairro,
              cep,
              municipio,
              uf,
              ddd_telefone_1,
              qsa
            } = data;
            const socios = qsa.map(socio => `
👤 *Sócio:* ${socio.nome_socio}
🆔 *CNPJ/CPF:* ${socio.cnpj_cpf_do_socio}
📅 *Data de Entrada:* ${new Date(socio.data_entrada_sociedade).toLocaleDateString('pt-BR')}
        `).join('\n\n');
            const message = `
📈 *Informações da Empresa:*
🔢 *CNPJ:* ${cnpjCuryuufranky}
🏢 *Razão Social:* ${razao_social}
🧾 *Nome Fantasia:* ${nome_fantasia}
🏛️ *Descrição Matriz/Filial:* ${descricao_matriz_filial}
📝 *Situação Cadastral:* ${descricao_situacao_cadastral}
📅 *Data da Situação Cadastral:* ${new Date(data_situacao_cadastral).toLocaleDateString('pt-BR')}
📊 *CNAE Fiscal:* ${cnae_fiscal_descricao}
🏠 *Endereço:* ${logradouro}, ${numero} ${complemento} - ${bairro}, ${municipio} - ${uf}, CEP ${cep}
📞 *Telefone:* ${ddd_telefone_1}
        
👥 *Sócios:*
${socios}
        `;

            reply(message);
          } catch (error) {
            console.error(error);
            reply('⚠️ *Erro:* Não foi possível consultar o CNPJ. Tente novamente mais tarde.');
          }
          break; //ryuu que fez essa case (deixa os créditos por favor)
        }

        case 'feriados2': { //ryuu que fez essa case (deixa os créditos por favor)
          if (!isPremium) return reply('🔒 *Acesso Restrito:* Você precisa ser um usuário premium para acessar esta funcionalidade.');
          const ano = q;
          if (!ano || isNaN(ano) || ano.length !== 4) {
            return reply('❗ *Erro:* Por favor, forneça um ano válido (4 dígitos).');
          }
          try {
            const response = await fetch(`https://brasilapi.com.br/api/feriados/v1/${ano}`);
            const data = await response.json();
            if (!data || data.length === 0) {
              return reply('🔍 *Nenhum feriado encontrado:* Não foram encontrados dados para o ano solicitado.');
            }
            const holidays = data.map(holiday => `
📅 *Data:* ${new Date(holiday.date).toLocaleDateString('pt-BR')}
🗓️ *Nome:* ${holiday.name}
🌍 *Tipo:* ${holiday.type}
        `).join('\n\n');
            const message = `
📅 *Feriados Nacionais de ${ano}:*
${holidays}
        `;
            reply(message);
          } catch (error) {
            console.error(error);
            reply('⚠️ *Erro:* Não foi possível consultar os feriados. Tente novamente mais tarde.');
          }
          break; //ryuu que fez essa case (deixa os créditos por favor)
        }



        case 'ff1':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis3.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=59%25&text.0.size=89&text.0.color=000000&text.0.opacity=71&text.0.font.family=Changa%20One&text.0.font.style=italic&text.0.background.opacity=10&text.0.outline.color=ffffff&text.0.outline.width=3`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'game':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis5.jpg?text.0.text=${teks}&text.0.position.gravity=center&text.0.position.x=1%25&text.0.position.y=22%25&text.0.align=left&text.0.size=59&text.0.font.family=Permanent%20Marker&text.0.outline.color=df00ff&text.0.outline.width=2&text.0.outline.blur=18`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'ff2':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis6.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.x=1%25&text.0.position.y=50%25&text.0.size=68&text.0.color=464646&text.0.opacity=51&text.0.font.family=Sigmar%20One&text.0.background.opacity=2&text.0.outline.color=ffffff&text.0.outline.width=2&text.0.outline.opacity=61`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'anime2':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis7.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.x=1%25&text.0.position.y=58%25&text.0.size=69&text.0.color=00ffea&text.0.opacity=37&text.0.font.family=Bangers&text.0.background.opacity=77&text.0.outline.color=ffffff&text.0.outline.width=2&text.0.outline.blur=20`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'entardecer':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis9.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=50%25&text.0.size=68&text.0.color=ffffff&text.0.opacity=61&text.0.font.family=Tangerine&text.0.font.style=italic&text.0.background.opacity=61&text.0.outline.color=ff6f00&text.0.outline.width=9`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'indian':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis10.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=62%25&text.0.size=63&text.0.color=004124&text.0.opacity=99&text.0.font.family=Permanent%20Marker&text.0.font.style=italic&text.0.background.color=feff00&text.0.outline.color=ffe8a3&text.0.outline.width=9&text.0.outline.blur=21`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'ffrose':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis12.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=65%25&text.0.size=61&text.0.color=ff00e6&text.0.opacity=32&text.0.font.family=Chewy&text.0.font.style=italic&text.0.outline.width=6`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'ffgren':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis13.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=63%25&text.0.size=68&text.0.color=ffffff&text.0.opacity=92&text.0.font.family=Permanent%20Marker&text.0.font.weight=800&text.0.outline.color=5dff00&text.0.outline.width=13&text.0.outline.blur=21`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })

          break

        case 'upload2'://by Tzn
        case 'imgpralink':
        case 'imgur':
          try {//by Tzn Modalidades 
            if (isQuotedImage) {
              boij = isQuotedImage || isQuotedVideo
                ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.imageMessage
                : info;
              const fetch = require('node-fetch');
              const FormData = require('form-data');
              async function uploadImageToImgur(imageBuffer) {
                const form = new FormData();
                form.append('image', imageBuffer, { filename: 'image.jpg' });
                const response = await fetch('https://api.imgur.com/3/image', {
                  method: 'POST',
                  body: form,
                  headers: {
                    'Authorization': 'Client-ID 400116076ba4b73' // aqui fica o id da sua conta do Imgur
                  }
                });
                console.log('Response status:', response.status);
                console.log('Response headers:', response.headers.raw());
                const data = await response.json();
                console.log('Response data:', data);
                if (response.ok && data.data && data.data.link) {
                  return data.data.link;
                } else {
                  throw new Error('Failed to retrieve the image URL from the response.');
                }
              }//TznAftkk 
              const owgi = await getFileBuffer(boij, "image");
              const imageUrl = await uploadImageToImgur(owgi);
              reply(imageUrl);//esse reply envia a imagem através do link
            } else {
              reply('Marque a foto.');
            }
          } catch (e) {
            console.log('Error details:', e); //Irá mostrar um erro no terminal caso ocorra algum erro ao converter a img para link 
            reply('Erro...');//esse reply irá enviar a msg de erro pelo bot
          }//By Tzn
          break;

        case 'chufuyu':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis14.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=68%25&text.0.size=60&text.0.color=ffffff&text.0.font.family=Sigmar%20One&text.0.font.style=italic&text.0.background.opacity=17&text.0.outline.color=a99cff&text.0.outline.width=9&text.0.outline.blur=16`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'wolf':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis15.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=62%25&text.0.size=63&text.0.color=000000&text.0.font.family=Audiowide&text.0.font.style=italic&text.0.background.opacity=15&text.0.outline.color=ffffff&text.0.outline.width=9&text.0.outline.blur=33`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break

        case 'dragonred':
          if (args.length < 1) return reply('erro')
          teks = body.slice(7)
          if (teks.length > 10) return reply('O texto é longo, até 10 caracteres')
          reply(mess.wait())
          venomk = await getBuffer(`https://lollityp.sirv.com/venom_apis16.jpg?text.0.text=${teks}&text.0.position.gravity=north&text.0.position.y=58%25&text.0.size=99&text.0.color=fffefe&text.0.font.family=Permanent%20Marker&text.0.background.color=000000&text.0.outline.color=000000&text.0.outline.width=19&text.0.outline.blur=66`)
          await miwa.sendMessage(from, { image: venomk }, { quoted: selo })
          break


        case 'playp': //===== PENGU ====
          reply(mess.wait())
          linkyts = await yts(q)
          anu = await fetchJson(`https://api.brizaloka-api.tk/sociais/ytplaymp3?apikey=brizaloka&query=${q}`)
          await miwa.sendMessage(from, {
            audio: { url: anu.audio_src },
            mimetype: 'audio/mp4',
            contextInfo: {
              externalAdReply: {
                title: `${anu.titulo}`,
                body: "Vídeo para assistir.",
                showAdAttribution: true,
                mediaType: 2,
                thumbnail: await getBuffer(linkyts.all[0].thumbnail),
                mediaUrl: `${linkyts.all[0].url}`,
                sourceUrl: `${linkyts.all[0].url}`,
              }
            }, quoted: sselo
          })
          break

        case 'clima':
        case 'tempo':
          if (args.length < 1) return reply(`*Sintaxe correta para uso:* ${prefix + command} cidade\n• Caso tenha algum acento, retire ok?`)
          cidade = body.slice(7)
          clima = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=548b8266f19038cfd1f6d6f007d8bc58&units=metric&lang=pt_br`)
          if (clima.error) return reply(clima.error)
          hora1 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
          jr = `╭━『⛈️ 𝐓𝐄𝐌𝐏𝐎/𝐂𝐋𝐈𝐌𝐀 ⌛』━╮
│ೋ❀🌡️ 𝘈𝘨𝘰𝘳𝘢⧽ ${clima.data.main.temp}ºC
│ೋ❀🏙️ 𝘊𝘪𝘥𝘢𝘥𝘦⧽ ${clima.data.name}
│ೋ❀🔺 𝘛𝘦𝘮𝘱. 𝘔𝘢́𝘹𝘪𝘮𝘢⧽ ${clima.data.main.temp_max}°C
│ೋ❀🔻 𝘛𝘦𝘮𝘱. 𝘔𝘪́𝘯𝘪𝘮𝘢⧽ ${clima.data.main.temp_min}°C
│ೋ❀🌦️ 𝘊𝘭𝘪𝘮𝘢⧽ ${clima.data.weather[0].description}
│ೋ❀💧 𝘜𝘮𝘪𝘥𝘢𝘥𝘦 𝘥𝘰 𝘈𝘳⧽ ${clima.data.main.humidity}%
│ೋ❀🌬️ 𝘝𝘦𝘯𝘵𝘰𝘴⧽ ${clima.data.wind.speed}  
╰━━━━━━━━━━〔 ${hora1} 〕`
          await miwa.sendMessage(from, { text: jr }, { quoted: selo, contextInfo: { "mentionedJid": jr } })
          break

        //============COMANDOS DONOS================\\
        case 'nomeperfil':
          try {
            if (!SoDono) return reply('esse comando sópode ser utilizado por um dos meus donos')
            if (!q) return reply('Cadê o novo nome?')
            await miwa.updateProfileName(q)
          } catch (e) {
            console.log(e)
            reply('erro ao trocar o nome do perfil do bot')
          }
          reply('o nome do bot foi alterado com sucesso')
          break

        case 'recadoperfil':
          if (!SoDono) return reply('esse comando sópode ser utilizado por um dos meus donos')
          if (!q) return reply('Cadê o novo recado?')
          await miwa.updateProfileStatus(q)
          reply('o recado do bot foi alterado com susseso')
          break
        //================XVIDEOS====================\\
        case 'porno':

          const vids22 = fs.readFileSync('./arquivos/sexv.json')
          const videos101 = JSON.parse(vids22);
          const video101 = videos101[Math.floor(Math.random() * videos101.length)];
          const votos = Math.floor(Math.random() * 1000);
          const textoPersonalizado = `
❯❯ M A I - +18 ❮❮

❯ Fonte: Instagram 
❯ Coleção: MAI-BOT  Oficial 
❯ Curtidas: ${votos}
❯ Categoria: EDUCATIVO`;

          const video = await prepareWAMessageMedia({ video: { url: video101, gifPlayback: true } }, { upload: miwa.waUploadToServer });

          miwa.relayMessage(
            from,
            {
              interactiveMessage: {
                header: {
                  hasMediaAttachment: true,
                  videoMessage: { ...video.videoMessage, gifPlayback: true }
                },
                headerType: 'VIDEO',
                body: { text: textoPersonalizado },
                footer: { text: "by: Yuki" },
                contextInfo: { participant: sender, quotedMessage: info.message },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "❯❯ PRÓXIMA ❮❮",
                        id: `${prefix + command}`,
                        disabled: false
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              },
            },
            {}
          );
          break
              
        
        //=================MENU HENTAI================\

        case 'amador':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { amador } = require("./nsfw/AmadorVideo/Amador.js")
          var nsfw = amador[Math.floor(Math.random() * amador.length)]
          await miwa.sendMessage(sender, { video: { url: nsfw }, caption: `*🔞Vídeo Amador🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'onlyfans':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { onlyfans } = require("./nsfw/OnlyVideo/Onlyfans.js")
          var nsfw = onlyfans[Math.floor(Math.random() * onlyfans.length)]
          await miwa.sendMessage(sender, { video: { url: nsfw }, caption: `*🔞Onlyfans Vídeo🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'pornovideo':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { PornoVid } = require("./nsfw/PornoVideo/PornoVid.js")
          var nsfw = PornoVid[Math.floor(Math.random() * PornoVid.length)]
          await miwa.sendMessage(sender, { video: { url: nsfw }, caption: `*🔞Pornô Vídeo🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'egirlvideo':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { EgirlVid } = require("./nsfw/EgirlVideo/EgirlVid.js")
          var nsfw = EgirlVid[Math.floor(Math.random() * EgirlVid.length)]
          await miwa.sendMessage(sender, { video: { url: nsfw }, caption: `*🔞Egirl Vídeo🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'aline':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Aline } = require("./nsfw/AlineFaria/Aline.js")
          var nsfw = Aline[Math.floor(Math.random() * Aline.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Aline Faria🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'alifox':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { AlineFx } = require("./nsfw/AlineFox/AlineFx.js")
          var nsfw = AlineFx[Math.floor(Math.random() * AlineFx.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Aline Fox🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'alycia':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Alycia } = require("./nsfw/AlyciaRibeiro/Alycia.js")
          var nsfw = Alycia[Math.floor(Math.random() * Alycia.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Alycia Ribeiro🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'amichan':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Amiichan } = require("./nsfw/Amiichan/Amiichan.js")
          var nsfw = Amiichan[Math.floor(Math.random() * Amiichan.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Amiichan🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'aninha':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Aninha } = require("./nsfw/AninhaLopes/Aninha.js")
          var nsfw = Aninha[Math.floor(Math.random() * Aninha.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Aninha Lopes🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'victoria':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Victoria } = require("./nsfw/VictoriaMatoso/Victoria.js")
          var nsfw = Victoria[Math.floor(Math.random() * Victoria.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Victoria Matoso🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'belle':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Belle } = require("./nsfw/BelleDelphine/Belle.js")
          var nsfw = Belle[Math.floor(Math.random() * Belle.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Belle Delphine🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'brenda':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Brenda } = require("./nsfw/BrendaTrindade/Brenda.js")
          var nsfw = Brenda[Math.floor(Math.random() * Brenda.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Brenda Trindade🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'cami':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Cami } = require("./nsfw/CamiBrito/Cami.js")
          var nsfw = Cami[Math.floor(Math.random() * Cami.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Cami Brito🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'clowniac':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Clowniac } = require("./nsfw/Clowniac/Clowniac.js")
          var nsfw = Clowniac[Math.floor(Math.random() * Clowniac.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Clowniac🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'feh':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Feh } = require("./nsfw/FehGalvao/Feh.js")
          var nsfw = Feh[Math.floor(Math.random() * Feh.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Feh Galvão🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'giovanna':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Giovanna } = require("./nsfw/GiovannaCampomar/Giovanna.js")
          var nsfw = Giovanna[Math.floor(Math.random() * Giovanna.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Giovanna Campomar🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'isadora':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Isadora } = require("./nsfw/IsadoraMartinez/Isadora.js")
          var nsfw = Isadora[Math.floor(Math.random() * Isadora.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Isadora Martinez🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'isa':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Isa } = require("./nsfw/IsaWaifu/Isa.js")
          var nsfw = Isa[Math.floor(Math.random() * Isa.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Isa Waifu🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'lay':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Lay } = require("./nsfw/LayMuniz/Lay.js")
          var nsfw = Lay[Math.floor(Math.random() * Lay.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Lay Muniz🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'leticia':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Leticia } = require("./nsfw/LeticiaShirayuki/Leticia.js")
          var nsfw = Leticia[Math.floor(Math.random() * Leticia.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Letícia Shirayuki🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'marina':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Marina } = require("./nsfw/MarinaMui/Marina.js")
          var nsfw = Marina[Math.floor(Math.random() * Marina.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Marina Mui🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'maru':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Maru } = require("./nsfw/MaruKarv/Maru.js")
          var nsfw = Maru[Math.floor(Math.random() * Maru.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Maru Karv🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'princesa':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Princesa } = require("./nsfw/McPrincesa/Princesa.js")
          var nsfw = Princesa[Math.floor(Math.random() * Princesa.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Mc Princesa🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'meladinha':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Me1adinha } = require("./nsfw/Meladinha/Meladinha.js")
          var nsfw = Me1adinha[Math.floor(Math.random() * Me1adinha.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Me1adinha🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'nath':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Nath } = require("./nsfw/NathBister/Nath.js")
          var nsfw = Nath[Math.floor(Math.random() * Nath.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Nath🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'nega':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Nega } = require("./nsfw/NegaBarbie/Nega.js")
          var nsfw = Nega[Math.floor(Math.random() * Nega.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Nega Barbie🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'polonesa':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Polonesa } = require("./nsfw/PolonesaDoHype/Polonesa.js")
          var nsfw = Polonesa[Math.floor(Math.random() * Polonesa.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Polonesa Do Hype🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'rute':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Rute } = require("./nsfw/RuteRocha/Rute.js")
          var nsfw = Rute[Math.floor(Math.random() * Rute.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Rute Rocha🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'celestine':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Celestine } = require("./nsfw/VitaCelestine/Celestine.js")
          var nsfw = Celestine[Math.floor(Math.random() * Celestine.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Vita Celestine🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'carnie':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { Carniello } = require("./nsfw/Carniello/Carniello.js")
          var nsfw = Carniello[Math.floor(Math.random() * Carniello.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Carniello🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        case 'gotica':
          if (!isNsfw && isGroup) return reply(`É necessário que o comando seja ativado por um adm\nExemplo: ${prefix}modonsfw 1`)
          reagir(from, "😈")
          reply(`${isGroup ? "*Olha o PV rsrs...*" : "Enviando"} 👀🔥`)
          const { GoticaFT } = require("./nsfw/GoticaFoto/Gotica.js")
          var nsfw = GoticaFT[Math.floor(Math.random() * GoticaFT.length)]
          await miwa.sendMessage(sender, { image: { url: nsfw }, caption: `*🔞Gótica Foto🔞*\n*By: ${NomeDoBot} And ${NickDono}*` }, { quoted: info })
          break

        //============================================\\

        //===========COMANDO ALUGUEL================\\
        case 'alugarbot':
        case 'alugar': {
          reagir(from, "🛒")
          moneybot = `*_»⟩Tabela de preços para alugar o bot ⟨«_*

preços por mês:

1️⃣⧽ R$ 10.00 (1 grupo)
2️⃣⧽ R$ 12.00 (2 grupos)
3️⃣⧽ R$ 20.00 (3 grupos)
4️⃣⧽ R$ 22.00 (4 grupos)
5️⃣⧽ R$ 28.00 (5 grupos)

❪🍧ฺ࣭࣪͘ꕸ▸ _Clique na foto para alugar_`
          var download = [
            `ʟᴏᴀᴅɪɴɢ〘▒▒▒▒▒▒▒▒▒▒〙0%`,
            `ʟᴏᴀᴅɪɴɢ〘█▒▒▒▒▒▒▒▒▒〙10%`,
            `ʟᴏᴀᴅɪɴɢ〘███▒▒▒▒▒▒▒〙35%`,
            `ʟᴏᴀᴅɪɴɢ〘█████▒▒▒▒▒〙51%`,
            `ʟᴏᴀᴅɪɴɢ〘███████▒▒▒〙62%`,
            `ʟᴏᴀᴅɪɴɢ〘████████▒▒〙80%`,
            `ʟᴏᴀᴅɪɴɢ〘██████████〙100%`,
            `𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...`
          ]
          let { key } = await miwa.sendMessage(from, { text: tempo + " " + pushname }, { quoted: info })
          await sleep(1000)
          for (let i = 0; i < download.length; i++) {
            await miwa.sendMessage(from, { text: download[i], edit: key }, { quoted: info })
          }
          await miwa.sendMessage(from, {
            text: moneybot, contextInfo: {
              externalAdReply: {
                title: `👑⟩ ${NickDono}`,
                body: `🤖⟩ ${NomeDoBot}`,
                thumbnail: await getBuffer(`https://i.imgur.com/EhWShRN.jpeg`),
                renderLargerThumbnail: true,
                mediaType: 1,
                showAdAttribution: true,
                sourceUrl: `https://wa.me/555194709091?text=Ol%C3%A1,%20gostaria%20de%20alugar%20a%20Mai%20Bot!`
              }
            }
          }, { quoted: info })
        }
          break
        //===============================================
console.log('passou aqui')

        //====================JOGOS======================\\
        case 'pau':

          random = `${Math.floor(Math.random() * 35)}`
          const tamanho = random
          if (tamanho < 13) { pp = 'só a fimose' } else if (tamanho == 13) { pp = 'passou da média😳' } else if (tamanho == 14) { pp = 'passou da média😳' } else if (tamanho == 15) { pp = 'eita, vai pegar manga?' } else if (tamanho == 16) { pp = 'eita, vai pegar manga?' } else if (tamanho == 17) { pp = 'calma man, a mina não é um poço😳' } else if (tamanho == 18) { pp = 'calma man, a mina não é um poço😳' } else if (tamanho == 19) { pp = 'calma man, a mina não é um poço😳' } else if (tamanho == 20) { pp = 'você tem um poste no meio das pernas' } else if (tamanho == 21) { pp = 'você tem um poste no meio das pernas' } else if (tamanho == 22) { pp = 'você tem um poste no meio das pernas' } else if (tamanho == 23) { pp = 'você tem um poste no meio das pernas' } else if (tamanho == 24) { pp = 'você tem um poste no meio das pernas' } else if (tamanho > 25) {
            pp = 'vai procurar petróleo com isso?'
          }
          hasil = `╭═════════════════ ⪩
╰╮ू ፝͜❥⃟🍌𝐑𝐄𝐒𝐔𝐋𝐓𝐀𝐃𝐎 𝐃𝐎 𝐏𝐀𝐔👁⃟ू ፝͜❥
╭┤➢☃️ 「𝘖𝘓𝘈: ${pushname}」
╭┤➢🍆「𝘚𝘌𝘜 𝑃𝐴𝑈 𝘛𝘌𝘔: ${random}𝘊𝘔
╭┤➢✉️ 「${pp}」
┃╰══ ⪨
╰═════════════════ ⪨`
          reply(hasil)
          break

        case 'chifre':
          random2 = `${Math.floor(Math.random() * 35)}`
          const tamanho2 = random2
          if (tamanho2 < 13) { pp = 'muito corno🤟' } else if (tamanho2 == 13) { pp = 'meio corno😬' } else if (tamanho2 == 14) { pp = 'muito corno😳' } else if (tamanho2 == 15) { pp = 'cuidado com o poste' } else if (tamanho2 == 16) { pp = 'vai pegar manga com esse chifre?' } else if (tamanho2 == 17) { pp = 'eita poha, levou muita galha em😳' } else if (tamanho2 == 18) { pp = 'cuidado com os fios de energia😳' } else if (tamanho2 == 19) { pp = 'como você aguenta esse peso todo😳' } else if (tamanho2 == 20) { pp = 'recorde de maior chifre, parabéns' } else if (tamanho2 == 21) { pp = 'parabéns, belos chifres' } else if (tamanho2 == 22) { pp = 'parabéns, belos chifres' } else if (tamanho2 == 23) { pp = 'parabéns, belos chifres' } else if (tamanho2 == 24) { pp = 'parabéns, belos chifres' } else if (tamanho2 > 25) {
            pp = 'vai construir uma torre com isso?'
          }
          hasil = `╭═════════════════ ⪩
╰╮ू ፝͜❥⃟💡𝐑𝐄𝐒𝐔𝐋𝐓𝐀𝐃𝐎 𝐃𝐎 𝐂𝐇𝐈𝐅𝐑𝐄👁⃟ू ፝͜❥
╭┤➢☃️ 「𝘖𝘓𝘈: ${pushname}」
╭┤➢🤟 「𝘚𝘌𝘜 𝘊𝘏𝘐𝘍𝘙𝘌 𝘛𝘌𝘔: ${random2}𝘊𝘔
╭┤➢✉️ 「${pp}」
┃╰══ ⪨
╰═════════════════ ⪨`
          reply(hasil)
          break

        case 'morte':
          morrer1 = `${Math.floor(Math.random() * 31)}`
          morrer2 = `${Math.floor(Math.random() * 9)}`
          var ano = ("2")
          ano1 = `${Math.floor(Math.random() * 300)}`
          morrer = `${morrer1}.${morrer2}.${ano}${ano1}`
          gilli = `╭═════════════════ ⪩
╰╮ू ፝͜❥⃟😵𝐃𝐀𝐓𝐀 𝐃𝐀 𝐒𝐔𝐀 𝐌𝐎𝐑𝐓𝐄👁⃟ू ፝͜❥
╭┤➢☃️ 「𝘖𝘓𝘈: ${pushname}」
╭┤➢📆 「𝘋𝘈𝘛𝘈: ${morrer1}/0${morrer2}/${ano}${ano1}
╭┤➢💐 「meus pêsames」
┃╰══ ⪨
╰═════════════════ ⪨`
          reply(gilli)
          break

        //================================================\\

        //=============COMANDOS TEXTO==================\\
        case 'recado'://BY:Ryuu Mods 
        case 'recadowhatsapp':

          rate = body.slice(6)
          var foda = ['Felicidade é só questão de ser.', 'Acredite: sempre tem algo bom guardado para você', 'Concentre-se no que está buscando, não no que está deixando para trás.', 'A vida é muito curta pra não viver sorrindo por aí!', 'Onde há vontade, há chance de dar certo!', 'Dance no seu ritmo! 💃', 'Só você sabe o que te deixará feliz.', 'Não se estresse com o que está fora do seu controle.', 'Aprenda a apreciar as voltas que o mundo dá.', 'Comece a se amar. O resto virá depois.', 'Maior que a tristeza de não haver vencido é a vergonha de não ter lutado!', 'Reciprocidade, para as coisa boas. Imunidade, para as coisas ruins.', 'Coragem, a vida gosta de pessoas destemidas.', 'Compartilhe seus sentimentos. Nem todas as pessoas sabem adivinhar', 'Continue caminhando, não tem problema se for devagar.', 'Melhor amar do que ser amargo!', 'Não corrigir nossas falhas é o mesmo que cometer novos erros', 'Quando o caminho se torna duro, só os duros continuam caminhando', 'Florescer exige passar por todas as estações!', 'Quando as coisas simples parecem especiais, você percebe como a vida pode ser boa.', 'Os aprendizados deixam a vida especial.', 'Feliz daquele que encontra o verdadeiro amor sem as cicatrizes da decepção']
          var gilli = foda[Math.floor(Math.random() * foda.length)]
          reply(` ${gilli} `)
          break

        case 'frasecriativas':
          rate = body.slice(6)
          var foda = ['Não conte os dias, viva-os! ☀️😎', 'Tudo que vem, vem com algum propósito. Assim como tudo que vai, vai por uma razão. 🌸🌀', 'Eu não gosto de cobrar atitude de ninguém porque eu tenho de sobra. 😉', 'Gostar, eu gosto de muita gente, mas a minha prioridade sempre será eu mesma. ✨', 'As pessoas que criticam, são as mesmas que copiam. 👀', 'Aprendi que meu único limite é a minha mente. 🌎', 'Fazendo dos meus sonhos, um objetivo. 💭']
          var gilli = foda[Math.floor(Math.random() * foda.length)]
          reply(` ${gilli} `)
          break

        case 'frasebonita':
          rate = body.slice(6)
          var foda = ['Viver em paz é um luxo. É saber que, apesar dos pesares, ficar bem é prioridade. ✨', 'Somos ferramentas para a vida seguir em frente. 🌎', 'Ao invés de pensar nas marcas que a vida deixa em você, reflita: Quais as marcas você está deixando na vida? 💭', 'Segue seu coração, tudo vai dar certo. ♥️', 'Permita-se sentir tudo que está dentro de você! ✨', 'Cada etapa da vida, lhe demandará uma versão mais forte de você. 🍃', 'A vida é como uma rosa, cada pétala um sonho, cada espinho uma realidade🌷🙉', 'A arma dos fracos é criticar os fortes. A arma dos fortes é ignorar os fracos!👌', 'Pare de olhar para trás. Você já sabe onde esteve, agora precisa saber pra onde vai🌙🍃', 'Só faz sentido o que te faz sentir.']
          var gilli = foda[Math.floor(Math.random() * foda.length)]
          reply(` ${gilli} `)
          break

        case 'frasedeamor':
        case 'frasesdeamor':
          rate = body.slice(6)
          var amor = ['Me perguntaram qual era o meu lugar favorito e eu respondi: Você!', 'Amar alguém profundamente te dá forças. Ser amado profundamente por alguém te dá coragem.', 'Eu orei por você sem te conhecer. E agora tenho você aqui, muito mais do que eu pedi.', 'Acordar com você no meu pensamento é a forma mais doce de começar meu dia.', 'Não quero a ilusão de um amor perfeito, quero a felicidade de um amor verdadeiro.', 'O verdadeiro amor nunca se desgasta. Quanto mais se dá, mais se tem.', 'Meu bem, eu que nunca me lembro de nada não me esqueço de você.', 'Não procure alguém que te complete. Complete a si mesmo e procure alguém que te transborde.']
          var ryuu = amor[Math.floor(Math.random() * amor.length)]
          reply(` ${ryuu} `)
          break

        case 'cantadas':
        case 'cantada':
          rate = body.slice(6)
          var cantada = ['Existe um vazio no meu coração que tem as suas medidas. Quer entrar?', 'Não existe amor à primeira vista. O que existe é a pessoa certa, no momento certo. Você por acaso estava lá!', 'O seu sorriso é o vírus que infectou o meu coração. ', 'Se o mar fosse um sentimento... seria tão grande quanto o amor que sinto por você. ', ' Você sabe qual é o motivo do meu sorriso todos os dias? A primeira palavra dessa frase.', 'O Ministério da Saúde adverte: te ver longe de mim me faz sentir saudades. ', 'Quem te conhece deve ter que tomar calmante pro resto da vida, não estou certo? Você deixa qualquer um doido por você! ', ' Amar você é loucura? Então não tem psiquiatra que me cure.']
          var ryuu = cantada[Math.floor(Math.random() * cantada.length)]
          reply(` ${ryuu} `)
          break

        case 'ansiedade':
        case 'ansiedades':
          rate = body.slice(6)
          var ansiedade = ['Quanto mais medo eu sinto, mais trêmulo fico de ansiedade. Eu me fortaleço nas dificuldades.', 'A ansiedade me acompanha mundo afora, mas sei que para ser feliz preciso dela como precaução, como freio para meus sonhos infinitos....', 'Já não me importa o tempo perdido, eu sinto uma ansiedade imensa de mergulhar no que ainda não vivi. ', 'Ansiedade é o desejo para que o futuro se transforme logo no seu maior presente. ', 'De repente nos vemos sofrendo antecipadamente por causa de algo que talvez jamais aconteça, é a agulha da ansiedade a nos espetar... ', 'A ansiedade é o acelerador que ganhamos de brinde por não sabermos esperar nosso próprio tempo. ', 'Não me sinto bem em parte nenhuma e ando cheio de ansiedade de coisas que não posso nem sei realizar. ', 'De repente nos vemos nus diante da ansiedade que nos deixa cegos e indefesos, porém dentro de nós estão as armas para nos livrar de suas garras. ']
          var ryuu = ansiedade[Math.floor(Math.random() * ansiedade.length)]
          reply(` ${ryuu} `)
          break

        case 'indiretas':
        case 'indireta':
          rate = body.slice(6)
          var indireta = ['Que essa frente fria consiga amenizar esse seu fogo.', 'Por que eu ainda fico lembrando de tudo aquilo que você já esqueceu?', 'Não olho para o passado, pois tudo de bom que tive nele está no meu presente, o que ficou pra trás foi só o que não servia pra nada. ', 'Algumas pessoas merecem um grande aplauso pelo teatro que fazem! 👏👏👏 ', ' Meu cupido é gari, só me traz lixo e você é a prova disso...', ' Não lhe compete julgar a realidade que você não vive. 💥', ' Às vezes, sem querer, a gente esbarra em alguém que vale a pena.', ' Não sei porque ainda me explico. Não devo explicações. Só para os meus pais, e somente até aos 18.']
          var ryuu = indireta[Math.floor(Math.random() * indireta.length)]
          reply(` ${ryuu} `)
          break

        case 'piadas':
        case 'piada':
          rate = body.slice(6)
          var piada = ['O que é um pontinho brilhando no jardim? Uma formiga de aparelho!', 'O que é um pontinho marrom cantando? Carlinhos Brown.', ' Como o Batman faz para abrir a bat-caverna? Ele bat-palma.', ' O que é um pontinho verde em Pernambuco? É um frevo de 4 folhas.', ' Por que as loiras entram no banco rebolando? Para movimentar a poupança.', ' Qual a semelhança entre uma loira e uma garrafa de cerveja? Do pescoço pra cima elas não tem nada.', 'Qual é a diferença entre a bicicleta e o vaso sanitário? Resp: a bicicleta você senta pra correr e o vaso sanitário você corre pra sentar! ', '- Joãozinho você bebe 3 vinhos, depois bebe + 4 vinhos e depois + 7. Quantos vinhos voce bebeu? - Puxa!! Isto já é sacanagem, a esta hora, eu já estou bêbado! ']
          var ryuu = piada[Math.floor(Math.random() * piada.length)]
          reply(` ${ryuu} `)
          break
        //================================================\\

        case 'tovideo': //Descoberto por Droidzin Modder && adaptado por Bkz Modz
          if (!isQuotedVideo && !info.message.videoMessage) {
            return reply('Marque um vídeo/gif que você deseja converter para mensagem de vídeo.')
          }
          miwa.relayMessage(from, { ptvMessage: isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage }, {})
          break

        case 'flame': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=flame-logo&text=${q}` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'silver': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/habboclub_silver/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'fx': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/fx/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'tribe': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/tribe/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'rugs': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/rugs/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'spaces': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/spaces/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'retropixel': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/retropixel/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'recycle': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/recycle/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'japan': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/japan/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'hands': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/hands/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'mushroom_green': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/mushroom_green/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'hello': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/hello/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'big': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/habbowood_big/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'gravity': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/gravity/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'fbomb': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/fbomb/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'cubie': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/cubie/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'bots': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/bots/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'arctic': {
          if (!q) return reply('Cadê o nicknome')
          await miwa.sendMessage(from, { image: { url: `https://habbofont.net/font/arctic/${q}.gif` } }, { quoted: info })
            .catch((err) => {
              reply(`Erro, tenta mais tarde`);
            })
        }
          break

        case 'qc': // Créditos: @IagoNT
          if (!q) return reply(`Exemplo de uso deste comando:\n • ${prefix}qc Olá, você é gay?`)
          reply(mess.wait())
          const text = `${q}`
          const username = `${pushname}`
          try {
            ppimg = await miwa.profilePictureUrl(sender, 'image')
          } catch {
            ppimg = 'https://telegra.ph/file/b5427ea4b8701bc47e751.jpg'
          }
          const { writeExifImg } = require('./arquivos/sticker/exif')
          miwa.sendImageAsSticker = async (jid, path, options = {}) => {
            let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
            let buffer
            if (options && (options.packname || options.author)) {
              buffer = await writeExifImg(buff, options)
            } else {
              buffer = await imageToWebp(buff)
            }

            await miwa.sendMessage(jid, { sticker: { url: buffer }, ...options })
            return buffer
          }
          const avatar = `${ppimg}`
          const json = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#FFFFFF",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [
              {
                "entities": [],
                "avatar": true,
                "from": {
                  "id": 1,
                  "name": username,
                  "photo": {
                    "url": avatar
                  }
                },
                "text": text,
                "replyMessage": {}
              }
            ]
          };
          const response = axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: { 'Content-Type': 'application/json' }
          }).then(res => {
            const buffer = Buffer.from(res.data.result.image, 'base64')
            miwa.sendImageAsSticker(from, buffer, { packname: `${NomeDoBot}`, author: `${pushname}` })
          })
          break

        // Pesquisa


        case 'createimg': case 'texttoimage': case 'imagine':
          if (!q) return reply(`O que você deseja criar amiguinho? Coloque após o comando o que você deseja criar... Por exemplo: ${prefix + command} macaco dirigindo uma bmw`);
          try {
            await replyWithReaction('Olá, estou criando a imagem a partir de seu questionamento, aguarde senhor(a)...', { react: { text: '🎨', key: info.key } });
            dataResultAI = await fetchJson(`https://hercai.onrender.com/v3/text2image?prompt=${q}`);
            await miwa.sendMessage(from, { image: { url: dataResultAI.url } }, { quoted: selo });
          } catch (error) {
            await replyWithReaction(mess.error(), { react: { text: '❌', key: info.key } });
          }
          break

        // Pesquisa de Produtos:

        case 'encurtalink': case 'tinyurl':
          if (!isPremium) return reply(enviar.msg.premium)
          if (args.length < 1) return reply(`❌️ *Forma incorreta, use está como exemplo:* ${prefix + command} https://instagram.com/maibot.wpp`)
          try {
            link = args[0]
            anu = await axios.get(`https://tinyurl.com/api-create.php?url=${link}`)
            reply(`✅️ *Link encurtado com sucesso, aqui está:* ${anu.data}`)
          } catch (e) {
            emror = String(e)
            reply(`${e}`)
          }
          break

        case 'encurtalink2': case 'tinyurl2':
          try {
            if (!isPremium) return reply(enviar.msg.premium)
            texto = args.join(' ')
            texto1 = texto.split('+')[0] || 'Indefinido'
            texto2 = texto.split('+')[1] || 'Indefinido'
            if (!texto.includes("+")) return reply(`❌️ *Forma incorreta, use está como exemplo:* ${prefix + command} https://instagram.com/miwabot.wpp+InstagramDamai`)
            bla = await axios.get(`https://free-api.herokuapp.com/api/linkshort/tinyurlwithalias?link=${texto1}&alias=${texto2}`)
            reply(`✅️ *Link encurtado com sucesso, aqui está:* ${bla.data.result}`)
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              reply('O nome solicitado, já existe ou tem alguma restrição ao criar!')
            }
          }
          break

        case 'encurtarlink3': case 'cuttly':
          if (!isPremium) return reply(enviar.msg.premium)
          if (args.length < 1) return reply(`❌️ *Forma incorreta, use está como exemplo:* ${prefix + command} https://instagram.com/maibot.wpp`)
          try {
            link = args[0]
            anu = await axios.get(`https://free-api.herokuapp.com/api/linkshort/cuttly?link=${link}`)
            reply(`✅️ *Link encurtado com sucesso, aqui está:* ${anu.data.result}`)
          } catch (e) {
            emror = String(e)
            reply(`${e}`)
          }
          break

        case 'encurtarlink4': case 'bitly':
          if (!isPremium) return reply(enviar.msg.premium)
          if (args.length < 1) return reply(`❌️ *Forma incorreta, use está como exemplo:* ${prefix + command} https://instagram.com/maibot.wpp`)
          try {
            link = args[0]
            anu = await axios.get(`https://free-api.herokuapp.com/api/linkshort/bitly?link=${link}`)
            reply(`✅️ *Link encurtado com sucesso, aqui está:* ${anu.data.result}`)
          } catch (e) {
            emror = String(e)
            reply(`${e}`)
          }
          break

        case 'desativacao':
          if (botoes) {
            await miwa.relayMessage(from,
              {
                interactiveMessage: {
                  body: {
                    text: `*_DESATIVAÇÕES GRUPO_*`,
                  }, nativeFlowMessage: {
                    buttons: [{
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-LINK",
                        id: `${prefix}antilink 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-LINK-GP",
                        id: `${prefix}antilinkgp 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-DOC",
                        id: `${prefix}antidoc 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANT-IIMG",
                        id: `${prefix}antiimg 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-VIDEO",
                        id: `${prefix}antivideo 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "X9-VISUUNICA",
                        id: `${prefix}x9visuunica 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-CONTATO",
                        id: `${prefix}antictt 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-AUDIO",
                        id: `${prefix}antiaudio 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "SO_ADM",
                        id: `${prefix}So_adm 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-STICKER",
                        id: `${prefix}antisticker 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "FECHAR GRUPO",
                        id: `${prefix}grupo f`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "anti-fake",
                        id: `${prefix}antifake 0`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ABRIR GRUPO",
                        id: `${prefix}grupo a`
                      }),
                    },
                    ],
                    messageParamsJson: "",
                  },
                },
              },
              {}
            ).then((r) => console.log(r));
          } else {


          }
          break

        case 'ativacoes':
          if (botoes) {
            await miwa.relayMessage(from,
              {
                interactiveMessage: {
                  body: {
                    text: `*_ATIVAÇÕES GRUPO_*`,
                  }, nativeFlowMessage: {
                    buttons: [{
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-LINK",
                        id: `${prefix}antilink 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-LINK-GP",
                        id: `${prefix}antilinkgp 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-DOC",
                        id: `${prefix}antidoc 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANT-IIMG",
                        id: `${prefix}antiimg 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-VIDEO",
                        id: `${prefix}antivideo 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "X9-VISUUNICA",
                        id: `${prefix}x9visuunica 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-CONTATO",
                        id: `${prefix}antictt 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-AUDIO",
                        id: `${prefix}antiaudio 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "SO_ADM",
                        id: `${prefix}So_adm 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ANTI-STICKER",
                        id: `${prefix}antisticker 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "FECHAR GRUPO",
                        id: `${prefix}grupo f`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "anti-fake",
                        id: `${prefix}antifake 1`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "ABRIR GRUPO",
                        id: `${prefix}grupo a`
                      }),
                    },
                    ],
                    messageParamsJson: "",
                  },
                },
              },
              {}
            ).then((r) => console.log(r));
          } else {


          }
          break

       
        //)==== dow

        case 'play': {
          if (!q) return reply(`Cade o nome?`);
          reply("aguarde o resultado");
          await miwa.sendMessage(from, { react: { text: '⏳', key: info.key } });
          await sleep(4000);  // Espera de 2 segundos

          // Enviando reação de emoji "🎵"
          await miwa.sendMessage(from, { react: { text: '🎵', key: info.key } });
          try {
            qp = args.join(" ");
            res = await yts(qp);
            blaimg = await getBuffer(res.all[0].image);
            blalink = await getBuffer(res.all[0].url);
            TheDown = `ꔷ㆒⸼݇҉ֻ᠂⃟🎵 MAI - BOT - PLAY ⸵░⃟🎵\n\n💫⃤ 𝚃í𝚝𝚞𝚕𝚘: ${res.all[0].title}\n⏰⃤ 𝚃𝚎𝚖𝚙𝚘: ${res.all[0].timestamp}\n👁️⃤ 𝚅𝚒𝚜𝚞𝚊𝚕𝚒𝚣𝚊çõ𝚎𝚜: ${res.all[0].views}\n🎞️⃤ 𝙲𝚊𝚗𝚊𝚕: ${res.all[0].author.name}\n📹⃤ 𝙿𝚘𝚜𝚝𝚊𝚍𝚘: ${res.all[0].ago}\n🔗⃤ 𝚄𝚛𝚕: ${res.all[0].url}\n💬⃤ 𝙳𝚎𝚜𝚌𝚛𝚒çã𝚘: ${res.all[0].description}`;
            await btncomfoto(from, " ", TheDown, " ", "𝑺𝒆𝒍𝒆𝒄𝒊𝒐𝒏𝒆 𝒂 𝒐𝒑𝒄̧𝒂̃𝒐 𝒅𝒆 𝒅𝒐𝒘𝒏𝒍𝒐𝒂𝒅 𝒅𝒆𝒔𝒆𝒋𝒂𝒅𝒂! 🌷", { url: res.all[0].image }, "image", info, {}, [
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "🎶 𝙑𝙀𝙍𝙎𝘼́𝙊 𝙈𝙐𝙎𝙄𝘾𝘼 🎶",
                  id: `${prefix}play_audio2 ${res.all[0].url}`
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "🎥 𝙑𝙀𝙍𝙎𝘼̃𝙊 𝙑𝙄𝘿𝙀𝙊 🎥",
                  id: `${prefix}playvideo ${res.all[0].url}`
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "📃 𝙑𝙀𝙍𝙎𝘼̃𝙊 𝘿𝙊𝘾𝙐𝙈𝙀𝙉𝙏𝙊 📃",
                  id: `${prefix}playdoc ${res.all[0].url}`
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "💽 𝘼𝘿𝙄𝘾𝙄𝙊𝙉𝘼𝙍 𝙋𝙇𝘼𝙔𝙇𝙄𝙎𝙏 💽",
                  id: `${prefix}adicionarmusica ${q}`
                })
              }
            ]);
          } catch (e) {
            console.log(e);
            return reply(`⟬❗⟭  ${pushname}, algum erro foi encontrado no servidor interno, que tal pedir mais tarde? Fica tranquilx, esse erro já foi relatado a meu(minha) criador(a).`);
            await miwa.sendMessage(`${numerodono}@s.whatsapp.net`, { text: `⟬❗⟭ Sr/Sra, foi encontrado um erro no servidor interno do sistema de Play de Módulos/Scraper.` });
          }
          break;
        }

        case 'playaudio2':
          try {
            if (!q) return reply(`Exemplo: ${prefix + command} poze desabafo`);
            await reply(`Estou atendendo seu pedido [ ${pushname} ]`)
            const api = await fetchJson(`http://kayserapis.tech:4197/api/ytsrc/videos?q=${q}&apikey=Sandrinho`)
            const buffer = await getBuffer(api.resultado[0].image)
            // Enviando reação de emoji "⏳"
            await miwa.sendMessage(from, { react: { text: '⏳', key: info.key } });
            await sleep(4000);  // Espera de 2 segundos

            // Enviando reação de emoji "🎵"
            await miwa.sendMessage(from, { react: { text: '🎵', key: info.key } });
            await miwa.sendMessage(from, {
              audio: { url: `http://kayserapis.tech:4197/api/dl/ytaudio?url=${api.resultado[0].url}&apikey=Sandrinho` }, mimetype: "audio/mp4",
              headerType: 4,
              contextInfo: {
                externalAdReply: {
                  title: `${NomeDoBot}`,
                  body: `${api.resultado[0].title}`,
                  showAdAttribution: true,
                  thumbnail: await getBuffer(`${api.resultado[0].image}`),
                  mediaType: 2,
                  mediaUrl: `instagram.com`,
                  sourceUrl: `https://www.youtube.com/@lukinha_07k`
                }
              }
            })
          } catch (erro) {
            console.log(erro)
          }
          break


        case 'insta':
        case 'insta_video':
        case 'instagram':
        case 'igdl':
          if (q.length < 5) return reply('Por favor, adicione um link do Instagram post/reel.');
          try {
            const { instagram } = require('betabotz-tools');
            const url = `${q};`
            const results = await instagram(url);
            if (results.result && results.result.length > 0 && results.result[0]._url) {
              const videoUrl = results.result[0]._url;
              await miwa.sendMessage(from, { video: { url: videoUrl }, mimetype: "video/mp4" }, { quoted: info });
            } else {
              return reply(`Desculpe, ocorreu um erro. Por favor, tente novamente mais tarde.`);
            }
          } catch (error) {
            console.error(error);
            return reply(`Desculpe, ocorreu um erro. Por favor, tente novamente mais tarde.`);
          }
          break;


        case 'gitclone':
          {
            let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
            if (!q) return reply(`Exemplo: ${prefix}gitclone https://github.com/YajiirDev/avatar`)
            if (!args[0]) reply(`Exemplo: ${prefix}gitclone https://github.com/YajiirDev/avatar`)
            reply(mess.wait())
            if (!regex1.test(args[0])) return reply('Aguarde...')
            let [, user, repo] = args[0].match(regex1) || []
            repo = repo.replace(/.git$/, '')
            let url = `https://api.github.com/repos/${user}/${repo}/zipball`
            let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
            await miwa.sendMessage(from, { document: { url: url }, fileName: filename + '.zip', mimetype: 'application/zip' }, { quoted: selo }).catch((err) => reply('❌️ Erro ao executar o download do arquivo solicitado...'))
          }
          break

      

        case 'tiktok':
        case 'tiktok_video':
        case 'tiktokvideo':
          try {
            reply(`Não precisa gritar, já ouvi e tô enviando o seu pedido!`)
            require('./arquivos/funcoes/scraper/tiktok.js').tikmate(q).then(data => {
              miwa.sendMessage(from, { video: { url: data.video.noWatermark }, caption: `_*Aqui está o seu vídeo do TikTok:*_\n*Pedido por:* _${pushname}_\n*Baixado por:* _${NomeDoBot}_` }, { quoted: info })
            })
          } catch {
            reply(`Desculpe, ocorreu um erro. Por favor, tente novamente mais tarde.`)
          }
          break

        case 'join': case 'entrar':
          if (!SoDono) return reply(mess.onlyOwner())
          string = args.join(' ')
          if (!string) return reply('Insira um link de convite ao lado do comando.')
          if (string.includes('chat.whatsapp.com/') || reply('Ops, verifique o link que você inseriu.')) {
            link = string.split('app.com/')[1]
            try {
              miwa.groupAcceptInvite(`${link}`)
            } catch (erro) {
              if (String(erro).includes('resource-limit')) {
                reply('O grupo já está com o alcance de 257 membros.')
              }
              if (String(erro).includes('not-authorized')) {
                reply('Não foi possível entrar no grupo.\nMotivo: Banimento.')
              }
            }
          }
          break

        case 'antiimg':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('Hmmmm')
          if (Number(args[0]) === 1) {
            if (isAntiImg) return reply('O recurso de anti imagem já está ativado.')
            dataGp[0].antiimg = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti imagem neste grupo.️')
          } else if (Number(args[0]) === 0) {
            if (!isAntiImg) return reply('O recurso de anti imagem já está desativado.')
            dataGp[0].antiimg = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de anti imagem neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antivideo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('Hmmmm')
          if (Number(args[0]) === 1) {
            if (isAntiVid) return reply('O recurso de anti vídeo já está ativado.')
            dataGp[0].antivideo = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti video neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntiVid) return reply('O recurso de anti vídeo já está desativado.')
            dataGp[0].antivideo = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de anti video neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antiaudio':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('Hmmmm')
          if (Number(args[0]) === 1) {
            if (isAntiAudio) return reply('O recurso de anti áudio já está ativado.')
            dataGp[0].antiaudio = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti audio neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntiAudio) return reply('O recurso de anti áudio já está desativado.')
            dataGp[0].antiaudio = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de anti audio neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antisticker':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('Hmmmm')
          if (Number(args[0]) === 1) {
            if (isAntiSticker) return reply('O recurso de anti sticker já está ativado.')
            dataGp[0].antisticker = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti sticker neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntiSticker) return reply('O recurso de anti sticker já está desativado.')
            dataGp[0].antisticker = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de anti sticker neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antidocumento':
        case 'antidoc':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (Antidoc) return reply('O recurso de anti documento já está ativado.')
            dataGp[0].antidoc = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti documento neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!Antidoc) return reply('O recurso de anti documento já está desativado.')
            dataGp[0].antidoc = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de anti documento neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antictt':
        case 'anticontato':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAntiCtt) return reply('O recurso de anti contato já está ativado.')
            dataGp[0].antictt = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de anti contato neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntiCtt) return reply('O recurso de anti contato já está desativado.')
            dataGp[0].antictt = false
            setGp(dataGp)
            reply('️✔️ Desativou com sucesso o recurso de anticontato neste grupo.️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antiloc':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          try {
            if (args.length < 1) return reply('1 pra ativar, 0 pra desligar')
            if (Number(args[0]) === 1) {
              if (Antiloc) return reply('O recurso de anti loc já está ativado.')
              dataGp[0].antiloc = true
              setGp(dataGp)
              reply('✔️ Ativou com sucesso o recurso de anti loc neste grupo.')
            } else if (Number(args[0]) === 0) {
              if (!Antiloc) return reply('O recurso de anti loc já está desativado.')
              dataGp[0].antiloc = false
              setGp(dataGp)
              reply('✔️ Desativou com sucesso o recurso de anti loc neste grupo.')
            } else {
              reply('1 para ativar, 0 para desativar')
            }
          } catch {
            reply('Deu erro, tente novamente :/')
          }
          break

        case 'antilinkgp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAntilinkgp) return reply('O recurso de antilink de grupo já está ativado.')
            dataGp[0].antilinkgp = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de antilink de grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntilinkgp) return reply('O recurso de antilink de grupo já está desativado.')
            dataGp[0].antilinkgp = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de antilink de grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antilinkhard':
        case 'antilink':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAntiLinkHard) return reply('O recurso de antilink hardcore já está ativado.')
            dataGp[0].antilinkhard = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de antilink hardcore neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAntiLinkHard) return reply('O recurso de antilink hardcore já está desativado.')
            dataGp[0].antilinkhard = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de antilink harcore neste grupo.️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'x9':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isx9) return reply('O recurso de x9 já está ativado.')
            dataGp[0].x9 = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de x9 neste grupo, irei notificar quando alguém for rebaixado ou promovido a adm 😏..')
          } else if (Number(args[0]) === 0) {
            if (!isx9) return reply('O recurso de x9 já está desativado.')
            dataGp[0].x9 = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de x9 neste grupo, não irei mais notificar promoção de adm nem rebaixamento.. ️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'visualizarmsg':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isVisualizar) {
            nescessario.visualizarmsg = true
            setNes(nescessario)
            reply('✔️ Ativou com sucesso o recurso de visualizar todas as mensagens enviada em grupos e privado.')
          } else if (isVisualizar) {
            nescessario.visualizarmsg = false
            setNes(nescessario)
            reply('✔️ Desativou com sucesso o recurso de visualizar todas as mensagens enviada em grupos e privado.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'x9visuunica':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isX9VisuUnica) return reply('O recurso de revelar visu única já está ativado.')
            dataGp[0].visuUnica = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de revelar visu única neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isX9VisuUnica) return reply('O recurso de revelar visu única já está desativado.')
            dataGp[0].visuUnica = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de revelar visu única neste grupo.')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'so_adm':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (So_Adm) return reply('Ja esta ativo')
            dataGp[0].soadm = true
            setGp(dataGp)
            reply(' - Ativou com sucesso o recurso de só adm utilizar comandos neste grupo 📝')
          } else if (Number(args[0]) === 0) {
            if (!So_Adm) return reply('Ja esta Desativado')
            dataGp[0].soadm = false
            setGp(dataGp)
            reply('‼️ Desativou o recurso de Só ADM utiliar comandos neste grupo ✔️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'odelete':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (IS_DELETE) return reply('O recurso de delete já está ativado.')
            nescessario.Odelete = true
            setNes(nescessario)
            reply('✔️ Ativou com sucesso o recurso de delete nos grupos.')
          } else if (Number(args[0]) === 0) {
            if (IS_DELETE) return reply('O recurso de delete já está desativado.')
            nescessario.Odelete = false
            setNes(nescessario)
            reply('️✔️ Desativou com sucesso o recurso de delete nos grupos.️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'antifake':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAntifake) return reply('O recurso de antifake já está ativado.')
            dataGp[0].antifake = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de antifake neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (isAntifake) return reply('O recurso de antifake já está desativado.')
            dataGp[0].antifake = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de antifake neste grupo.️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'prefixos':
          if (!isGroup) return reply(mess.onlyGroup())
          if (dataGp[0].prefixos.length < 1) return reply("Não contem nenhum prefixo a + adicionado neste grupo.")
          bla = `Lista de prefixos para uso do bot, no Grupo: ${groupName}\n\n`
          for (i of dataGp[0].prefixos) {
            bla += `Prefixo: ${i}\n\n`
          }
          reply(bla)
          break

        case 'figurinhas':
          if (!q) return reply("Insira a qnd de figu que deja que eu envie")
          if (!Number(args[0]) || Number(q.trim()) > 5) return reply("Digite a quantidade de figurinhas que deseja que eu envie.. não pode mais de 5..")
          reply(mess.wait())
          async function figuss() {
            var rnd = Math.floor(Math.random() * 8051)
            await miwa.sendMessage(from, { sticker: { url: `https://raw.githubusercontent.com/badDevelopper/Testfigu/main/fig (${rnd}).webp` } })
          }
          for (i = 0; i < q; i++) {
            await sleep(680)
            figuss()
          }
          break

        case 'figaleatoria':
          reply(mess.wait())
          bla = await getBuffer(`http://api.nezsab-apis.xyz/figu?apikey=` + API_KEY_MIWA)
          await miwa.sendMessage(from, { sticker: bla })
          break

        case 'add_prefixo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isMultiP) return reply(`Para usar este comando, você deve ativar o comando, multiprefix\nExemplo: ${prefix}multiprefixo 1`)
          if (ANT_LTR_MD_EMJ(q)) return reply("Não pode letra modificada, nem emoji..")
          if (!q.trim()) return reply("Determine o novo prefixo, não pode espaço vazio...")
          if (q.trim() > 1) return reply(`Calma, o prefixo só pode ser um\nExemplo: ${prefix + command} _\nAe o bot vai passar á responder _ como prefixo do bot..`)
          if (dataGp[0].prefixos.indexOf(q.trim()) >= 0) return reply(`Esse prefixo já se encontra incluso, procure ver na lista dos prefixos\nExemplo: ${prefix}prefixos`)
          dataGp[0].prefixos.push(q.trim())
          setGp(dataGp)
          reply(`Prefixo ${q.trim()} Adicionado com sucesso na lista de prefixos para uso do bot, neste grupo...`)
          break

        case 'tirar_prefixo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isMultiP) return reply(`Para usar este comando, você deve ativar o comando, multiprefix\nExemplo: ${prefix}multiprefixo 1`)
          if (ANT_LTR_MD_EMJ(q)) return reply("Não pode letra modificada, nem emoji..")
          if (!q.trim()) return reply("Determine o prefixo que deseja tirar, não pode espaço vazio...")
          if (q.trim() > 1) return reply(`Calma, o prefixo só pode ser tirado um por vez\nExemplo: ${prefix + command} _\nAe o bot não vai responder mais com _`)
          if (dataGp[0].prefixos.indexOf(q.trim()) < 0) return reply(`Esse prefixo não está incluso, procure ver na lista dos prefixos\nExemplo: ${prefix}prefixos`)
          if (dataGp[0].prefixos.length == 1) return reply("Adicione um prefixo para pode tirar este, tem que ter pelo menos 1 prefixo já incluso dentro do sistema para tirar outro.")
          dataGp[0].prefixos.splice(dataGp[0].prefixos.indexOf(q.trim()), 1)
          setGp(dataGp)
          reply(`Prefixo ${q.trim()} tirado com sucesso da lista de prefixos de uso deste grupo..`)
          break

        case 'multiprefixo': case 'multiprefix':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins())
          if (!isMultiP) {
            dataGp[0].multiprefix = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de multi prefixos neste grupo')
          }
          if (isMultiP) {
            dataGp[0].multiprefix = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de multi prefixos neste grupo')
          }
          break

        case 'ephemeral': case 'msgtemp': {
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!q) return reply(`Insira os valores de ativação/desativação`)
          if (args[0] === '1') {
            reply(`⏲️ As mensagens temporárias ativada com sucesso. ✅️`)
            await miwa.sendMessage(from, { disappearingMessagesInChat: WA_DEFAULT_EPHEMERAL })
          } else if (args[0] === '0') {
            reply(`⏲️ As mensagens temporárias desativada com sucesso. ‼️`)
            await miwa.sendMessage(from, { disappearingMessagesInChat: false })
          }
        }
          break

        case 'changegroup': case 'config_gp': case 'config-group': {
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!q) return reply(`Insira all / adms para escolher quem pode atualizar os dados do grupo. A decisão é sua, adm! `)
          if (args[0] === 'adms') {
            reply(`🔐 Sucesso! - Agora somente os adm poderá editar os dados do grupo.`)
            await miwa.groupSettingUpdate(from, 'locked')
          } else if (args[0] === 'all') {
            reply(`🔓 Sucesso! - Agora todos os participantes pode alterar os dados do grupo.`)
            await miwa.groupSettingUpdate(from, 'unlocked')
          }
        }
          break

        case 'rmphotogp': case 'rmfotogroup': {
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          reply(`A foto do grupo foi removida com sucesso.`)
          await miwa.removeProfilePicture(from)
        }
          break

        case 'antinotas':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('Hmmmm')
          if (Number(args[0]) === 1) {
            if (isAntiNotas) return reply('Já Esta ativo')
            dataGp[0].antinotas = true
            setGp(dataGp)
            reply('Ativou com sucesso o recurso de anti notas neste grupo✔️')
          } else if (Number(args[0]) === 0) {
            if (!isAntiNotas) return reply('Ja esta Desativado.')
            dataGp[0].antinotas = false
            setGp(dataGp)
            reply('Desativou com sucesso o recurso de anti notas neste grupo✔️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'anticatalogo':
        case 'anticatalg':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAnticatalogo) return reply('Ja esta ativo')
            dataGp[0].anticatalogo = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de anticatalogo neste grupo 📝')
          } else if (Number(args[0]) === 0) {
            if (!isAnticatalogo) return reply('Ja esta Desativado')
            dataGp[0].anticatalogo = false
            setGp(dataGp)
            reply('‼️ Desativou com sucesso o recurso de anticatalogo neste grupo✔️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'bemvindo':
        case 'welcome':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!SoDono) return reply(mess.onlyOwner())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isWelkom) return reply('Ja esta ativo')
            dataGp[0].wellcome[0].bemvindo1 = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de bem vindo neste grupo 📝')
          } else if (Number(args[0]) === 0) {
            if (!isWelkom) return reply('Ja esta Desativado')
            dataGp[0].wellcome[0].bemvindo1 = false
            setGp(dataGp)
            reply('‼️ Desativou com sucesso o recurso de bemvindo neste grupo✔️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'bemvindo2':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!SoDono) return reply(mess.onlyOwner())
          if (args.length < 1) return reply(`Digite da forma correta:\nComando: ${prefix + command} 1 para ativar `)
          if (Number(args[0]) === 1) {
            if (isWelkom2) return reply('❎O recurso já está ativado no grupo❎')
            dataGp[0].wellcome[1].bemvindo2 = true
            setGp(dataGp)
            reply('✅O recurso foi ativado✅')
          } else if (Number(args[0]) === 0) {
            if (!isWelkom2) return reply('❎O recurso não está ativado no grupo❎')
            dataGp[0].wellcome[1].bemvindo2 = false
            setGp(dataGp)
            reply('❌O recurso foi desativado❌')
          } else {
            reply(`Digite da forma correta:\nComando: ${prefix + command} 1, para ativar e 0 para desativar`)
          }
          break

        case 'legendabv':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de boas-vindas*')
          teks = body.slice(11)
          if (isWelkom) {
            dataGp[0].wellcome[0].legendabv = teks
            setGp(dataGp)
            reply('*Mensagem de boas vindas definida com sucesso!*')
          } else {
            reply(`Ative o ${prefix}bemvindo 1`)
          }
          break

        case 'legendasaiu':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de saída*')
          teks = body.slice(13)
          if (isWelkom) {
            dataGp[0].wellcome[0].legendasaiu = teks
            setGp(dataGp)
            reply('*Mensagem de saída definida com sucesso!*')
          } else {
            reply(`Ative o ${prefix}bemvindo 1`
            )
          }
          break

        case 'legendabv2':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de boas-vindas*')
          teks = body.slice(12)
          if (isWelkom2) {
            dataGp[0].wellcome[1].legendabv = teks
            setGp(dataGp)
            reply('*Mensagem de boas vindas2 definida com sucesso!*')
          } else {
            reply(`Ative o ${prefix}bemvindo2 1`)
          }
          break

        case 'legendasaiu2':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de saída*')
          teks = body.slice(14)
          if (isWelkom2) {
            dataGp[0].wellcome[1].legendasaiu = teks
            setGp(dataGp)
            reply('*Mensagem de saída2 definida com sucesso!*')
          } else {
            reply(`Ative o ${prefix}bemvindo2 1`)
          }
          break

        case 'legenda_estrangeiro':
        case 'legenda_estrangeiros':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de remoção de estrangeiros*')
          if (isAntifake) {
            dataGp[0].legenda_estrangeiro = q
            setGp(dataGp)
            reply('*Mensagem de remoção de estrangeiros definida com sucesso!*')
          } else {
            reply(`Ative o antifake primeiro com ${prefix}antifake 1`)
          }
          break

        case 'legenda_video':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de remoção de estrangeiros*')
          dataGp[0].legenda_video = q
          setGp(dataGp)
          reply('*Mensagem de remoção de video definida com sucesso!*')
          break

        case 'legenda_imagem':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de remoção de estrangeiros*')
          dataGp[0].legenda_imagem = q
          setGp(dataGp)
          reply('*Mensagem de remoção de imagem definida com sucesso!*')
          break

        case 'legenda_documento':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('*Escreva a mensagem de remoção de estrangeiros*')
          dataGp[0].legenda_documento = q
          setGp(dataGp)
          reply('*Mensagem de remoção de Documento definida com sucesso!*')
          break

        case 'addautorm':
        case 'addautoban':
        case 'listanegra':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins && !SoDono) return reply('Precisa ser Dono ou Adm')
          if (!mrc_ou_numero) return reply("Marque a mensagem do usuário com o comando ou utilize o comando com o número do usuário que deseja adicionar na lista negra..")
          if (dataGp[0].listanegra.includes(mrc_ou_numero)) return reply('*Esse Número ja esta incluso*')
          dataGp[0].listanegra.push(mrc_ou_numero)
          setGp(dataGp)
          reply(`*Número adicionado a lista de autoban*`)
          break

        case 'autobang':
        case 'listanegrag':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!mrc_ou_numero) return reply("Marque a mensagem do usuário com o comando ou utilize o comando com o número do usuário que deseja adicionar na lista negra Global..")
          if (listanegraG.includes(mrc_ou_numero)) return reply('*Esse Número ja esta incluso*')
          listanegraG.push(mrc_ou_numero)
          fs.writeFileSync('./settings/nescessario.json', JSON.stringify(nescessario, null, '\t'))
          reply(`*Número adicionado a lista de autoban*`)
          break

        case 'tirardalistag':
          if (!SoDono) return reply(mess.onlyOwner())
          if (!mrc_ou_numero) return reply("Marque a mensagem do usuário com o comando ou utilize o comando com o número do usuário que deseja tirar da lista negra..")
          if (!listanegraG.includes(mrc_ou_numero)) return reply('*Esse Número não esta incluso*')
          var i = listanegraG.indexOf(mrc_ou_numero)
          listanegraG.splice(i, 1)
          fs.writeFileSync('./settings/nescessario.json', JSON.stringify(nescessario, null, '\t'))
          reply(`*Número foi removido da lista negra*`)
          break

        case 'delremover':
        case 'delautorm':
        case 'delautoban':
        case 'tirardalista':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!mrc_ou_numero) return reply("Marque a mensagem do usuário com o comando ou utilize o comando com o número do usuário que deseja tirar da lista negra..")
          if (!dataGp[0].listanegra.includes(mrc_ou_numero)) return reply('*Esse Número não esta incluso*')
          var i = dataGp[0].listanegra.indexOf(mrc_ou_numero)
          dataGp[0].listanegra.splice(i, 1)
          setGp(dataGp)
          reply(`*Número foi removido da lista de autoban*`)
          break

        case 'listban':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (dataGp[0].listanegra.length < 1) return reply('*Nenhum Número não foi adicionado*')
          teks = '*Números que vou moer na porrada se voltar 😡:*\n'
          for (i = 0; i < dataGp[0].listanegra.length; ++i) {
            teks += `➤ *${dataGp[0].listanegra[i].split('@')[0]}*\n`
          }
          teks += '*Esses ai vou descer meu martelo do ban 🥵*'
          reply(teks)
          break

        case 'verfotolink':

          if (!q) return reply(`Por favor, forneça o link da foto.`);
          const imageUrl = q.trim();
          await miwa.sendMessage(from, { image: { url: imageUrl }, caption: 'Aqui está a foto:' }, { quoted: info });
          break;

        case 'mute':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply('O bot precisa ser adm pra executar essa ação.')
          if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('*Marque o número que deseja desmutar*')
          mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
          if (isMuted) {
            var ind = GroupsMutedActived.indexOf(from)
            for (let _ of mentioned) {
              teks = `Usuário mutado: @${_.split('@')[0]} - Ação do adm: [ ${pushname} ]`
              muted[ind].numbers.push(_)
            }
            fs.writeFileSync('./database/usuarios/muted.json', JSON.stringify(muted, null, 2))
            teks += '\nCaso você dar um piu, você vai ser banido do grupo.'
            mentions(teks, mentioned, true)
          } else {
            const data = {
              jid: from,
              numbers: mentioned
            }
            muted.push(data)
            fs.writeFileSync('./database/usuarios/muted.json', JSON.stringify(muted, null, 2) + '\n')
            for (let _ of mentioned) {
              teks = `Usuário mutado: @${_.split('@')[0]} - Ação do adm: [ ${pushname} ]`
            }
            teks = '\nCaso você dar um piu, você vai ser banido do grupo.'
            mentions(teks, mentioned, true)
          }
          break

        case 'baileys':
          blv = JSON.parse(fs.readFileSync(`./node_modules/@whiskeysockets/baileys/package.json`))
          sendButton(from, { text: ` ${tempo} ${pushname}..`, footer: `Baileys Version - ${blv.version}` }, miwa, sender, [{ type: `copy_url`, text: blv.name, url: blv.homepage }], info)
          break

        case 'desmute':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply('O Bot Precisa ser ADM pra executar essa ação.')
          if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return reply('*Marque o número que deseja desmutar*')
          mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
          var ind = GroupsMutedActived.indexOf(from)
          if (isMuted) {
            for (let _ of mentioned) {
              if (muted[ind].numbers.indexOf(_) >= 0) {
                var rmind = muted[ind].numbers.indexOf(_)
                muted[ind].numbers.splice(rmind, 1)
              }
            }
            fs.writeFileSync('./database/usuarios/muted.json', JSON.stringify(muted, null, 2) + '\n')
            for (let _ of mentioned) {
              teks = `Usuário desmutado: @${_.split('@')[0]} - Ação do adm: [ ${pushname} ]`
            }
            teks += '\nAgr você pode falar a vontade no grupo!'
            mentions(teks, mentioned, true)
          } else {
            const data = {
              jid: from,
              numbers: []
            }
            muted.push(data)
            fs.writeFileSync('./database/usuarios/muted.json', JSON.stringify(muted, null, 2) + '\n')
            for (let _ of mentioned) {
              teks = `Usuário desmutado: @${_.split('@')[0]} - Ação do adm: [ ${pushname} ]`
            }
            teks += '\nAgr você pode falar a vontade no grupo!'
            mentions(teks, mentioned, true)
          }
          break

        case 'roletarussa':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          jds = []
          A2 = groupMembers
          B2 = groupMembers
          TAMBOR = ["na perna.", "na cabeça.", "no pescoço.", "no peito.", "no olho.", "no estômago.", "na boca.", "na perna.", "na testa.", "no braço."]
          C2 = A2[Math.floor(Math.random() * A2.length)]
          if (C2 === sender || C2 === botNumber + "@s.whatsapp.net") {
            return reply(`*Escolhi* @${C2.id.split('@')[0]} mas infelizmente correu de covardia...*`)
          }
          tpa = TAMBOR[Math.floor(Math.random() * (TAMBOR.length))]
          reply(`*A escolha é minha! 1 membro irá morrer, que os jogos comecem...* `)
          setTimeout(() => {
            D1 = `*Que pena... você não sobreviveu ao meu jogo* @${C2.id.split('@')[0]}, *hora de enterrar o cadáver, infelizmente morreu com tiro* *${tpa}*`
            mentions(D1, jds, true)
          }, 5000)
          jds.push(C2.id)
          setTimeout(() => {
            jds.push(C2.id)
            miwa.groupParticipantsUpdate(from, [C2.id], "remove")
          }, 6000)
          break

        case 'ai':
case 'ia': {
  if (!q) {
    return reply("Fala o que você quer, por favor.");
  }

  // Enviar uma reação de carregamento
  await miwa.sendMessage(from, { react: { text: `🤖`, key: info.key } });

  // Enviar mensagem de carregamento
  const loadingMessage = await miwa.sendMessage(from, { text: "Estou pensando... 🤔", quoted: info });

  try {
    const ia = await fetchJson(`http://br2.bronxyshost.com:4130/ias/gemini?q=${q}&apikey=Yukizinho`);

    if (!ia || !ia.resultado) {
      throw new Error("Nenhum resultado encontrado.");
    }

    // Responder com o resultado da IA e selo verificado
    const verifiedMessage = {
      text: ia.resultado,
      footer: 'Verificado ✅',
      contextInfo: {
        externalAdReply: {
          title: 'Mai-Bot',
          body: 'Resposta da IA',
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: false,
          thumbnail: await getBuffer('http://br5.bronxyshost.com:4034/uploads/1730824894387.jpg'),
          sourceUrl: `https://chat.whatsapp.com/BiNEjqxUJtIJRunqkNRyWe`
        }
      }
    };
    await miwa.sendMessage(from, verifiedMessage, { quoted: loadingMessage });
  } catch (e) {
    console.error(e);
    await miwa.sendMessage(from, { text: "Ocorreu um erro ao tentar obter a resposta da IA.", quoted: loadingMessage });
  }

  // Enviar uma reação de conclusão
  await miwa.sendMessage(from, { react: { text: `✅`, key: info.key } });

  break;
}


        case 'hd':
          try {
            if (isMedia || isQuotedImage) {
              post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage;
              imagem = await downloadContentFromMessage(post, 'image');
              base64 = Buffer.from([]);
              for await (const send of imagem) {
                base64 = Buffer.concat([base64, send]);
              }
              reply(`Alterando a qualidade da foto para *HD*, aguarde um pouco!`);
              const link = await upload(base64);
              const { remini } = require('betabotz-tools');
              const results = await remini(link);
              if (results && results.image_data) {
                const imageUrl = results.image_data;
                await miwa.sendMessage(from, { image: { url: imageUrl } }, { quoted: info });
              } else {
                return reply('(Sem resposta do módulo para melhorar a imagem)');
              }
            } else {
              reply('Selecione uma imagem para melhorar a qualidade.');
            }
          } catch (e) {
            console.error(e);
            return reply('(Erro interno do servidor. Por favor, tente novamente mais tarde.)');
          }
          break

        case 'gemini':
          if (!q) return reply(`Faça uma pergunta para que o Gemini possa ajudar, você também pode mencionar uma imagem com o comando e fazer uma pergunta ao gemini sobre a imagem.\n\n*• Exemplo:* ${prefix + command} Olá tudo bem?`)
          try {
            const { GoogleGenerativeAI } = require("@google/generative-ai");
            const genAI = new GoogleGenerativeAI('AIzaSyAA9rJnbWVd0MRzhAiK7GTSxPrl4-cuA0E');
            const modelText = genAI.getGenerativeModel({ model: 'gemini-pro' });
            const modelImage = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });
            let imageData;
            let textResponse;
            const prompt = q;
            if (isQuotedImage || isMedia) {
              let post;
              if (isQuotedImage) {
                post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
              } else if (isMedia) {
                post = info.message.imageMessage;
              }
              const imagem = await downloadContentFromMessage(post, 'image');
              if (!imagem || imagem.length === 0) {
                return reply("_Erro ao processar a imagem. Por favor, tente novamente._");
              }
              let base64 = Buffer.from([]);
              for await (const send of imagem) {
                base64 = Buffer.concat([base64, send]);
              }
              imageData = {
                inlineData: {
                  data: base64.toString("base64"),
                  mimeType: "image/png",
                },
              };
              const imageName = `gemini_${Date.now()}.png`;
              fs.writeFileSync(`./src/${imageName}`, base64);
              fs.unlinkSync(`./src/${imageName}`);
              const result = await modelImage.generateContent([prompt, imageData]);
              textResponse = result.response.text();
              reply(textResponse)
            } else {
              const { response } = await modelText.generateContent(`${encodeURIComponent(q)}`);
              textResponse = response.text();
              reply(textResponse)
            }
          } catch (e) {
            console.error(e);
            return reply(`erro`);
          }
          break;

        case 'gpt':
        case 'chatgpt3':
          try {
            if (!q) return reply(`*Faça uma pergunta!*\n\nExemplo: ${prefix + command} mande uma receita de bolo`);
            const { openai } = require('betabotz-tools');
            const traduzirgpt = require('translate-google');
            const results = await openai(q);
            if (results && results.result) {
              const respostaIngles = results.result;
              const respostaPortugues = await traduzirgpt(respostaIngles, { to: 'pt' });
              reply(respostaPortugues)
            } else {
              return reply('(Sem resposta da OpenAI)');
            }
          } catch (e) {
            console.log(e);
            return reply('(Erro interno do servidor. Por favor, tente novamente mais tarde.)');
          }
          break


        case 'gptvoz':
          if (!q) return reply(`Ex: ${prefix}gpt Olá`)
          nznk = await fetch(`https://miwa-apis.online/api/ia/gpt?query=${encodeURI(q)}&apikey=` + API_KEY_MIWA).then(response => response.json())
          const gpts = require('./arquivos/funcoes/gtts')('pt')
          ranm = getRandom('.mp3')
          rano = getRandom('.ogg')
          gpts.save(ranm, `${nznk.resultado}`, function () {
            exec(`ffmpeg -i ${ranm} -ar 48000 -vn -c:a libopus ${rano}`, (err) => {
              miwa.sendMessage(from, { audio: fs.readFileSync(ranm), ptt: true, mimetype: "audio/mpeg" }, { quoted: info })
              DLT_FL(ranm)
              DLT_FL(rano)
            })
          })
          break

        case 'corretor':
          if (!q) return reply(`Ops, você não digitou o texto o qual deseja corrigir. Utiliza esse comando com alguma palavra ou texto!\n❓️ *Exemplo:* ${prefix}${command} Eu te mamo`)
          try {
            reply(`Verificando os erros ortográficos em seu texto ou palavra... *Aguarde!*`)
            anu1 = await fetchJson(`https://miwa-apis.online/api/open-ai_txt?TOKEN_GPT=${TOKEN_GPT}&q=Corrija gramaticalmente uma frase para o português brasileiro tradicional: ${q}`)
            msgSemQuoted(`📖 *Texto corrigido:* ${anu1.resultado[0].TextoCorrigido}`)
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log(e)
            } else {
              reply('🤓❌ *Ops amiguinho?!* Não e possível obter um resultado específico até a key da OpenAI seja definida...\n• Entre em contato com o dono, caso este erro ocorra novamente!')
            }
          }
          break

        case 'nasa':
          try {
            if (!q) return reply(`Exemplo: ${prefix}${command} 05-07-2003`)
            dataSab = await fetchJson(`http://kayserapis.tech:4197/api/nasaphoto?data=${q}&apikey=Sandrinho`)
            resultExp = await fetchJson(`http://kayserapis.tech:4197/api/info/translate?texto=${dataSab.nasa.explanation}&ling=pt&apikey=Sandrinho`)
            await miwa.sendMessage(from, { image: { url: dataSab.nasa.hdurl }, caption: mess.result_APOD(dataSab, resultExp) })
          } catch (e) {
            console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            reply(`❌️ Erro identificado no servidor! ❌️`);
          }
          break;

        case 'gerargrupos'://By: Aqua Bot
        case 'gerargrupo'://By: Aqua Bot
        case 'gerargp'://By: Aqua Bot
          if (!q) return reply("Ei, qual tipo de grupo?")
          reply(`🔎 _procurando grupos_ 🔍`)
          swp = await fetchJson(`https://tohka.tech/api/pesquisa/gpwhatsapp?nome=${q}&apikey=nduok4MPQR`)
          teks = `═══════ ❯❯ *Mai Bot - GRUPOS* ❮❮\n\n`;
          for (let i of swp) {
            teks += "▧⃯⃟NOME『" + i.nome + "』\n"
            teks += "▧⃯⃟DESCRIÇÃO→ " + i.descrição + "\n"
            teks += "▧⃯⃟LINK→ " + i.link + "\n\n"
          }
          teks += `☆ヅ━━━━━━━Mai Bot━━━━━━━━ヅ☆`
          reply(teks)
          break

        case 'cases':
          if (!SoDono) return reply("Você não é dono para utilizar este comando...")
          try {
            const listCases = () => {
              const fileContent = fs.readFileSync("index.js").toString();
              const caseNames = fileContent.match(/case\s+'(.+?)'/g);
              if (caseNames) {
                return caseNames.map((caseName, index) => `${index + 1}. ${caseName.match(/'(.+?)'/)[1]}`).join('\n');
              } else {
                reply("nenhuma case encontrada.")
              }
            }
            await miwa.sendMessage(from, { text: listCases() }, { quoted: info });
          } catch (e) {
            console.log(e)
            reply('ocorreu um erro ao obter as cases.')
          }
          break

        case 'simi':
          if (!isGroup) return reply(mess.onlyGroup())
          try {
            datasimi = await fetchJson(`https://api.simsimi.vn/v1/simtalk`, {
              method: 'POST',
              headers: { 'content-type': "application/x-www-form-urlencoded" },
              body: "text=" + q + "&lc=pt"
            })
            return reply(datasimi.message)
          } catch (e) {
            return reply("Resposta não encontrada..")
          }
          break

        case 'simih':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isSimi) return reply('O modo simi está ativo')
            dataGp[0].simi1 = true
            setGp(dataGp)
            reply('Ativado com sucesso o modo simi neste grupo 😗..')
          } else if (Number(args[0]) === 0) {
            if (!isSimi) return reply('Já está Desativado.')
            dataGp[0].simi1 = false
            setGp(dataGp)
            reply('Desativado modo simi com sucesso neste grupo 😡️')
          } else {
            reply('1 para ativar, 0 para desativar, lerdao vc em KKKKK')
          }
          break

        case 'simih2':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isSimi2) return reply('O modo Simi está ativo')
            dataGp[0].simi2 = true
            setGp(dataGp)
            reply('Ativado com sucesso o modo simi neste grupo 😗..')
          } else if (Number(args[0]) === 0) {
            if (!isSimi2) return reply('Já está Desativado.')
            dataGp[0].simi2 = false
            setGp(dataGp)
            reply('Desativado modo simi com sucesso neste grupo 😡️')
          } else {
            reply('1 para ativar, 0 para desativar, lerdao vc em KKKKK')
          }
          break

        case 'autofigu': case 'autosticker':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAutofigu) return reply('Ja esta ativo')
            dataGp[0].autosticker = true
            setGp(dataGp)
            reply('✔️ Ativou com sucesso o recurso de auto figurinhas neste grupo.')
          } else if (Number(args[0]) === 0) {
            if (!isAutofigu) return reply('Ja esta Desativado')
            dataGp[0].autosticker = false
            setGp(dataGp)
            reply('✔️ Desativou com sucesso o recurso de auto figurinhas neste grupo.️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'autorepo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAutorepo) return reply('Ja esta ativo')
            dataGp[0].autoresposta = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de auto resposta neste grupo. 📝')
          } else if (Number(args[0]) === 0) {
            if (!isAutorepo) return reply('Ja esta Desativado')
            dataGp[0].autoresposta = false
            setGp(dataGp)
            reply('‼️ Desativou com sucesso o recurso de auto resposta neste grupo.️ 📝')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'gerarrg': {
          const randomRG = () => {
            const numbers = '0123456789';
            let rg = '';
            for (let i = 0; i < 9; i++) {
              rg += numbers.charAt(Math.floor(Math.random() * numbers.length));
            }
            return rg;
          };

          const rg = randomRG();
          const name = `${ryuunome()}`; // Using the provided name variable

          const info = `
        ════════✪══✪═══════
        📄 *Gerador de RG* 📄
        ════════✪══✪═══════
        👤 *Nome*: ${name}
        🆔 *RG*: ${rg}
        ════════✪══✪═══════
        🔄 *Gerado com sucesso!*
        ════════✪══✪═══════
    `;

          reply(info);
        }
          break;

        case 'geraremail': {
          const randomName = () => {
            const names = [
              "Carlos", "Fernanda", "Mariana", "Pedro", "João", "Paula", "Lucas", "Ana", "Gabriel", "Camila",
              "Rafael", "Juliana", "Mateus", "Sofia", "Guilherme", "Larissa", "Felipe", "Isabela", "Rodrigo", "Bianca",
              "Vinícius", "Alice", "Daniel", "Luiza", "Leonardo", "Beatriz", "Henrique", "Clara", "Ricardo", "Eduarda",
              "Thiago", "Livia", "André", "Laura", "Bruno", "Marina", "José", "Helena", "Marcelo", "Patricia"
            ];
            return names[Math.floor(Math.random() * names.length)];
          };

          const randomDomain = () => {
            const domains = [
              "example.com", "email.com", "domain.com", "webmail.com", "mail.com", "inbox.com", "test.com", "random.com",
              "site.com", "online.com", "internet.com", "web.com", "myemail.com", "mailbox.com", "provider.com", "service.com",
              "host.com", "server.com", "custom.com", "domain.net"
            ];
            return domains[Math.floor(Math.random() * domains.length)];
          };

          const randomUsername = () => {
            const adjectives = ["cool", "awesome", "fast", "brave", "fancy", "wise", "smart", "creative", "happy", "kind"];
            const nouns = ["lion", "tiger", "bear", "fox", "eagle", "wolf", "panda", "shark", "whale", "dolphin"];
            let username = "";
            for (let i = 0; i < 3; i++) {
              username += `${adjectives[Math.floor(Math.random() * adjectives.length)]}${nouns[Math.floor(Math.random() * nouns.length)]}`;
              if (i < 2) username += ".";
            }
            return username;
          };

          const randomPassword = () => {
            const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
            let password = "";
            for (let i = 0; i < 12; i++) {
              password += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return password;
          };

          const randomIP = () => {
            return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
          };

          const name = randomName();
          const username = randomUsername();
          const domain = randomDomain();
          const email = `${username}@${domain}`;
          const password = randomPassword();
          const ip = randomIP();

          const info = `
        ════════✪══✪═══════
        📧 *Gerador de Email* 📧
        ════════✪══✪═══════
        👤 *Nome*: ${name}
        📧 *Email*: ${email}
        🔑 *Senha*: ${password}
        🌐 *IP*: ${ip}
        ════════✪══✪═══════
        🔄 *Gerado com sucesso!*
        ════════✪══✪═══════
    `;

          reply(info);
        }
          break;

        case 'gerarcpf': {
          function gerarCPF() {
            const rand = () => Math.floor(Math.random() * 9);
            let cpf = [];
            for (let i = 0; i < 9; i++) {
              cpf.push(rand());
            }
            cpf.push(digitoVerificador(cpf));
            cpf.push(digitoVerificador(cpf));
            return cpf.join('');
          }

          function digitoVerificador(cpf) {
            const reducer = (sum, current, index) => sum + current * (cpf.length + 1 - index);
            const remainder = cpf.reduce(reducer, 0) % 11;
            return remainder < 2 ? 0 : 11 - remainder;
          }

          const cpf = gerarCPF();
          const formatCPF = (cpf) => `${cpf.slice(0, 3)}.${cpf.slice(3, 6)}.${cpf.slice(6, 9)}-${cpf.slice(9, 11)}`;
          const randomAge = () => Math.floor(Math.random() * 82) + 18;
          const randomName = () => {
            const names = [
              "Carlos", "Fernanda", "Mariana", "Pedro", "João", "Paula", "Lucas", "Ana", "Gabriel", "Camila",
              "Rafael", "Juliana", "Mateus", "Sofia", "Guilherme", "Larissa", "Felipe", "Isabela", "Rodrigo", "Bianca",
              "Vinícius", "Alice", "Daniel", "Luiza", "Leonardo", "Beatriz", "Henrique", "Clara", "Ricardo", "Eduarda"
            ];
            return names[Math.floor(Math.random() * names.length)];
          };
          const randomCity = () => {
            const cities = [
              "São Paulo", "Rio de Janeiro", "Belo Horizonte", "Porto Alegre", "Curitiba", "Recife", "Salvador", "Brasília", "Fortaleza", "Manaus",
              "Belém", "Goiânia", "Campinas", "São Luís", "Natal", "Maceió", "João Pessoa", "Aracaju", "Cuiabá", "Campo Grande",
              "Florianópolis", "Vitória", "Macapá", "Boa Vista", "Palmas", "Teresina", "Porto Velho", "Rio Branco", "Sorocaba", "Niterói"
            ];
            return cities[Math.floor(Math.random() * cities.length)];
          };
          const randomState = () => {
            const states = [
              "SP", "RJ", "MG", "RS", "PR", "PE", "BA", "DF", "CE", "AM",
              "PA", "GO", "MA", "RN", "AL", "PB", "SE", "MT", "MS", "SC",
              "ES", "AP", "RR", "TO", "PI", "RO", "AC", "RJ", "SP", "MG"
            ];
            return states[Math.floor(Math.random() * states.length)];
          };

          const info = `
        ════════✪══✪═══════
        🎉 *Gerador de CPF* 🎉
        ════════✪══✪═══════
        📄 *CPF*: ${formatCPF(cpf)}
        👤 *Nome*: ${randomName()}
        📅 *Idade*: ${randomAge()} anos
        🌆 *Cidade*: ${randomCity()}
        🏙️ *Estado*: ${randomState()}
        ════════✪══✪═══════
        🔄 *Gerado com sucesso!*
        ════════✪══✪═══════
    `;

          reply(info);
        }
          break;

        case 'blaze': {//criador: ryuu Akiyamax
          if (!isModobn) return reply(`O modo brincadeira está desligado, peça ao administrador para ligá-lo`);

          if (args.length < 1 || isNaN(args[0])) return reply(`Modo certo de se usar ${prefix}blaze valor\n\nExemplo:\n${prefix}blaze 5000`);

          const aposta = parseInt(args[0]);
          if (aposta < 50) return reply(`A aposta mínima é de 50 Coins`);
          if (checkATMuser(sender) < aposta) return reply(`Você não tem Coins suficientes para fazer essa aposta, você precisa ter no mínimo ${aposta} Coins`);

          const emojis = ['🧨', '🏆', '🎰'];
          const getRandomEmoji = () => emojis[Math.floor(Math.random() * emojis.length)];

          const row1 = [getRandomEmoji(), getRandomEmoji(), getRandomEmoji()];
          const row2 = [getRandomEmoji(), getRandomEmoji(), getRandomEmoji()];
          const row3 = [getRandomEmoji(), getRandomEmoji(), getRandomEmoji()];

          const isWinningLine = (row) => row[0] === row[1] && row[1] === row[2];

          let resultado, message;
          if (isWinningLine(row1) || isWinningLine(row2) || isWinningLine(row3)) {
            const ganho = aposta * 2;
            resultado = ganho;
            message = `🎉 Você ganhou!  *+${ganho} 🪙*`;
          } else {
            resultado = -aposta;
            message = `😔 Você perdeu!  *-${aposta} 🪙*`;
          }

          const displayMessage = `
    ┏━━━━━ 🔥 BLAZE 🔥 ━━━━━┓
    ┃
    ┃ ${row1.join(' ')}
    ┃ ${row2.join(' ')}
    ┃ ${row3.join(' ')}
    ┃
    ┗━━━━━ 🔥 BLAZE 🔥 ━━━━━┛
    
    ${message}
    `;

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: displayMessage,
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Jogar novamente",
                        id: `${prefix}blaze ${q}`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Ver banco",
                        id: `${prefix}banco`
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              }
            },
            {}
          ).then((r) => console.log(r));

          addKoinUser(sender, resultado);
          break;
        }

        case 'ff': // Criador: ryuu Akiyamax
          if (!isModobn) return reply(`Modo brincadeira está desligado, peça ao administrador para ligá-lo`);

          const kills = Math.floor(Math.random() * 32); // Número aleatório de kills entre 0 e 9
          const earnings = kills * 10; // Cada kill vale R$ 10

          const messagcue = `
🔫 Você jogou uma partida de Free Fire e conseguiu ${kills} kills!
💰 Ganhou R$ ${earnings} pela sua performance no jogo.
`;

          await btncomfoto(from, messagcue, "", "", "Clique para jogar novamente", { url: 'https://telegra.ph/file/d8d73e5051f878730c813.jpg' }, "image", info, {}, [
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Jogar novamente",
                id: `${prefix}ff`
              }),
            },
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Ver banco",
                id: `${prefix}banco`
              }),
            }
          ]);

          addKoinUser(sender, +earnings);
          break;

        case 'autototext':
          if (!isGroup) return reply(enviar.msg.grupo);
          if (!isGroupAdmins) return reply(enviar.msg.adm);
          if (args.length < 1) return reply(`Use 1 para ativar, 0 para desativar o recurso Auto-Transcrever.`);

          if (Number(args[0]) === 0) {
            if (!dataGp[0].autototext) return reply(`O modo Auto-Transcrever já está desativado neste grupo!`);
            dataGp[0].autototext = false;
            setGp(dataGp);
            reply(`_*✖ Desativou com sucesso o Auto-Transcrever neste grupo, agora o bot não irá transcrever os áudios enviados.*_`);
          } else if (Number(args[0]) === 1) {
            if (dataGp[0].autototext) return reply(`O modo Auto-Transcrever já está ativado neste grupo!`);
            dataGp[0].autototext = true;
            setGp(dataGp);
            reply(`_*✔ Ativou com sucesso o Auto-Transcrever neste grupo, agora o bot irá transcrever todos os áudios enviados.*_`);
          } else {
            reply(`Use 1 para ativar, 0 para desativar o recurso Auto-Transcrever.`);
          }
          break;

        case 'modobrincadeira':
        case 'modobrincadeiras':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isModobn) return reply('O modo brincadeira já está ativo')
            dataGp[0].jogos = true
            setGp(dataGp)
            reply('🎯 Ativou com sucesso o recurso de Modo brincadeira neste grupo. 🪀')
          } else if (Number(args[0]) === 0) {
            if (!isModobn) return reply('O modobrincadeira já está desativado.')
            dataGp[0].jogos = false
            setGp(dataGp)
            reply('🎯 Desativou com sucesso o recurso de Modo brincadeira neste grupo. 🪀')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'patente':
        case 'level':
          if (!isGroup) return reply(mess.onlyGroup())
          resul = `${tempo}, usuário: @${sender.split("@")[0]}, aqui está suas informações de patente e level para saber como está atualmente:\n\n📍 Patente: ${patente} | 🏆 Level: ${level_up}`
          await miwa.sendMessage(from, { text: resul, mentions: [sender] }, { quoted: info })
          break

        case 'leveling':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply('Ative pressione 1, Desativar pressione 0')
          if (Number(args[0]) === 1) {
            if (isLevelingOn) return reply('*O recurso de nível já estava ativo antes*')
            dataGp[0].level = true
            setGp(dataGp)
            reply(retornar.levelon)
          } else if (Number(args[0]) === 0) {
            if (!isLevelingOn) return reply(`O recurso de level já está Desativado neste grupo.`)
            dataGp[0].level = false
            setGp(dataGp)
            reply(retornar.leveloff)
          } else {
            reply('Adicionar parâmetro 1 ou 0 ')
          }
          break

        case 'bangp':
        case 'unbangp':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!SoDono) return reply(mess.onlyOwner())
          if (command == 'bangp') {
            if (isBanchat) return reply(`Este grupo já está banido.`)
            dataGp[0].bangp = true
            setGp(dataGp)
            reply(`Grupo banido com sucesso`)
          } else {
            if (!isBanchat) return reply(`Este grupo não está mais banido.`)
            dataGp[0].bangp = false
            setGp(dataGp)
            reply(`Grupo desbanido...`)
          }
          break

        case 'nuke': case 'arquivargp'://BY: NK DOMINA
          if (!SoDono) return reply(`PASSANDO A PIKA NO GRUPO😈😈`)
          if (!isBotGroupAdmins) return reply(`preciso de adm, mestre🥹`)
          if (info.key.fromMe) return
          function banirtodos() {
            var r_banirtodos = Math.floor(Math.random() * groupMembers.length + 0)
            nmrbot = botNumber.split("@")[0]
            var resp = `${groupMembers[r_banirtodos].id.split("@")[0]}`
            if (resp === numerodono || resp === nmrbot) {
              return
            } else {
              miwa.groupParticipantsUpdate(from, [resp + "@s.whatsapp.net"], 'remove')
            }
          }
          myinterval = setInterval(banirtodos, 1000)
          if (groupMembers.length <= 2) {
            clearInterval(myinterval);
          }
          break

        case 'modonsfw':
        case 'nsfw':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (args.length < 1) return reply(`Digite ${prefix}Modonsfw 1 para ativar e ${prefix}Modonsfw 0 para desativar`)
          if (Number(args[0]) === 1) {
            if (isNsfw) return reply('O modo nsfw já está ativo.')
            dataGp[0].nsfw = true
            setGp(dataGp)
            reply(`✓ Ativado com sucesso o modo nsfw +18 no grupo: *${groupMetadata.subject}*`)
          } else if (Number(args[0]) === 0) {
            if (!isNsfw) return reply('O modo nsfw já está desativado.')
            dataGp[0].nsfw = false
            setGp(dataGp)
            reply(`✓ Modo Nsfw +18 desativado com sucesso no grupo: *${groupMetadata.subject}*`)
          } else {
            reply('1 para ativar, 0 para desligar')
          }
          break

        case 'antipalavrão':
        case 'antipalavrao':
        case 'antipalavra':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply(`[❗] 1 / 0, Exemplo ${prefix + command} 1`)
          if (Number(args[0]) === 1) {
            if (isPalavrao) return reply('Ja esta ativo.')
            dataGp[0].antipalavrao.active = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de anti palavras hardcore neste grupo 📝')
          } else if (Number(args[0]) === 0) {
            if (!isPalavrao) return reply('Ja esta Desativado')
            dataGp[0].antipalavrao.active = false
            setGp(dataGp)
            reply('‼️ Desativou com sucesso o recurso de anti palavra harcore neste grupo. 📝️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break


        case 'addpalavra':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isPalavrao) return reply('Anti palavrão desativado!')
          if (args.length < 1) return reply(`Use assim : ${prefix + command} [palavrão]. exemplo ${prefix + command} puta`)
          texto = args.join(' ').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "")
          if (isPalavras.includes(texto)) return reply('Já foi adicionada')
          dataGp[0].antipalavrao.palavras.push(texto)
          setGp(dataGp)
          reply('Palavrão adicionado com sucesso!')
          break

        case 'delpalavra':
          if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyOwner())
          if (!isPalavrao) return reply('Anti palavrão desativado!')
          if (args.length < 1) return reply(`Use assim: ${prefix + command} [palavrão]. Exemplo: ${prefix + command} Rapariga`)
          texto = args.join(' ').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "")
          if (!isPalavras.includes(texto)) return reply('Já foi removida')
          var i = dataGp[0].antipalavrao.palavras.indexOf(texto)
          dataGp[0].antipalavrao.palavras.splice(i, 1)
          setGp(dataGp)
          reply('Palavrão removido da lista com sucesso!')
          break

        case 'listapalavrão': case 'listapalavra':
        case 'listpalavra':
          if (!isPalavrao) return reply('Anti palavrão desativado!')
          let lbw = `Esta é a lista de palavrão\nTotal: ${isPalavras.length}\n`
          for (let i of isPalavras) {
            lbw += `➸ ${i}\n`
          }
          await reply(lbw)
          break

        case 'limitecaracteres':
        case 'limiteflood':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (args.length < 1) return reply(`Digite ${prefix + command} 1 para ativar`)
          if (Number(args[0]) === 1) {
            if (isAntiFlood) return reply(`🌀 O recurso limite de caracteres já está ativo no grupo.`)
            dataGp[0].limitec.active = true
            setGp(dataGp)
            reply(`✔️ O recurso limite de caracteres foi ativado nesse grupo 📝`)
          } else if (Number(args[0]) === 0) {
            if (!isAntiFlood) return reply('✔️ O recurso limite de caracteres não está ativado no grupo 📝')
            dataGp[0].limitec.active = false
            setGp(dataGp)
            reply('O recurso limite de caracteres foi desativado nesse grupo ✔️')
          } else {
            reply(`Digite ${prefix + command} 1 para ativar, 0 para desativar o recurso`)
          }
          break

        case 'limitec_global':
        case 'limitec':
          if (!SoDono && !isnit && !ischyt) return reply(mess.onlyOwner())
          if (!isAntiFlood) return reply(`Ative este recurso primeiro ${prefix}limiteflood 1`)
          if (!q) return reply(`Cade a quantidade? Ex: ${prefix + command} 5000`)
          if (isNaN(q) == true) return reply('Digite apenas números')
          if (command == 'limitec') {
            dataGp[0].limitec.quantidade = q
            setGp(dataGp)
            reply(`Foi alterado o limite de caracteres para: ${q}`)
          } else {
            var data = { limitefl: q }
            fs.writeFileSync('./database/usuarios/flood.json', JSON.stringify(data, null, '\t'))
            reply(`Foi adicionado um limite global de caracteres de: ${q}`)
          }
          break

        case 'status':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins && !SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe) return reply(mess.onlyAdmins()) // │➱ Anti Spam: ${isAntiSpam ?  '✓ - Função ativa.' : '✕ - Não ativada.'}
          reply(`Status de funcionalidades ativaveis para proteger o grupo / se divertir com seus participantes. 
As funcionalidades de *Anti Privado Block - Anti Ligação*, são ativações que somente o dono, pode executar, _então caso esteja ativa você não poderá executar comandos no privado ou fazer ligações ao número do bot._

➱ Anti Ligação: ${isAnticall ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti PV Block: ${isAntiPv ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Imagem: ${isAntiImg ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Vídeo: ${isAntiVid ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Áudio: ${isAntiAudio ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Sticker: ${isAntiSticker ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Documento: ${Antidoc ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Contato ${isAntiCtt ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Localização: ${Antiloc ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Link Grupo: ${isAntilinkgp ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Link Hard: ${isAntiLinkHard ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Fake: ${isAntifake ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Notas: ${isAntiNotas ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Catalogo: ${isAnticatalogo ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Anti Palavrão: ${isPalavrao ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Limite Caracteres: ${isAntiFlood ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Bem Vindo 1: ${isWelkom ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Bem Vindo 2: ${isWelkom2 ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Simi 1: ${isSimi ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Simi 2: ${isSimi2 ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Auto Sticker: ${isAutofigu ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Auto Resposta: ${isAutorepo ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Modo Brincadeira: ${isModobn ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Level ${isLevelingOn ? '✓ - Função ativa.' : '✕ - Não ativada.'}
➱ Modo Nsfw: ${isNsfw ? '✓ - Função ativa.' : '✕ - Não ativada.'}`)
          break

        case 'reiniciar':
          setTimeout(async () => {
            reply("Reiniciando..")
            setTimeout(async () => {
              process.exit()
            }, 1200)
          }, 1000)
          break

        case 'novoqr':
          if (!SoDono) return reply(mess.onlyOwner());
          reply("Será apagado o qrcode, e irá gerar um novo, fique atento no terminal para ler novamente..");
          setTimeout(() => {
            fs.rmdirSync(folderUserAuth, { recursive: true });
          }, 1500)
          break;

        //==========(Sticker-Stickers)===========\\

        case 'emoji': case 'semoji':
          if (!q) return reply(`*Exemplo:* ${prefix}emoji ☹️/whatsapp`)
          emot = q.split('/')[0]
          jemot = q.split('/')[1]
          if (jemot == 'apple') { idemot = 0 }
          else if (jemot == 'google') { idemot = 1 }
          else if (jemot == 'samsung') { idemot = 2 }
          else if (jemot == 'microsoft') { idemot = 3 }
          else if (jemot == 'whatsapp') { idemot = 4 }
          else if (jemot == 'twitter') { idemot = 5 }
          else if (jemot == 'facebook') { idemot = 6 }
          else if (jemot == 'joypixels') { idemot = 7 }
          else if (jemot == 'openmoji') { idemot = 8 }
          else if (jemot == 'emojidex') { idemot = 9 }
          else if (jemot == 'lg') { idemot = 10 }
          else if (jemot == 'htc') { idemot = 11 }
          else if (!jemot) { idemot = 4 }
          else {
            return reply(`Exemplo: ${prefix}emoji ☹️/whatsapp`)
          }
          reply(mess.wait())
          if (idemot == undefined) return
          emoji.get(emot)
            .then(emoji => {
              sendStickerFromUrl(from, emoji.images[idemot].url)
            }).catch(e => {
              reply("Emoji não encontrado.. Tente com outro emoji para ver está funcionando..")
            })
          break

        case 'adicionarmusica':
        case 'adicionarmúsica':
        case 'addmusica':
        case 'addmúsica':
        case 'addsong'://criador: ryuu, bot: Akiyamax
        case 'adds':

          if (!q) return reply('Por favor, forneça o nome da música.');
          const addSongMsg = addSongToPlaylist(sender, q);
          reply(addSongMsg);
          break;

        case 'removermusica':
        case 'removermúsica':
        case 'removemusica':
        case 'removemúsica':
        case 'removesong':
        case 'tirarmusica':
        case 'rems'://criador: ryuu, bot: Akiyamax

          if (!q) return reply('Por favor, forneça o nome da música.');
          const removeSongMsg = removeSongFromPlaylist(sender, q);
          reply(removeSongMsg);
          break;

        case 'limparplaylist':
        case 'clearplaylist':
        case 'clear'://criador: ryuu, bot: Akiyamax

          const clearPlaylistMsg = clearUserPlaylist(sender);
          reply(clearPlaylistMsg);
          break;

        case 'verplaylist': // Criador: ryuu, bot: AkiyamaX

          const allSongs = loadUserPlaylist(sender);
          if (allSongs.length === 0) {
            return reply('Sua playlist está vazia.');
          }

          const playPlaylistMsg = allSongs.map((song, index) => `${index + 1}. ${song.name}`).join('\n');

          const rows = allSongs.map((song, index) => ({
            header: "🎵 Música",
            title: `${index + 1}. ${song.name}`,
            description: `Clique para tocar`,
            id: `${prefix}play ${song.name}`,
          }));

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: `Aqui estão as músicas:\n\n${playPlaylistMsg}`,
                },
                nativeFlowMessage: {
                  buttons: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "Lista de Músicas",
                      sections: [{
                        title: "🎵 Músicas",
                        rows: rows,
                      }]
                    })
                  }],
                  messageParamsJson: "",
                },
              },
            },
            {}
          ).then((r) => console.log(r));
          break;


        case 'baixarplaylist':

          if (!menc_os2 || menc_os2.length === 0) return reply('Por favor, mencione o usuário cuja playlist deseja baixar.');
          console.log(`Baixando playlist para o usuário: ${menc_os2}`); // Log para depuração
          const targetPlaylist = loadUserPlaylist(menc_os2);
          console.log(`Playlist do usuário: ${JSON.stringify(targetPlaylist)}`); // Log para depuração
          if (targetPlaylist.length === 0) {
            return reply('A playlist do usuário está vazia.');
          }

          const currentPlaylist = loadUserPlaylist(sender);
          const updatedPlaylist = [...currentPlaylist, ...targetPlaylist];
          saveUserPlaylist(sender, updatedPlaylist);
          reply('A playlist foi baixada com sucesso.');
          break;

        case 'compartilharplaylist':
        case 'shareplaylist':

          if (!menc_os2 || menc_os2.length === 0) return reply('Por favor, mencione o usuário com quem deseja compartilhar a playlist.');


          const sharePlaylistMsg = shareUserPlaylist(sender, menc_os2);
          reply(sharePlaylistMsg);
          break;

        case 'emoji-mix':
        case 'emojimix':
          txt = q.replace(" +", "+").replace("+ ", "+").replace(" + ", "+")
          var [emj1, emj2] = txt.split("+")
          if (!q.includes("+")) return reply(`Olá, está faltando o +\nExemplo: ${prefix + command} 😪+🤣`)
          try {
            reply(mess.wait())
            sendStickerFromUrl(from, `https://miwa-apis.online/api/emojimix?emoji1=${encodeURI(emj1)}&emoji2=${encodeURI(emj2)}&apikey=` + API_KEY_MIWA)
          } catch (e) {
            if (String(e).includes(API_KEY_MIWA)) {
              console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              reply('Ops não foi possivel fazer esse mix de emoji ou pode ter ocorrido algum problema no sistema..')
            }
          }
          break

        case 'figfundo':
        case 'figvideo':
        case 'figusemfundo':
        case 'sfundo':
          if ((isMedia && !info.message.videoMessage || isQuotedImage) && !q.length <= 1) {
            rafa = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
            reply(mess.wait())
            buff = await getFileBuffer(rafa, 'image')
            bas64 = `data:image/jpeg;base64,${buff.toString('base64')}`
            anu = args.join(' ').split('|')
            satu = anu[0] !== '' ? anu[0] : `Usuário: ${pushname}`
            sd = `📍Criado por: ${NomeDoBot}`
            dua = typeof anu[1] !== 'undefined' ? anu[1] : `${sd}`
            var mantap = await convertSticker(bas64, `${dua}`, `${satu}`)
            var sti = new Buffer.from(mantap, 'base64');
            await miwa.sendMessage(from, { sticker: sti }, { quoted: info })
          } else {
            return reply(`So imagem mn -_-`)
          }
          break

        case 'rbale':
          if (!isQuotedSticker) return reply('Marque uma figurinha...')
          encmediats = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
          reply(mess.wait())
          bas64 = `data:image/jpeg;base64,${encmediats.toString('base64')}`
          var mantap = await convertSticker(bas64, `📍Criado por: ${NomeDoBot}`, `Usuário: ${pushname}`)
          var sti = new Buffer.from(mantap, 'base64');
          await miwa.sendMessage(from, { sticker: sti }, { quoted: info })
            .catch((err) => {
              reply(`❎ Erro, tenta mais tarde`);
            })
          break

        case 'addcase': {
          if (!q) return reply("Está faltando nada não??");
          if (!SoDono) return;
          const pula = [fs.readFileSync('index.js', 'utf8').slice(0, fs.readFileSync('index.js', 'utf8').lastIndexOf('break') + 5), q, fs.readFileSync('index.js', 'utf8').slice(fs.readFileSync('index.js', 'utf8').lastIndexOf('break') + 5)].join('\n\n\n\n');
          fs.writeFileSync('index.js', pula);
          reply('Nova case adicionada com sucesso!');
          break
        };

        case 'rename':
        case 'roubar':
          setTimeout(() => { reagir(from, "✅") }, 300)
          if (!isQuotedSticker) return reply('Marque uma figurinha...')
          encmediats = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
          var kls = q
          var pack = kls.split("/")[0];
          var author2 = kls.split("/")[1];
          if (!q) return reply('*Falta um nome para renomear a figurinha... ;-;*')
          if (!pack) return reply(`*Necessita de um nome antes da barra ( / ), ex:*
${prefix + command} ${pushname + q}`)
          if (!author2) return reply(`*Falta um complemento, ex:*
${prefix + command} ${q}/complemento`)
          reply(`𝙿𝚊𝚌𝚔 𝙽𝚊𝚖𝚎: _"${pack}"_
𝙰𝚞𝚝𝚑𝚘𝚛 𝙽𝚊𝚖𝚎: _"${author2}"_
-------------------------------------------------------------
▧⃯⃟𝚁𝚎𝚗𝚘𝚖𝚎𝚊𝚗𝚍𝚘 𝚂𝚞𝚊 𝙵𝚒𝚐𝚞𝚛𝚒𝚗𝚑𝚊ฺ͘.•🛸 ݈݇─`)
          base64 = `data:image/jpeg;base64,${encmediats.toString('base64')}`
          var mantap = await convertSticker(bas64, `${author2}`, `${pack}`)
          var sti = new Buffer.from(mantap, 'base64');
          await miwa.sendMessage(from, { sticker: sti, contextInfo: { externalAdReply: { title: `${pack}|${author2}`, body: "", previewType: "PHOTO", thumbnail: sti } } }, { quoted: seloctt })
            .catch((err) => {
              reply(`❌ Erro, tenta mais tarde`);
            })
          break

        case 'fstiker':
        case 'fsticker':
        case 'f':
          var RSM = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
          var boij = RSM?.imageMessage || info.message?.imageMessage || RSM?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessage?.message?.imageMessage || RSM?.viewOnceMessage?.message?.imageMessage
          var boij2 = RSM?.videoMessage || info.message?.videoMessage || RSM?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessage?.message?.videoMessage || RSM?.viewOnceMessage?.message?.videoMessage
          if (boij) {
            var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ ☁️ ⃟ᴄᴏɴᴛᴀᴛᴏᴅᴏɴᴏ \n↳ 51 94709091!`
            var author2 = `↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
            reply(mess.wait())
            owgi = await getFileBuffer(boij, 'image')
            let encmediaa = await sendImageAsSticker(miwa, from, owgi, info, { packname: pack, author: author2 })
            await DLT_FL(encmediaa)
          } else if (boij2 && boij2?.seconds < 11) {
            var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ ☁️ ⃟ᴄᴏɴᴛᴀᴛᴏᴅᴏɴᴏ \n↳ 51 94709091!`
            var author2 = `↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
            reply(mess.wait())
            owgi = await getFileBuffer(boij2, 'video')
            let encmedia = await sendVideoAsSticker(miwa, from, owgi, info, { packname: pack, author: author2 })
            await DLT_FL(encmedia)
          } else {
            reply(`Enviar imagem / vídeo / gif com legenda \n${prefix}sticker (duração do adesivo de vídeo de 1 a 10 segundos)`)
          }
          break

        case 'figu':
          if (fs.existsSync(DF_TJ)) return reply("Aguarde um momento, e realize o pedido novamente, não seja tão rápido...")
          var DF_TJ = "./database/data/CVF.json"
          fs.writeFileSync(DF_TJ, JSON.stringify([isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage || isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage]))
          var PUXJ = JSON.parse(fs.readFileSync(DF_TJ))
          var DFN = PUXJ[0]
          DFN.sticker = { url: DFN.url }
          await delay(1200)
          DLT_FL(DF_TJ)
          await miwa.sendMessage(from, DFN)
          break

        case 'st':
        case 'stk':
        case 'sticker':
        case 's':
          var RSM = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
          var boij2 = RSM?.imageMessage || info.message?.imageMessage || RSM?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessage?.message?.imageMessage || RSM?.viewOnceMessage?.message?.imageMessage
          var boij = RSM?.videoMessage || info.message?.videoMessage || RSM?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessage?.message?.videoMessage || RSM?.viewOnceMessage?.message?.videoMessage
          if (boij2) {
            var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ ☁️ ⃟ᴄᴏɴᴛᴀᴛᴏᴅᴏɴᴏ \n↳ 51 94709091!`
            var author2 = `↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
            owgi = await getFileBuffer(boij2, 'image')
            let encmediaa = await sendImageAsSticker2(miwa, from, owgi, info, { packname: pack, author: author2 })
            await DLT_FL(encmediaa)
          } else if (boij && boij.seconds < 11) {
            var pack = `👑 ⃟ᴄʀɪᴀᴅᴀ ᴘᴏʀ\n↳ ${NomeDoBot}\n\n↧ ☁️ ⃟ᴄᴏɴᴛᴀᴛᴏᴅᴏɴᴏ \n↳ 51 94709091!`
            var author2 = `↧ 🥀 ⃟ɴɪᴄᴋ ᴅᴏɴᴏ\n↳ ${NickDono}\n\n↧ 💻 ⃟ғᴇɪᴛᴀ ᴘᴏʀ:\n↳ ${pushname}`
            owgi = await getFileBuffer(boij, 'video')
            let encmedia = await sendVideoAsSticker2(miwa, from, owgi, info, { packname: pack, author: author2 })
            await DLT_FL(encmedia)
          } else {
            return reply(`Marque uma imagem, ou um vídeo de ate 9.9 segundos, ou uma visualização única, para fazer figurinha, com o comando ${prefix + command}`)
          }
          break

        case 'toimg':
          if (!isQuotedSticker) return reply('❌ adesivo de resposta um ❌')
          try {
            reply(mess.wait())
            buff = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
            await miwa.sendMessage(from, { image: buff }, { quoted: info }).catch(e => {
              console.log(e);
              reply('ERRO!!')
            })
          } catch {
            reply("Erro..")
          }
          break

        //=============(LOGOS)=============\\



        //==========(PLAQUINHAS-LOGOS)===========\

        case 'apibot':
          reagir(from, "✅")
          api = await fetchJson(`https://miwa-apis.online/api/keyerrada?apikey=` + API_KEY_MIWA)
          api2 = `${tempo} ${pushname}

✔️ Você Tem『 ${api.limite_de_request} 』Downloads Disponíveis...`
          reply(api2)
          break

        //=======================================\\

        case 'metadinha': {
          sendMsg = await miwa.sendMessage(from, { react: { text: `👫`, key: info.key } })
          reply(mess.wait())
          let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
          let random = anu[Math.floor(Math.random() * anu.length)]
          await miwa.sendMessage(from, { image: { url: random.male }, caption: `Perfil Masculino 🤵` }, { quoted: selo })
          await miwa.sendMessage(from, { image: { url: random.female }, caption: `Perfil Feminino 👰` }, { quoted: selo })
        }
          break

        case 'comunismo':
        case 'bolsonaro':
        case 'bnw':
        case 'beautiful':
        case 'blur':
        case 'affect':
        case 'del':
        case 'circle':
        case 'dither':
        case 'facepalm':
        case 'invert':
        case 'magik':
        case 'rotate':
        case 'rip':
        case 'jail':
        case 'trash':
        case 'pixelate':
        case 'sepia':
        case 'wanted':
        case 'wasted':
          try {

            if ((isMedia && !info.message.videoMessage || isQuotedImage)) {
              post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
              imagem = await downloadContentFromMessage(post, 'image')
              base64 = Buffer.from([])
              for await (const send of imagem) { base64 = Buffer.concat([base64, send]) }
              reply(mess.wait())
              link = await upload(base64)
              await miwa.sendMessage(from, { image: { url: `https://miwa-apis.online/api/canvas/${command}?link=${link}&apikey=${API_KEY_MIWA}` } }, { quoted: info }).catch(e => {
                return reply("Erro..")
              })
            } else {
              reply('Selecione uma imagem para transformar. ')
            }
          } catch (e) {
            if (JSON.stringify(e).includes("ServerAPI-Sab_Premium")) {
              return console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              console.log(e)
              reply('ERROR!!')
            }
          }
          break

        case 'lgbt':
          try {
            if ((isMedia && !info.message.videoMessage || isQuotedImage)) {
              post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
              imagem = await downloadContentFromMessage(post, 'image')
              base64 = Buffer.from([])
              for await (const send of imagem) { base64 = Buffer.concat([base64, send]) }
              reply(mess.wait())
              link = await upload(base64)
              await miwa.sendMessage(from, { image: { url: `https://sec.sabapis.tech/api/canvas/gay?img=${link}&apikey=ServerAPI-Sab_Premium` } }, { quoted: info }).catch(e => {
                return reply("Erro..")
              })

            } else {
              reply('Selecione uma imagem para transformar. ')
            }
          } catch (e) {
            if (JSON.stringify(e).includes("ServerAPI-Sab_Premium")) {
              return console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              console.log(e)
              reply('ERROR!!')
            }
          }
          break

        //========(SORTEIO-VOTAR-CASES)=========\\

        case 'substituir':
          if (!SoDono && !isnit) return reply("Só dono..")
          if (isMedia && !info.message.videoMessage || isQuotedDocument) {
            media = isQuotedDocument ? info.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : info.message.documentMessage
            rane = getRandom('.' + await getExtension(media.mimetype))
            doc = await getFileBuffer(media, 'document')
            fs.writeFileSync(q, doc)
            await miwa.sendMessage(from, { text: 'O arquivo foi substituído para outro local com sucesso.' }, { quoted: info })
          } else {
            reply('Marque o documento ou arquivo..')
          }
          break

        case 'index-bot':
          if (!SoDono) return reply(mess.onlyOwner())
          if (isMedia && !info.message.videoMessage || isQuotedDocument) {
            media = isQuotedDocument ? info.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : info.message.documentMessage
            rane = getRandom('.' + await getExtension(media.mimetype))
            doc = await getFileBuffer(media, 'document')
            fs.writeFileSync('./index.js', doc)
            await miwa.sendMessage(from, { text: "O arquivo './index.js' foi atualizado com sucesso." }, { quoted: info })
          } else {
            reply('Marque o documento ou o arquivo que deseja enviar pra determinar pasta ou substituir..')
          }
          break

        case 'getcase':
        case 'puxarcase':
          try {
            if (!SoDono) return reply(mess.onlyOwner())
            reply('- Calma ae amigo(a), já estou enviando o comando / case para você..')
            const getCase = (cases) => {
              return 'case ' + `'${cases}'` + fs.readFileSync("./index.js").toString().split('case \'' + cases + '\'')[1].split("break")[0] + "break"
            }
            await sleep(500)
            msgSemQuoted(`${getCase(q)}`)
          } catch (e) {
            console.log(e)
            reply('❌️ Comando não encontrado! ❌️')
          }
          break

        case 'bann':
          if (!isPremium && !SoDono) return reply("Só usuário premium pode utilizar este comando..")
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
          if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Este usuário já foi removido ou saiu do grupo.")
          if (premium.includes(menc_os2)) return mentions(`@${menc_os2.split("@")[0]} a(o) @${sender.split("@")[0]} está querendo banir você, visualiza esse problema ae 😶`, [menc_os2], true)
          if (groupAdmins.includes(menc_os2)) return mentions(`@${menc_os2.split("@")[0]} a(o) @${sender.split("@")[0]} está querendo banir você, visualiza esse problema ae 😶`, [menc_os2], true)
          if (botNumber.includes(menc_os2)) return reply('Não sou besta de remover eu mesmo né 🙁, mas estou decepcionado com você')
          if (numerodono.includes(menc_os2)) return reply('Não posso remover meu dono 🤧')
          await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} Foi [ REMOVIDO(A) COM SUCESSO ] - (Por motivos ainda não esclarecidos) -`, mentions: [menc_os2] })
          miwa.groupParticipantsUpdate(from, [menc_os2], "remove")
          break

        case 'band':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          try {
            if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
            if (IS_DELETE) {
              setTimeout(() => {
                miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
              }, 500)
            }
            if (!JSON.stringify().includes(menc_os2)) return reply("Este usuário já foi removido do grupo.")
            if (botNumber.includes(menc_os2)) return reply('Não sou besta de remover eu mesmo né 🙁, mas estou decepcionado com você')
            if (numerodono.includes(menc_os2)) return reply('Não posso remover meu dono 🤧')
            await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} Foi [ REMOVIDO(A) COM SUCESSO ] - (Por motivos justos.) -`, mentions: [menc_os2] })
            miwa.groupParticipantsUpdate(from, [menc_os2], "remove")
          } catch (e) {
            console.log(e)
          }
          break

        case 'ban': case 'banir': case 'kick': case 'avadakedavra':
          if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          try {
            if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
            if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Este usuário já foi removido do grupo ou saiu.")
            if (botNumber.includes(menc_os2)) return reply('Não sou besta de remover eu mesmo né 🙁, mas estou decepcionado com você')
            if (JSON.stringify(numerodono).indexOf(menc_os2) >= 0) return reply('Não posso remover meu dono 🤧')
            await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} Foi [ REMOVIDO(A) COM SUCESSO ] - (Por motivos justos.) -`, mentions: [menc_os2] })
            miwa.groupParticipantsUpdate(from, [menc_os2], "remove")
          } catch (e) {
            console.log(e)
          }
          break

        case 'add':
        case 'unkick':
        case 'reviver':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!q && info.message.extendedTextMessage === null) return reply('Marque a mensagem ou coloque o número de quem você quer adicionar no grupo.')
          try {
            useradd = `${args.join(" ").replace(/\D/g, '')}` ? `${args.join(" ").replace(/\D/g, '')}` : info.message.extendedTextMessage.contextInfo.participant
            let id = `${useradd.replace(/\D/g, '')}`
            if (!id) return reply(`Número inválido.`)
            let [result] = await miwa.onWhatsApp(id)
            if (!result) return reply(`Esse número não está registrado no WhatsApp.`)
            let response = await miwa.groupParticipantsUpdate(from, [result.jid], "add")
            if (response[0].status == "409") {
              await miwa.sendMessage(from, { text: `Ele já está no grupo, como eu vou adicionar?`, mentions: [result.jid, sender] })
            } else if (response[0].status == "403") {
              await miwa.sendMessage(from, { text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele privou a conta`, mentions: [result.jid, sender] })
            } else if (response[0].status == "408") {
              await miwa.sendMessage(from, { text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele saiu recentemente do grupo.`, mentions: [result.jid, sender] })
            } else if (response[0].status == "401") {
              await miwa.sendMessage(from, { text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele bloqueou o bot`, mentions: [result.jid, sender] })
            } else if (response[0].status == "200") {
              await miwa.sendMessage(from, { text: `Prontinho fiz o que você pediu.`, mentions: [result.jid, sender] })
            } else {
              reply("Vish acho que algo deu errado")
            }
          } catch {
          }
          break

        case 'promover':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
          if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Este usuário foi removido do grupo ou saiu, não será possível promover..")
          await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} Foi promovido(a) para adm com sucesso.`, mentions: [menc_os2] })
          miwa.groupParticipantsUpdate(from, [menc_os2], "promote")
          break

        case 'rebaixar':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          if (!isBotGroupAdmins) return reply(`*Como ousa usar um comando que não lhe pertence o dom de usar! *Somente adminstradores do grupo tem acesso...*`)
          if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
          if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Este usuário foi removido do grupo ou saiu, não será possível rebaixar..")
          await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} Foi Rebaixado para [ MEMBRO COMUM ] com sucesso.`, mentions: [menc_os2] })
          miwa.groupParticipantsUpdate(from, [menc_os2], "demote")
          break

        case 'sorteio':
          if (!isGroup) return reply('_' + mess.onlyGroup() + '_');
          if (!isGroupAdmins) return reply('_' + mess.onlyAdmins() + '_');
          if (!q) return reply(`Coloque algo após o comando, por exemplo: *${prefix}sorteio* _de 100 R$_`);
          try {
            await mention(`🤖🎉 Parabéns *@${groupMembers[Math.floor(Math.random() * groupMetadata.participants.length)].id.split('@')[0]}*, você acaba de ser contemplado(a) como o(a) ganhador(a) do sorteio...\n–\n• Para mais informações entre em contato com o(a) adm responsável pelo sorteio: _“${q}”_.`);
          } catch (error) {
            reply('Deu erro, tente novamente :/')
          }
          break

        case 'sorteionumero':
        case 'sorteionumeros':
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          try {
            if (!isGroup) return reply(mess.onlyGroup())
            if (!q) return reply(`Coloque algo, após o comando sorteio, por exemplo, ${prefix}sorteionumero de 100 R$`)
            var numerossrt = sortear[Math.floor(Math.random() * sortear.length)]
            d = []
            teks = `🎉Parabéns ao número do sortudo, por ganhar o sorteio ${q}:\n\n`
            for (i = 0; i < 1; i++) {
              teks += `🔥፝⃟  ➣ ${numerossrt}\n`
              d.push(numerossrt)
            }
            mentions(teks, d, true)
          } catch (e) {
            console.log(e)
            reply('Deu erro, tente novamente :/')
          }
          break

        //==========(TTPS/ATTP)============\\

        case 'ttp':
          try {
            if (q < 1) return reply(`_Coloque o texto_\n*Exemplo:* ${prefix + command} ᴍᴀɪ`)
            reply(mess.wait())
            string = args.join(' ') || 'Texto indefinido'
            post = `https://miwa-apis.online/api/ttp?texto=${string}&apikey=` + API_KEY_MIWA
            sendStickerFromUrl(from, post, { quoted: selo })
          } catch (e) {
            if (String(e).includes("invalid json response body at")) {
              console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
            } else {
              reply('ERROR!!')
            }
          }
          break

       

        //======================================\\


        //===(ZOUEIRAS/BRINCADEIRAS/HUMOR)===\\

        case 'gerarnick': case 'fazernick':
try {
if(ANT_LTR_MD_EMJ(q)) return reply("Não pode letras modificadas nem emoji..");
if(!q) return reply(`escreva um nome para eu enviar ele com letras modificadas, Exemplo: ${prefix+command} Yuxinze`);
ABC = await fetchJson(`http://br2.bronxyshost.com:4130/api/fazernick?nome=${q}&apikey=Yukizinho`)
AB = `Lista com base no Nick informado, para encontrar melhor fonte para utilizar:\n\n`;
for ( i of ABC) {
AB += `${i}\n\n`;
}
reply(AB);
} catch (e) {
return reply("Erro..");
}
break
        case 'copynick':
          if (!q) return
          sendButton(from, { text: ` *Nick gerado com sucesso:* ${q}`, footer: NomeDoBot }, miwa, sender, [{ type: `copy_text`, text: `CLIQUE AQUI PARA COPIAR`, url: q }], info)
          break

        case 'gerarnick2': {
          const args = q.split(' ');
          const nome = args.slice(0).join(' ');
          if (!nome) return reply('Digite um nome para gerar o nickname.');

          const estilos = {
            'a': ['𝒶', '𝒜', '𝓐', '𝔞', '𝓪', '𝒶', '𝕒', '𝒶', '𝒶', '𝓐'],
            'b': ['𝒷', '𝐵', '𝓑', '𝔟', '𝓫', '𝒷', '𝕓', '𝓫', '𝒷', '𝓑'],
            'c': ['𝒸', '𝒞', '𝓒', '𝔠', '𝓬', '𝒸', '𝕔', '𝓬', '𝒸', '𝓒'],
            'd': ['𝒹', '𝐷', '𝓓', '𝔡', '𝓭', '𝒹', '𝕕', '𝓭', '𝒹', '𝓓'],
            'e': ['𝒺', '𝐸', '𝓔', '𝔢', '𝓮', '𝒺', '𝕖', '𝓮', '𝒺', '𝓔'],
            'f': ['𝒻', '𝐹', '𝓕', '𝔣', '𝓯', '𝒻', '𝕗', '𝓯', '𝒻', '𝓕'],
            'g': ['𝒼', '𝒢', '𝓖', '𝔤', '𝓰', '𝒼', '𝕘', '𝓰', '𝒼', '𝓖'],
            'h': ['𝒽', '𝐻', '𝓗', '𝔥', '𝓱', '𝒽', '𝕙', '𝓱', '𝒽', '𝓗'],
            'i': ['𝒾', '𝐼', '𝓘', '𝔦', '𝓲', '𝒾', '𝕚', '𝓲', '𝒾', '𝓘'],
            'j': ['𝒿', '𝒥', '𝓙', '𝔧', '𝓳', '𝒿', '𝕛', '𝓳', '𝒿', '𝓙'],
            'k': ['𝒦', '𝐾', '𝓚', '𝔨', '𝓴', '𝒦', '𝕜', '𝓴', '𝒦', '𝓚'],
            'l': ['𝓁', '𝐿', '𝓛', '𝔩', '𝓵', '𝓁', '𝕝', '𝓵', '𝓁', '𝓛'],
            'm': ['𝓂', '𝑀', '𝓜', '𝔪', '𝓶', '𝓂', '𝕞', '𝓶', '𝓂', '𝓜'],
            'n': ['𝓃', '𝒩', '𝓝', '𝔫', '𝓷', '𝓃', '𝕟', '𝓷', '𝓃', '𝓝'],
            'o': ['𝑜', '𝒪', '𝓞', '𝔬', '𝓸', '𝑜', '𝕠', '𝓸', '𝑜', '𝓞'],
            'p': ['𝓅', '𝒫', '𝓟', '𝔭', '𝓹', '𝓅', '𝕡', '𝓹', '𝓅', '𝓟'],
            'q': ['𝓆', '𝒬', '𝓠', '𝔮', '𝓺', '𝓆', '𝕢', '𝓺', '𝓆', '𝓠'],
            'r': ['𝓇', '𝑅', '𝓡', '𝔯', '𝓻', '𝓇', '𝕣', '𝓻', '𝓇', '𝓡'],
            's': ['𝓈', '𝒮', '𝓢', '𝔰', '𝓼', '𝓈', '𝕤', '𝓼', '𝓈', '𝓢'],
            't': ['𝓉', '𝒯', '𝓣', '𝔱', '𝓽', '𝓉', '𝕥', '𝓽', '𝓉', '𝓣'],
            'u': ['𝓊', '𝒰', '𝓤', '𝔲', '𝓾', '𝓊', '𝕦', '𝓾', '𝓊', '𝓤'],
            'v': ['𝓋', '𝒱', '𝓥', '𝔳', '𝓿', '𝓋', '𝕧', '𝓿', '𝓋', '𝓥'],
            'w': ['𝓌', '𝒲', '𝓦', '𝔴', '𝓹', '𝓌', '𝕨', '𝓹', '𝓌', '𝓦'],
            'x': ['𝓍', '𝒳', '𝓧', '𝔵', '𝓧', '𝓍', '𝕩', '𝓧', '𝓍', '𝓧'],
            'y': ['𝓎', '𝒴', '𝓨', '𝔶', '𝓨', '𝓎', '𝕪', '𝓨', '𝓎', '𝓨'],
            'z': ['𝓏', '𝒵', '𝓩', '𝔫', '𝓩', '𝓏', '𝕫', '𝓩', '𝓏', '𝓩'],
            'A': ['𝒜', '𝐵', '𝒞', '𝒟', '𝐸', '𝐹', '𝒢', '𝐻', '𝐼', '𝒥'],
            'B': ['𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'C': ['𝒞', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'D': ['𝐷', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'E': ['𝐸', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'F': ['𝐹', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'G': ['𝒢', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'H': ['𝐻', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'I': ['𝐼', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'J': ['𝒥', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'K': ['𝒦', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'L': ['𝐿', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'M': ['𝒩', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'N': ['𝒩', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'O': ['𝒪', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'P': ['𝒫', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'Q': ['𝒬', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'R': ['𝑅', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'S': ['𝒮', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'T': ['𝒯', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'U': ['𝒰', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'V': ['𝒱', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'W': ['𝒲', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'X': ['𝒳', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'Y': ['𝒴', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
            'Z': ['𝒵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵', '𝐵'],
          };

          const nickname = nome.split('').map(char => {
            const styles = estilos[char] || [char];
            return styles[Math.floor(Math.random() * styles.length)];
          }).join('');

          reply(`Aqui está o seu nickname estilizado: ${nickname}`);
          break;
        }
        case 'chance':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          var avb = body.slice(7)
          if (args.length < 1) return await miwa.sendMessage(from, { text: `Você precisa digitar da forma correta\nExemplo: ${prefix}chance do luuck ser gay` }, { quoted: info })
          random = `${Math.floor(Math.random() * 100)}`
          hasil = `A chance ${body.slice(8)}\n\né de... ${random}%`
          await miwa.sendMessage(from, { text: hasil, mentions: [sender] }, { quoted: info })
          break

        case 'nazista':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a sua ficha de nazista : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imgnazista }, caption: `O quanto você é nazista? \n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱  nazista 卐`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'gay':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a sua ficha de gay : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            feio = random
            boiola = random
            if (boiola < 20) { var bo = 'hmm... você é hetero😔' } else if (boiola == 21) { var bo = '+/- boiola' } else if (boiola == 23) { var bo = '+/- boiola' } else if (boiola == 24) { var bo = '+/- boiola' } else if (boiola == 25) { var bo = '+/- boiola' } else if (boiola == 26) { var bo = '+/- boiola' } else if (boiola == 27) { var bo = '+/- boiola' } else if (boiola == 2) { var bo = '+/- boiola' } else if (boiola == 29) { var bo = '+/- boiola' } else if (boiola == 30) { var bo = '+/- boiola' } else if (boiola == 31) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 32) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 33) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 34) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 35) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 36) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 37) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 3) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 39) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 40) { var bo = 'tenho minha desconfiança...😑' } else if (boiola == 41) { var bo = 'você é né?😏' } else if (boiola == 42) { var bo = 'você é né?😏' } else if (boiola == 43) { var bo = 'você é né?😏' } else if (boiola == 44) { var bo = 'você é né?😏' } else if (boiola == 45) { var bo = 'você é né?😏' } else if (boiola == 46) { var bo = 'você é né?😏' } else if (boiola == 47) { var bo = 'você é né?😏' } else if (boiola == 4) { var bo = 'você é né?😏' } else if (boiola == 49) { var bo = 'você é né?😏' } else if (boiola == 50) { var bo = 'você é ou não?🧐' } else if (boiola > 51) {
              var bo = 'você é gay🙈'
            }
            await miwa.sendMessage(from, { image: { url: imggay }, caption: `  O quanto você é gay? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ gay 🏳️‍🌈\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info })
          }, 7000)
          break

        case 'feio':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a sua ficha de feio : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            feio = random
            if (feio < 20) { var bo = 'É não é feio' } else if (feio == 21) { var bo = '+/- feio' } else if (feio == 23) { var bo = '+/- feio' } else if (feio == 24) { var bo = '+/- feio' } else if (feio == 25) { var bo = '+/- feio' } else if (feio == 26) { var bo = '+/- feio' } else if (feio == 27) { var bo = '+/- feio' } else if (feio == 2) { var bo = '+/- feio' } else if (feio == 29) { var bo = '+/- feio' } else if (feio == 30) { var bo = '+/- feio' } else if (feio == 31) { var bo = 'Ainda tá na média' } else if (feio == 32) { var bo = 'Da pra pegar umas(ns) novinha(o) ainda' } else if (feio == 33) { var bo = 'Da pra pegar umas(ns) novinha(o) ainda' } else if (feio == 34) { var bo = 'É fein, mas tem baum coração' } else if (feio == 35) { var bo = 'Tá na média, mas não deixa de ser feii' } else if (feio == 36) { var bo = 'Bonitin mas é feio com orgulho' } else if (feio == 37) { var bo = 'Feio e preguiçoso(a), vai se arrumar praga feia' } else if (feio == 3) { var bo = 'tenho ' } else if (feio == 39) { var bo = 'Feio, mas um banho E se arrumar, deve resolver' } else if (feio == 40) { var bo = 'FeiN,  mas não existe gente feia, existe gente que não conhece os produtos jequity' } else if (feio == 41) { var bo = 'você é Feio, mas é legal, continue assim' } else if (feio == 42) { var bo = 'Nada que uma maquiagem e se arrumar, que não resolva 🥴' } else if (feio == 43) { var bo = 'Feio que dói de ver, compra uma máscara que melhora' } else if (feio == 44) { var bo = 'Feio mas nada que um saco na cabeça não resolva né!?' } else if (feio == 45) { var bo = 'você é feio, mas tem bom gosto' } else if (feio == 46) { var bo = 'Feio mas tem muitos amigos' } else if (feio == 47) { var bo = 'Feio mas tem lábia pra pegar várias novinha' } else if (feio == 4) { var bo = 'Feio e ainda não sabe se vestir, vixi' } else if (feio == 49) { var bo = 'Feiooo' } else if (feio == 50) { var bo = 'você é Feio, mas não se encherga 🧐' } else if (feio > 51) { var bo = 'você é Feio demais 🙈' }


            await miwa.sendMessage(from, { image: { url: imgfeio }, caption: `  O quanto você é feio? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ feio 🙉\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info })
          }, 7000)
          break

        case 'corno':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: ` ❰ Pesquisando a ficha de corno : @${sender_ou_n.split("@")[0]}, aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imgcorno }, caption: ` O quanto você é corno? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱  corno 🐃`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'vesgo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a ficha de vesgo : @${sender_ou_n.split("@")[0]}, aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imgvesgo }, caption: `O quanto você é vesgo? \n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱  Vesgo 🙄😆`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'bebado':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a ficha de bebado : @${sender_ou_n.split("@")[0]} , aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imgbebado }, caption: `O quanto você é bebado? \n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ Bêbado 🤢🥵🥴`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'gado':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a ficha de gado : @${sender_ou_n.split("@")[0]}, aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imggado }, caption: `O quanto você é gado? \n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱  gado 🐂`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'gostoso':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: ` ❰ Pesquisando a sua ficha de gostoso : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imggostoso }, caption: `O quanto você é gostoso? 😏\n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ gostoso 😝`, gifPlayback: true, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'gostosa':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          await miwa.sendMessage(from, { text: `❰ Pesquisando a sua ficha de gostosa : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] })
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 110)}`
            await miwa.sendMessage(from, { image: { url: imggostosa }, caption: `O quanto você é gostosa? 😏\n\n「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ gostosa 😳`, mentions: [sender_ou_n] }, { quoted: info })
          }, 7000)
          break

        case 'matar':
        case 'mata':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          if (!menc_os2 || menc_jid2[1]) return reply('marque o alvo que você quer matar, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: matarcmd }, gifPlayback: true, caption: `Você Acabou de matar o(a) @${menc_os2.split('@')[0]} 😈👹`, mentions: [menc_os2] }, { quoted: info })
          break


        case 'beijo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          if (!menc_os2 || menc_jid2[1]) return reply('marque a pessoa que você quer beijar, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: beijocmd }, gifPlayback: true, caption: `Você deu um beijo gostoso na(o) @${menc_os2.split('@')[0]} 😁👉👈❤`, mentions: [menc_os2] }, { quoted: info })
          break

        case 'biografia':
          try {
            var status = await miwa.fetchStatus(marc_tds)
          } catch {
            var status = "Privado ou inexistente. "
          }
          reply(status)
          break

        case 'tapa':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!menc_os2 || menc_jid2[1]) return reply('marque o alvo que você quer da um tapa, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: tapacmd }, gifPlayback: true, caption: `Você Acabou de da um tapa na raba da😏 @${menc_os2.split('@')[0]} 🔥`, mentions: [menc_os2] }, { quoted: info })
          break

        case 'chute':
        case 'chutar':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          if (!menc_os2 || menc_jid2[1]) return reply('marque o alvo que você quer da um chute, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: chutecmd }, gifPlayback: true, caption: `Você Acabou de da um chute em @${menc_os2.split('@')[0]} 🤡`, mentions: [menc_os2] }, { quoted: info })
          break

        case 'dogolpe':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          if (!menc_os2 || menc_jid2[1]) return reply('Marque a mensagem com o comando ou marque o @ do usuário..')
          random = `${Math.floor(Math.random() * 100)}`
          await miwa.sendMessage(from, { text: `*GOLPISTA ENCONTRADO👉🏻*\n\n*GOLPISTA* : *@${menc_os2.split("@")[0]}*\n*PORCENTAGEM DO GOLPE* : ${random}%😂\n\nEle(a) gosta de ferir sentimentos 😢`, mentions: [menc_os2] })
          break

        case 'shipo':
          if (!menc_jid2) return reply('Marque uma pessoa do grupo para encontrar o par dela')
          mention(`*Hmmm.... Eu Shipo eles 2💘💘*\n\n1 = @${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split('@')[0]}\n && 2 = ${menc_jid2.split("@")[0]} com uma porcentagem de: ${Math.floor(Math.random() * 100) + "%"}`)
          break

        case 'casal':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          mention(`*Hmmm.... Eu Shipo eles 2💘💘*\n\n1= @${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split('@')[0]}\ne esse\n2= @${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split('@')[0]}\ncom uma porcentagem de: ${Math.floor(Math.random() * 100) + "%"}`)
          break

        case 'ranklevel':
        case 'rankpatente':
          var i3 = countMessage.map(i => i.groupId).indexOf(from)
          var blue = countMessage[i3].numbers.map(i => i)
          blue.sort((a, b) => ((a.figus == undefined ? a.figus = 0 : a.figus + a.messages + a.cmd_messages + a.figus) < (b.figus == undefined ? b.figus = 0 : b.figus + b.cmd_messages + b.messages + b.figus)) ? 0 : -1)
          menc = []
          blad = `
*🏆 Rank de level e patentes no grupo:* ${groupName}\n`
          for (i = 0; i < (blue.length < 5 ? blue.length : 5); i++) {
            var i5 = patentes.map(i => i.grupoID).indexOf(from)
            var i6 = patentes[i5].usus.map(i => i.id).indexOf(blue[i].id)
            if (i != null) blad += `
*🏅 ${i + 1}º Lugar:* @${blue[i].id.split('@')[0]}
▢ Level do usuário atualmente: ${patentes[i5].usus[i6].level_usu}\n▢ Patente atual do usuário: ${patentes[i5].usus[i6].patente_usu}\n`
            menc.push(blue[i].id)
          }
          mentions(blad, menc, true)
          break

        case 'rankativos':
        case 'rankativo':
          if (!isGroup) return reply(mess.onlyGroup())
          var i3 = countMessage.map(i => i.groupId).indexOf(from)
          var blue = countMessage[i3].numbers.map(i => i)
          blue.sort((a, b) => ((a.figus == undefined ? a.figus = 0 : a.figus + a.messages + a.cmd_messages) < (b.figus == undefined ? b.figus = 0 : b.figus + b.cmd_messages + b.messages)) ? 0 : -1)
          menc = []
          blad = `
*🏆 Rank dos mais ativos no grupo:* ${groupName}\n`
          for (i = 0; i < (blue.length < 5 ? blue.length : 5); i++) {
            var i5 = patentes.map(i => i.grupoID).indexOf(from)
            var i6 = patentes[i5].usus.map(i => i.id).indexOf(blue[i].id)
            if (i != null) blad += `
*🏅 ${i + 1}º Lugar:* @${blue[i].id.split('@')[0]}
▢ Mensagens encaminhadas: ${blue[i].messages}
▢ Comandos executados: ${blue[i].cmd_messages}
▢ Patente do Usuário: ${patentes[i5].usus[i6].patente_usu}
▢ Usuário conectado em: ${blue[i].aparelho}
▢ Figurinhas enviadas: ${blue[i].figus}\n`
            menc.push(blue[i].id)
          }
          mentions(blad, menc, true)
          break

        case 'rankinativo':
        case 'rankinativos':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply(mess.onlyAdmins())
          bule = [];
          bule2 = []
          mentioned_jid = []
          for (cag of countMessage[ind].numbers) {
            bule2.push(cag.id)
            if (cag.messages <= 1) { bule.push(cag) }
          }
          bule.sort((a, b) => ((a.messages + a.cmd_messages) < (b.cmd_messages + b.messages)) ? 0 : -1)
          boardi = `🗑 *Rank dos mais inativos do grupo:* ${groupName}\n\n`
          if (bule.length == 0) boardi += '❌ Nenhum usuário inativo foi encontrado neste grupo.️'
          for (i = 0; i < (bule.length < 5 ? bule.length : 5); i++) {
            if (i != null) boardi += `*🏅 ${i + 1}º Lugar:* @${bule[i].id.split('@')[0]}\n▢ Mensagens enviadas: ${bule[i].messages}\n▢ Comandos executados: ${bule[i].cmd_messages}\n▢ Usuário conectado em: ${bule[i].aparelho}\n\n`
            mentioned_jid.push(bule[i].id)
          }
          mentions(boardi, mentioned_jid, true)
          break

        case 'checkativo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (groupIdscount.indexOf(from) < 0) return reply('O bot não tem ainda dados sobre o grupo')
          var ind = groupIdscount.indexOf(from)
          if (!menc_os2 || menc_jid2[1]) return reply('Marque o @ de quem deseja puxar a atividade / Só pode um por vez..')
          if (numbersIds.indexOf(menc_os2) >= 0) {
            var indnum = numbersIds.indexOf(menc_os2)
            var RSM_CN = countMessage[ind].numbers[indnum]
            mentions(`Consulta individual da atividade do usuário @${menc_os2.split('@')[0]} no grupo: ${groupName}\n\n▢ Mensagens encaminhadas: ${RSM_CN.messages}\n▢ Comandos executados: ${RSM_CN.cmd_messages}\n▢ Usuário conectado em: ${RSM_CN.aparelho}\n▢ Figurinhas encaminhadas: ${RSM_CN.figus}`, [menc_os2], true)
          } else {
            mentions(`Consulta individual da atividade do usuário @${menc_os2.split('@')[0]} no grupo: ${groupName}\n\n▢ Mensagens enviadas no grupo: 0\n▢ Comandos executados no grupo: 0\n▢ Usuário conectado em: Sem info.\n▢ Figurinhas enviadas no grupo: 0`, [menc_os2], true)
          }
          break

        case 'rankgay': case 'rankgays':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `*🤖RANK DOS 5 MAIS GAYS DO GRUPO [ ${groupName} ]🏳‍🌈*\n\n`
          for (var i = 0; i < 5; i++) {
            ABC += `${Math.floor(Math.random() * 100)}% @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnkgay)
          break;

        case 'rankgado': case 'rankgados':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `RANK DOS 5 MAIS GADO DO GRUPO 🐂🐃\n\n`
          for (var i = 0; i < 5; i++) {
            ABC += `${Math.floor(Math.random() * 100)}% @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnkgado);
          break;

        case 'rankcorno': case 'rankcornos':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `RANK DOS 5 MAIS CORNO DO GRUPO 🐂\n\n`
          for (var i = 0; i < 5; i++) {
            ABC += `${Math.floor(Math.random() * 100)}% @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnkcorno);
          break;

        case 'rankbi':
          await miwa.sendMessage(from, { react: { text: `🏳‍🌈`, key: info.key } })
          if (!isGroup) return reply('Só pode ser utilizado este comando, em grupo.')
          try {
            if (!isGroup) return reply(enviar.msg.grupo)
            let d = []
            let teks = `ESSES SÃO OS BISSEXUAIS DO GRUPO!!🏳‍🌈
${groupName}🫣\n`
            for (i = 0; i < 10; i++) {
              let r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
              teks += `🏳‍🌈⋆͜͡҈➳ @${groupMembers[r].id.split('@')[0]}\n`
              d.push(groupMembers[r].id)
            }
            mentions(teks, d, true)
          } catch (e) {
            console.log(e)
            reply('Deu erro, tente novamente :/')
          }
          break
        //BY: ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐

        case 'rankbv':
          await miwa.sendMessage(from, { react: { text: `👄`, key: info.key } })
          if (!isGroup) return reply('Só pode ser utilizado este comando, em grupo.')
          try {
            if (!isGroup) return reply(enviar.msg.grupo)
            let d = []
            let teks = `ESSES SÃO OS QUE NÃO BEIJAM NINGUEM!!👄
${groupName}🫣\n`
            for (i = 0; i < 10; i++) {
              let r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
              teks += `👄⋆͜͡҈➳ @${groupMembers[r].id.split('@')[0]}\n`
              d.push(groupMembers[r].id)
            }
            mentions(teks, d, true)
          } catch (e) {
            console.log(e)
            reply('Deu erro, tente novamente :/')
          }
          break
        //BY: ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐

        case 'rankbunduda':
          await miwa.sendMessage(from, { react: { text: `🤡`, key: info.key } })
          if (!isGroup) return reply('Só pode ser utilizado este comando, em grupo.')
          try {
            if (!isGroup) return reply(enviar.msg.grupo)
            let d = []
            let teks = `🫣ESSES(AS) SÃO OS MAIS BUNDUDAS(AS) DO GRUPO ${groupName}🫣\n`
            for (i = 0; i < 10; i++) {
              let r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
              teks += `🫣⋆͜͡҈➳ @${groupMembers[r].id.split('@')[0]}\n`
              d.push(groupMembers[r].id)
            }
            mentions(teks, d, true)
          } catch (e) {
            console.log(e)
            reply('Deu erro, tente novamente :/')
          }
          break
        //BY: ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐

        case 'anjo':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando seu nível angelical : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            anjo = random;
            if (anjo < 20) { var bo = 'Você é bem terreno... 😇'; }
            else if (anjo < 40) { var bo = 'Você tem traços angelicais 😇'; }
            else if (anjo < 60) { var bo = 'Você é um anjo 😇'; }
            else if (anjo < 80) { var bo = 'Você é um anjo celestial! 😇'; }
            else { var bo = 'Você é um arcanjo divino! 😇✨'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/ddba48c868d7db5fdbbcd.jpg' }, caption: `O quanto você é anjo? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ anjo 😇✨\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        case 'magico':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando seu nível de magia : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            magico = random;
            if (magico < 20) { var bo = 'Você é bem mundano... 🧙'; }
            else if (magico < 40) { var bo = 'Você tem traços mágicos 🪄'; }
            else if (magico < 60) { var bo = 'Você é um > 🧙'; }
            else if (magico < 80) { var bo = 'Você é um mago poderoso! 🧙'; }
            else { var bo = 'Você é o mestre dos magos! 🧙✨'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/bc46ce223a0cf3534d01f.jpg' }, caption: `O quanto você é mágico? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ mágico 🧙✨\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        case 'espiao':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando suas habilidades de espionagem : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            espiao = random;
            if (espiao < 20) { var bo = 'Você é bem perceptível... 👀'; }
            else if (espiao < 40) { var bo = 'Você tem habilidades de espião 🕵️‍♂️'; }
            else if (espiao < 60) { var bo = 'Você é um espião 🕵️‍♂️'; }
            else if (espiao < 80) { var bo = 'Você é um espião profissional! 🕵️‍♂️'; }
            else { var bo = 'Você é o melhor espião do mundo! 🕵️‍♂️🌍'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/807e6bdbdf0fae348fa83.jpg' }, caption: `O quanto você é espião? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ espião 🕵️‍♂️🌍\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        //BY: ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐

        case 'mago':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando suas habilidades mágicas : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            mago = random;
            if (mago < 20) { var bo = 'Você é um aprendiz de magia... 🧙‍♂️'; }
            else if (mago < 40) { var bo = 'Você tem alguma habilidade mágica 🧙‍♂️'; }
            else if (mago < 60) { var bo = 'Você é um mago em treinamento! 🧙‍♂️'; }
            else if (mago < 80) { var bo = 'Você é um mago habilidoso! 🧙‍♂️'; }
            else { var bo = 'Você é um mago supremo! 🧙‍♂️✨'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/0a4976a9e00133bd45cf8.jpg' }, caption: `O quanto você é um mago? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ mago 🧙‍♂️✨\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        case 'samurai':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando suas habilidades de samurai : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            samurai = random;
            if (samurai < 20) { var bo = 'Você está mais para guerreiro comum... 🗡️'; }
            else if (samurai < 40) { var bo = 'Você tem espírito de samurai! 🗡️'; }
            else if (samurai < 60) { var bo = 'Você é um samurai em treinamento! 🗡️'; }
            else if (samurai < 80) { var bo = 'Você é um samurai habilidoso! 🗡️'; }
            else { var bo = 'Você é um mestre samurai! 🗡️👹'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/7a02ebd19c954ffa72c32.jpg' }, caption: `O quanto você é samurai? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ samurai 🗡️👹\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        case 'maquina':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(`Este tipo de comando só pode ser utilizado com o modobrincadeira ativo, fale com um adm ou se você for, apenas digite ${prefix}modobrincadeira 1`);
          await miwa.sendMessage(from, { text: `❰ Avaliando suas habilidades de viagem no tempo : @${sender_ou_n.split("@")[0]} aguarde... ❱`, mentions: [sender_ou_n] });
          setTimeout(async () => {
            random = `${Math.floor(Math.random() * 100)}`;
            maquina = random;
            if (maquina < 20) { var bo = 'Você ainda não tem controle sobre o tempo... ⏳'; }
            else if (maquina < 40) { var bo = 'Você tem algumas habilidades temporais ⏳'; }
            else if (maquina < 60) { var bo = 'Você é um viajante do tempo em treinamento! ⏳'; }
            else if (maquina < 80) { var bo = 'Você é um mestre da viagem no tempo! ⏳'; }
            else { var bo = 'Você domina o tempo como ninguém! ⏳✨'; }
            await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/d91e84ca89235dd780db0.jpg' }, caption: `O quanto você domina a viagem no tempo? \n\n 「 @${sender_ou_n.split("@")[0]} 」Você é: ❰ ${random}% ❱ mestre da viagem no tempo ⏳✨\n\n${bo}`, mentions: [sender_ou_n], thumbnail: null }, { quoted: info });
          }, 7000);
          break

        case 'socar':
          if (!isGroup) return reply('Só pode ser utilizado este comando, em grupo.')
          if (!menc_os2 || menc_jid2[1]) return reply('marque o alvo que você quer da um soco, a mensagem ou o @')
          txtkk = [`Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um golpe fatal!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te nocautear!`,
          `Olá @${menc_os2.split('@')[0]}, você foi atingido pelo ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um soco!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te acertar!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um golpe forte!`,
          `Olá @${menc_os2.split('@')[0]}, você foi socado pelo ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra épica!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te derrubar!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou em cheio!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra incrível!`,
          `Oi @${menc_os2.split('@')[0]}, você levou um golpe de ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um soco devastador!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te derrubar com um soco!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra monumental!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te acertar um soco!`,
          `Atenção @${menc_os2.split('@')[0]}, você levou uma surra do ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um golpe poderoso!`,
          `Olá @${menc_os2.split('@')[0]}, você foi atingido por um soco de ${sender.split('@')[0]}!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te esmurrando!`,
          `Ei @${menc_os2.split('@')[0]}, você está levando uma surra de ${sender.split('@')[0]}!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te golpeando!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra memorável!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te nocauteou com um soco!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te dando um golpe brutal!`,
          `Ei @${menc_os2.split('@')[0]}, você foi atingido fortemente por ${sender.split('@')[0]}!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou com tudo!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te esmagar com um soco!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um soco implacável!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te dando uma surra histórica!`,
          `Ei @${menc_os2.split('@')[0]}, você levou um soco fenomenal de ${sender.split('@')[0]}!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um golpe formidável!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou um soco arrasador!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te espancando!`,
          `Olá @${menc_os2.split('@')[0]}, você está sendo socado por ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um soco avassalador!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um golpe intenso!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou um soco potente!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te nocautear com um soco avassalador!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te esmagando com socos!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te dar uma surra fenomenal!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um soco brutal!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te esmagando com força!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um golpe formidável!`,
          `Olá @${menc_os2.split('@')[0]}, você levou uma surra de ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou um soco destruidor!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te derrubar com um golpe!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te espancando sem piedade!`,
          `Atenção @${menc_os2.split('@')[0]}, você foi atingido por um soco poderoso de ${sender.split('@')[0]}!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um golpe fulminante!`,
          `Ei @${menc_os2.split('@')[0]}, você levou um soco brutal de ${sender.split('@')[0]}!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou um golpe devastador!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te esmurrando sem dó!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um soco poderoso!`,
          `Olá @${menc_os2.split('@')[0]}, você foi atingido com força por ${sender.split('@')[0]}!`,
          `Ei @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu um soco esmagador!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te derrubou com um golpe destruidor!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te dar uma surra colossal!`,
          `Atenção @${menc_os2.split('@')[0]}, você levou um soco avassalador de ${sender.split('@')[0]}!`,
          `Olá @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te acertou um soco fenomenal!`,
          `Ei @${menc_os2.split('@')[0]}, você foi atingido por um soco destruidor de ${sender.split('@')[0]}!`,
          `Aviso @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} te deu uma surra fulminante!`,
          `Oi @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} acabou de te nocautear com um soco!`,
          `Atenção @${menc_os2.split('@')[0]}, ${sender.split('@')[0]} está te espancando violentamente!`]
          const susp = txtkk[Math.floor(Math.random() * txtkk.length)]
          lss = ["https://telegra.ph/file/f737009edab409fe7be43.mp4", "https://telegra.ph/file/608f10571c79cd270684b.mp4", "https://telegra.ph/file/b11cdf32f93712fcd4d78.mp4", "https://telegra.ph/file/72bb4bc30d2d75e2b0b77.mp4", "https://telegra.ph/file/a1f4856876d4cb47fc215.mp4", "https://telegra.ph/file/866708c964801c6af880a.mp4", "https://telegra.ph/file/c917c16f143f4716488ca.mp4", "https://telegra.ph/file/663990556cd3b872b670e.mp4", "https://telegra.ph/file/638e353bcbd343581aa5f.mp4", "https://telegra.ph/file/6770b65c4b7a43840735a.mp4", "https://telegra.ph/file/7172540125b1b5754f12f.mp4", "https://telegra.ph/file/13468fc5ca601483a1c38.mp4", "https://telegra.ph/file/3463d0e205b5d5dc7a075.mp4", "https://telegra.ph/file/4b135cfda8a32f3c6d83c.mp4", "https://telegra.ph/file/4b135cfda8a32f3c6d83c.mp4", "https://telegra.ph/file/6577e0445dd4b3ac15465.mp4", "https://telegra.ph/file/88891992448b401b6763a.mp4"]
          randomp = lss[Math.floor(Math.random() * lss.length)]
          jrq = await getBuffer(randomp)
          await miwa.sendMessage(from, { video: jrq, gifPlayback: true, caption: susp, mentions: [menc_os2] }, { quoted: info })
          break

        // COMANDOS DE BRINCADEIRA, CRIAR EMPRESA, FAMÍLIA, ETC

        case 'criarfamilia'://criador: Ryuufranky x

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)
          const nomeFamilia = args.join(" ");
          if (!nomeFamilia) return reply('Por favor, forneça um nome para a família.');
          const criarFamiliaMsg = criarFamilia(sender, nomeFamilia);
          reply(criarFamiliaMsg);
          break;
        case 'vertodasfamilia'://criador: Ryuufranky x

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)
          const verTodasFamiliasMsg = verTodasFamilias();
          reply(verTodasFamiliasMsg, null, {
            contextInfo: {
              mentionedJid: loadFamilias().familias.flatMap(f => f.membros)
            }
          });
          break;
        case 'adicionarfamilia'://criador: Ryuufranky x
        case 'addfamilia':

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)
          if (!menc_os2 || menc_jid2[1]) return reply('❕Marque a pessoa')
          if (!menc_os2) return reply('Por favor, mencione um membro para adicionar à família.');
          const adicionarFamiliaMsg = adicionarFamilia(sender, menc_os2);
          reply(adicionarFamiliaMsg);
          break;
        case 'sairfamilia'://criador: Ryuufranky x

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)
          const sairFamiliaMsg = sairFamilia(sender);
          reply(sairFamiliaMsg);
          break;
        case 'verfamilia'://criador: Ryuufranky x

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)
          const verFamiliaMsg = verFamilia(sender);
          reply(verFamiliaMsg, null, {
            contextInfo: {
              mentionedJid: loadFamilias().familias.find(f => f.membros.includes(sender)).membros
            }
          });
          break;

        case 'criarempresa':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const nomeEmpresa = args[0];
          const tipoEmpresa = args[1] || 'basica';
          if (!nomeEmpresa) return reply('Por favor, forneça um nome para a empresa.');
          const criarEmpresaMsg = criarEmpresa(sender, nomeEmpresa, tipoEmpresa);
          reply(criarEmpresaMsg);
          break;

        case 'verempresa':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const verEmpresaMsg = verEmpresa(sender);
          reply(verEmpresaMsg);
          break;

        case 'adicionarproduto':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const [nomeProduto, valorProdutoStr] = args.join(' ').split('/');
          if (!nomeProduto || !valorProdutoStr) {
            return reply('Por favor, forneça um nome e valor para o produto no formato: nomeProduto/valorProduto');
          }
          const valorProduto = parseInt(valorProdutoStr.trim(), 10);
          if (isNaN(valorProduto) || valorProduto > 300) {
            return reply('O valor do produto deve ser um número e não pode exceder 300 reais.');
          }
          const adicionarProdutoMsg = adicionarProduto(sender, nomeProduto.trim(), valorProduto);
          reply(adicionarProdutoMsg);
          break;

        case 'venderproduto':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const nomeProdutoVenda = args[0];
          if (!nomeProdutoVenda) return reply('Por favor, forneça o nome do produto a ser vendido.');
          const venderProdutoMsg = venderProduto(sender, nomeProdutoVenda);
          reply(venderProdutoMsg);
          break;

        case 'venderempresa':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const venderEmpresaMsg = venderEmpresa(sender);
          reply(venderEmpresaMsg);
          break;

        case 'vertodasempresas':
          if (!isModobn) return reply('Modo brincadeira está desativado.');
          const verTodasEmpresasMsg = verTodasEmpresas();
          reply(verTodasEmpresasMsg, null, {
            contextInfo: {
              mentionedJid: loadEmpresas().empresas.flatMap(e => e.dono)
            }
          });
          break;

        case 'banco': {


          var salldo = checkATMuser(sender);

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: `
╭───────────────────╮
│
│ *NOME: ${pushname}*
│
│ *DINHEIRO: Você tem ${salldo}*
│
│ *NUBANK: SECRETO*
│
╰───────────────────╯
                    `,
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Trabalhar",
                        id: `${prefix}trabalhar`
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              },
            },
            {}
          ).then((r) => console.log(r));
          break;
        }

        case 'trabalhar':

          MT = Math.floor(Math.random() * 200);
          var foda = [
            `Você estava minerando nas ilhas savitas e encontrou em seu caminho *R$ ${Number(MT).toFixed(2)}* em minerais preciosos! 💰`,
            `🗣💰 Você invadiu uma mina proibida e quando estava fazendo a mineração achou *R$ ${Number(MT).toFixed(2)}* em troca de ouro!`,
            `💎👷🏻‍♀️ Você invadiu uma mina de diamantes proibida, enquanto você estava fazendo a mineração, encontrou 2 diamantes equivalentes à *R$ ${Number(MT).toFixed(2)}*.`,
            `⛏️👷🏻‍♀️ Você escavou uma mina de ouro subterrânea em Minas Gerais e encontrou *R$ ${Number(MT).toFixed(2)}*!`,
            `🛫 Em uma de suas viagens para o interior da Flórida, você embarcou uma busca ao tesouro perdido e encontrou em seu caminho um cordão de ouro perdido avaliado em *R$ ${Number(MT).toFixed(2)}*.`,
            `😱🌟 Você invadiu a casa do vizinho e encontrou *R$ ${Number(MT).toFixed(2)}* escavando o quintal dele.`,
            `⛏️👷🏻‍♀️✨️ Você acaba de invadir em uma mina de esmeraldas desconhecida e encontrou *R$ ${Number(MT).toFixed(2)}*`,
            `🛥️💰 Você encontrou nas profundezas do oceanos, um tesouro em um navio antigo equivalente à *R$ ${Number(MT).toFixed(2)}*.`,
            `🌟 Você foi chamado para trabalhar na mina e encontrou milhares de resíduos! Como recompensa, você acaba de ganhar *R$ ${Number(MT).toFixed(2)}*. 😸`,
            `Você foi chamado para trabalhar na mina e encontrou muitos tesouros perdidos!👷🏼🌟 Como recompensa, você acaba de ganhar *R$ ${Number(MT).toFixed(2)}*.`
          ];

          var sinkqkqsina = foda[Math.floor(Math.random() * foda.length)];

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: `
${sinkqkqsina}
                    `,
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Trabalhar novamente",
                        id: `${prefix}trabalhar`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Ver banco",
                        id: `${prefix}banco`
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              }
            },
            {}
          ).then((r) => console.log(r));
          addKoinUser(sender, + MT);
          break;

        case 'arma': case 'comprararma': {

          if (!isModobn) return reply(`❌ *Modo Brincadeira está OFF, peça ao adm para ativar!* ❌`);
          if (arma.includes(sender)) return reply("*VOCE JA TEM UMA ARMA*");
          const dinheiro = checkATMuser(sender);
          const quantidader = 8000; // preço da arma
          if (dinheiro < quantidader) return reply(`*${pushname} VC NAO TEM DINHEIRO SUFICIENTE PARA COMPRAR UMA ARMA*\n\n*PREÇO: ${quantidader}*`);
          arma.push(`${sender}`);
          fs.writeFileSync('./funções_rpg/arma/arma.json', JSON.stringify(arma));
          addKoinUser(sender, -quantidader);
          await miwa.sendMessage(from, { text: `*ARMA COMPRADA COM SUCESSO 🔫*\n\n*CUSTO 💰: ${quantidader}*` }, { quoted: info });
        }
          break;

        case 'comprarvip': case 'cv': {

          if (!isModobn) return reply(`❌ *Modo Brincadeira está OFF, peça ao adm para ativar!* ❌`);
          if (premium.includes(sender)) return reply("*VOCE JA TEM VIP*");
          const dinheiro = checkATMuser(sender);
          const quantidader = 15000; // preço do vip
          if (dinheiro < quantidader) return reply(`*${pushname} VC NAO TEM DINHEIRO SUFICIENTE PARA COMPRAR O VIP*\n\n*PREÇO: ${quantidader}*`);
          premium.push(`${sender}`);
          fs.writeFileSync('./settings/media/premium.json', JSON.stringify(premium));
          addKoinUser(sender, -quantidader);
          await miwa.sendMessage(from, { text: `*VIP COMPRADO COM SUCESSO *\n\n*CUSTO 💰: ${quantidader}*` }, { quoted: info });
        }
          break;

        case 'venderarma': {

          if (!isModobn) return reply(`❌ *Modo Brincadeira está OFF, peça ao adm para ativar!* ❌`);
          if (!arma.includes(sender)) return reply(`voce ainda nem tem uma arma`);
          const index = arma.indexOf(sender);
          if (index !== -1) {
            arma.splice(index, 1);
            fs.writeFileSync('./funções_rpg/arma/arma.json', JSON.stringify(arma));
            addKoinUser(sender, 6000); // valor de venda da arma
            await miwa.sendMessage(from, { text: `*ARMA VENDIDA COM SUCESSO 🔫*\n\n*GANHO 💰: 6000*` }, { quoted: info });
          } else {
            return reply(`Erro ao vender a arma`);
          }
        }
          break;

        case 'loteria': {

          if (!isModobn) return reply(`Modo brincadeira está off, peça para o administrador ligar`);

          const resultado = Math.random();
          if (resultado < 0.1) { // 10% de chance de ganhar
            const premio = 10000; // Prêmio é 100 vezes o valor da aposta
            addKoinUser(sender, premio);
            return reply(`Parabéns! Você ganhou na loteria e recebeu R$ ${premio} como prêmio.`);
          } else {
            return reply(`Infelizmente você não ganhou na loteria. Boa sorte na próxima! Perdeu: 7 R$ por comprar o ticket`);
            addKoinUser(sender, - `7`);
          }
          break;
        }

        case 'apostaresportes': {

          if (!isModobn) return reply(`Modo brincadeira está off, peça para o administrador ligar`);
          if (args.length < 2) return reply(`Modo certo de se usar ${prefix}apostaresportes <time> <valor>\nExemplo: ${prefix}apostaresportes barcelona 500`);

          const timeApostado = args[0].toLowerCase();
          const valorAposta = parseInt(args[1]);

          if (isNaN(valorAposta) || valorAposta <= 0) return reply('Por favor, insira um valor válido para a aposta.');

          const chancesVitoria = Math.random();
          const chancesEmpate = Math.random();
          const chancesDerrota = Math.random();

          let mensagem = '';

          if (chancesVitoria > 0.33) {
            const valorGanho = Math.floor(Math.random() * 1000) + 1;
            addKoinUser(sender, valorGanho);
            mensagem = `Parabéns! Você ganhou a aposta e recebeu R$ ${valorGanho}.`;
          } else {
            mensagem = `Infelizmente, você perdeu a aposta e não recebeu nenhum dinheiro.`;
          }

          return reply(mensagem);
          break;
        }

        case 'investir': { // Criador: ryuu

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          if (args.length < 2) return reply(`Modo certo de se usar ${prefix}investir <tipo> <valor>\nExemplo: ${prefix}investir ações 1000\n\ntipos: criptomoedas,imóveis,fundos,ações`);

          const tiposInvestimento = ['ações', 'fundos', 'imóveis', 'criptomoedas'];
          const tipoInvestimento = args[0].toLowerCase();
          const valorInvestimento = parseInt(args[1]);

          if (!tiposInvestimento.includes(tipoInvestimento)) return reply(`Tipo de investimento inválido. Tipos disponíveis: ${tiposInvestimento.join(', ')}`);
          if (isNaN(valorInvestimento) || valorInvestimento <= 0) return reply('Por favor, insira um valor válido para investir.');

          const chance = Math.random();
          let mensagem = '';

          if (chance < 0.5) {
            confirmATM(sender, valorInvestimento);
            mensagem = `Seu investimento em ${tipoInvestimento} não deu certo e você perdeu R$ ${valorInvestimento}.`;
          } else {
            const retorno = Math.floor(Math.random() * 1000) + 1;
            addKoinUser(sender, retorno);
            mensagem = `Seu investimento em ${tipoInvestimento} deu certo e você ganhou R$ ${retorno}!`;
          }

          await btncomfoto(from, mensagem, "", "", "Clique para investir novamente", { url: 'https://telegra.ph/file/4319894a76630c5a3f034.jpg' }, "image", info, {}, [
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Investir novamente",
                id: `${prefix}investir ${tipoInvestimento} ${valorInvestimento}`
              }),
            },
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Ver banco",
                id: `${prefix}banco`
              }),
            }
          ]);
          break;
        }



        case 'roubarbanco': {
          ;
          if (!arma.includes(sender)) return reply(`voce ainda nem tem uma arma`)
          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);

          const roubo = Math.floor(Math.random() * 1000);
          const chance = Math.random();

          let message = '';
          if (chance < 0.3) {
            message = `🚓 Você foi pego tentando roubar o banco e perdeu R$ ${roubo}.`;
            addKoinUser(sender, -roubo);
          } else {
            message = `💰 Você conseguiu roubar o banco e ganhou R$ ${roubo}!`;
            addKoinUser(sender, +roubo);
          }

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: message
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Roubar novamente",
                        id: `${prefix}roubarbanco`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Ver banco",
                        id: `${prefix}banco`
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              }
            },
            {}
          ).then((r) => console.log(r));

          break;
        }


        case 'churrasqueira': case 'comprarchurrasqueira': {
          if (!isModobn) return reply(`O modo brincadeira está desligado, peça ao administrador para ligá-lo`);

          const hasChurrasqueira = churrasqueira.includes(sender);
          if (hasChurrasqueira) return reply("*VOCE JA TEM UMA CHURRASQUEIRA*");

          const dinheiro = checkATMuser(sender);
          const quantidader = 1000;  // Preço da churrasqueira

          if (dinheiro < quantidader) return reply(`*${pushname} VC NAO TEM DINHEIRO SUFICIENTE PARA COMPRAR UMA CHURRASQUEIRA*\n\n*PREÇO: ${quantidader}*`);

          churrasqueira.push(`${sender}`);
          fs.writeFileSync('./funções_rpg/churrasqueira/churrasqueira.json', JSON.stringify(churrasqueira));
          addKoinUser(sender, -quantidader);
          await miwa.sendMessage(from, { text: `*CHURRASQUEIRA COMPRADA COM SUCESSO 🍖*\n\n*CUSTO 💰: ${quantidader}*` }, { quoted: info });
        }
          break;

        case 'venderchurrasqueira': {
          if (!isModobn) return reply(`O modo brincadeira está desligado, peça ao administrador para ligá-lo`);

          if (!churrasqueira.includes(sender)) return reply(`VOCE AINDA NÃO TEM UMA CHURRASQUEIRA`);

          const indksbex = churrasqueira.indexOf(sender);
          if (indksbex > -1) {
            churrasqueira.splice(indksbex, 1);
            fs.writeFileSync("./funções_rpg/churrasqueira/churrasqueira.json", JSON.stringify(churrasqueira));
            addKoinUser(sender, +10000); // Valor de venda
            reply(`*VOCÊ VENDEU SUA CHURRASQUEIRA POR R$ 10000*`);
          }
        }
          break;

        case 'minerardiamante':
        case 'minerardima':

          if (!isModobn) return reply(`modo brincadeira está off, peça ao admin para ativar`);
          const mineDiamondsMsg = mineDiamonds(sender);
          reply(mineDiamondsMsg);
          break;

        case 'venderdiamante':
        case 'venderdima':

          if (!isModobn) return reply(`modo brincadeira está off, peça ao admin para ativar`);
          const sellDiamondsMsg = sellDiamonds(sender);
          reply(sellDiamondsMsg);
          break;

        case 'gerarcarro': {//criador: ryuu Akiyamax
          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`)

          const marcas = [
            'Toyota', 'Honda', 'Ford', 'Chevrolet', 'BMW', 'Mercedes', 'Audi', 'Volkswagen', 'Nissan', 'Hyundai',
            'Kia', 'Mazda', 'Subaru', 'Dodge', 'Jeep', 'Lexus', 'Acura', 'Infiniti', 'Lincoln', 'Volvo',
            'Mitsubishi', 'Buick', 'Cadillac', 'Chrysler', 'Jaguar', 'Land Rover', 'Porsche', 'Tesla', 'Fiat', 'Alfa Romeo',
            'Peugeot', 'Renault', 'Citroen', 'Ferrari', 'Lamborghini', 'Maserati', 'Bentley', 'Rolls-Royce', 'Aston Martin', 'McLaren',
            'Pagani', 'Bugatti', 'Koenigsegg', 'Mini', 'Smart', 'Saab', 'Opel', 'Vauxhall', 'Seat', 'Skoda',
            'Dacia', 'Lancia', 'Lotus', 'MG', 'Rover', 'SsangYong', 'Proton', 'Geely', 'Tata', 'Mahindra',
            'Maruti Suzuki', 'Holden', 'HSV', 'Scion', 'Ram', 'GMC', 'Hummer', 'Saturn', 'Pontiac', 'Oldsmobile',
            'Plymouth', 'Studebaker', 'DeLorean', 'Fisker', 'Lucid', 'Rivian', 'Polestar', 'Genesis', 'BYD', 'Chery',
            'Great Wall', 'Haval', 'Zotye', 'BAIC', 'Nio', 'XPeng', 'Wuling', 'Hongqi', 'Aiways', 'VinFast'
          ];//AkiyamaX
          const modelos = [
            'Corolla', 'Civic', 'Mustang', 'Camaro', 'X5', 'C-Class', 'A4', 'Golf', 'Altima', 'Elantra',
            'Sorento', 'CX-5', 'Impreza', 'Challenger', 'Wrangler', 'RX', 'TLX', 'Q50', 'Navigator', 'XC90',
            'Outlander', 'Enclave', 'Escalade', 'Pacifica', 'XF', 'Range Rover', '911', 'Model S', '500', 'Giulia'
          ];
          const anos = [
            '1995', '1996', '1997', '1998', '1999', '2000', '2001', '2002', '2003', '2004',
            '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014',
            '2015', '2016', '2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024'
          ];//franky
          const cores = [
            'Vermelho', 'Azul', 'Preto', 'Branco', 'Prata', 'Cinza', 'Verde', 'Amarelo', 'Rosa', 'Roxo',
            'Marrom', 'Bege', 'Dourado', 'Laranja', 'Turquesa', 'Ciano', 'Magenta', 'Lavanda', 'Coral', 'Marinho',
            'Vinho', 'Oliva', 'Amarelo Canário', 'Cobre', 'Cinza Chumbo', 'Grafite', 'Cinza Claro', 'Azul Bebê', 'Pérola', 'Prata Metálico'
          ];
          //ryuu x
          const marca = marcas[Math.floor(Math.random() * marcas.length)];
          const modelo = modelos[Math.floor(Math.random() * modelos.length)];
          const ano = anos[Math.floor(Math.random() * anos.length)];
          const renavam = Math.floor(Math.random() * 10000000000).toString().padStart(11, '0');
          const placa = `${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}-${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)}`;
          const cor = cores[Math.floor(Math.random() * cores.length)];

          const mensagem = `
┏━── *「 🚗 GERADOR DE CARROS 🚗 」*  ─━┓
│
│ 🏎️ *Marca:* ${marca}
│ 🚘 *Modelo:* ${modelo}
│ 📅 *Ano:* ${ano}
│ 🔖 *RENAVAM:* ${renavam}
│ 🚓 *Placa:* ${placa}
│ 🎨 *Cor:* ${cor}
│
┗━───────────────────────────━┛
`;
          await btncomfoto(from, mensagem, "", "", "Clique para gerar um novo carro", { url: 'https://telegra.ph/file/e7f95b1b557a53ffc96a6.jpg' }, "image", info, {}, [
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Gerar novo carro",
                id: `${prefix}gerarcarro`
              }),
            },
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Ver banco",
                id: `${prefix}banco`
              }),
            },
          ]);
          break;
        }//ryuu

        case 'tigrinho': {

          const quetude = Math.floor(Math.random() * 100) + 50;
          const options = [
            { message: "TIGRINHO JOGOU 1 CARTA DE R$ {quetude}!", min: 5, max: 20 },
            { message: "VOCE APOSTOU TUDO NO TIGRINHO R$ {quetude}!", min: 10, max: 30 },
            { message: "TIGRINHO TE DEU R$ {quetude}!", min: 20, max: 50 },
            { message: "TIGRINHO TE DEU NADA HOJE", min: 0, max: 0 },
            { message: "PEGOU O CARTÃO DA MAE E GANHO NO TIGRE: R$ {quetude}!", min: 30, max: 80 },
            { message: "TIGRE PAGOU: R$ {quetude}!", min: 15, max: 40 }
          ];
          addKoinUser(sender, + quetude);
          const randomIndex = Math.floor(Math.random() * options.length);
          const selectedOption = options[randomIndex];

          const ainibut = Math.floor(Math.random() * (selectedOption.max - selectedOption.min + 1)) + selectedOption.min;

          const message = selectedOption.message.replace("{quetude}", ainibut);

          await miwa.relayMessage(from,
            {
              interactiveMessage: {
                body: {
                  text: `🐯 ${message}`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Jogar novamente",
                        id: `${prefix}tigrinho`
                      }),
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Ver banco",
                        id: `${prefix}banco`
                      }),
                    }
                  ],
                  messageParamsJson: "",
                },
              }
            },
            {}
          ).then((r) => console.log(r));

          break;
        }

        case 'pintarcasa': { // Criador: ryuu Akiyamax

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          const cores = ['vermelha', 'azul', 'verde', 'amarela', 'branca', 'preta'];
          const tempo = Math.floor(Math.random() * 60) + 1;
          const salario = Math.floor(Math.random() * 500) + 100;
          reply(`🖌️ Iniciando pintura de casa...\n\n🎨 Cor da tinta: ${cores[Math.floor(Math.random() * cores.length)]}\n⏳ Tempo estimado: ${tempo} minutos\n\nAguarde enquanto pintamos a casa...`);
          await sleep(tempo * 1000);
          const sucesso = Math.random() < 0.8;
          let mensagem = '';
          if (sucesso) {
            addKoinUser(sender, salario);
            mensagem = `
┏━── *「️ 🏠 PINTURA DE CASA 🏠 」*  ─━┓
│▢ Cor da casa: ${cores[Math.floor(Math.random() * cores.length)]}
│▢ Tempo gasto: ${tempo} minutos
│▢ Salário recebido: R$ ${salario.toFixed(2)}
┗━── *「️ 🏠 PINTURA DE CASA 🏠 」*  ─━┛
        `;
          } else {
            mensagem = `❌ Infelizmente, a pintura da casa falhou e você não recebeu nenhum salário.`;
          }
          await btncomfoto(from, mensagem, "", "", "Clique para pintar outra casa", { url: 'https://telegra.ph/file/970c3b7f3750294ab76c7.jpg' }, "image", info, {}, [
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Pintar outra casa",
                id: `${prefix}pintarcasa`
              }),
            },
            {
              name: "quick_reply",
              buttonParamsJson: JSON.stringify({
                display_text: "Ver banco",
                id: `${prefix}banco`
              }),
            }
          ]);
          break;
        }

        case 'casar':

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          if (!menc_os2 || menc_jid2[1]) return reply('❕Marque a pessoa');
          if (!menc_os2) return reply('Por favor, mencione um parceiro para casar.');
          const casarMsg = casar(sender, menc_os2);
          reply(casarMsg);
          break;

        case 'dupla':
        case 'vercasamento':
          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          const verCasamentoMsg = verCasamento(sender);
          reply(verCasamentoMsg, null, {
            contextInfo: {
              mentionedJid: [sender, loadCasamentos().casamentos.find(c => c.parte1 === sender || c.parte2 === sender).parte2]
            }
          });
          break;

        case 'divorciar':

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          const divorciarMsg = divorciar(sender);
          reply(divorciarMsg);
          break;

        case 'vertodoscasamentos':

          if (!isModobn) return reply(`modo brincadeira ta off, pede pro adm`);
          const verTodosCasamentosMsg = verTodosCasamentos();
          reply(verTodosCasamentosMsg, null, {
            contextInfo: {
              mentionedJid: loadCasamentos().casamentos.flatMap(c => [c.parte1, c.parte2])
            }
          });
          break;

        case 'criarperfil':
          const nomePerfil = args[0];
          const descricao = args.slice(1).join(' ');
          if (!nomePerfil || !descricao) return reply('Por favor, forneça um nome e uma descrição para o perfil.');
          const criarPerfilMsg = criarPerfilTinder(sender, nomePerfil, descricao);
          reply(criarPerfilMsg);
          break;

        case 'excluirperfil':
          const excluirPerfilMsg = excluirPerfilTinder(sender);
          reply(excluirPerfilMsg);
          break;

        case 'todosperfis':
          const todosPerfisMsg = todosPerfisTinder();
          reply(todosPerfisMsg);
          break;

        case 'vermeuperfil':
          const verMeuPerfilMsg = verMeuPerfilTinder(sender);
          reply(verMeuPerfilMsg);
          break;

        case 'curtirperfil':
          const perfilCurtido = args.join(' ');
          if (!perfilCurtido) return reply('Por favor, forneça o nome do perfil que deseja curtir.');
          const curtirPerfilMsg = curtirPerfilTinder(sender, perfilCurtido);
          reply(curtirPerfilMsg);
          break;

        case 'descurtirperfil':
          const perfilDescurtido = args.join(' ');
          if (!perfilDescurtido) return reply('Por favor, forneça o nome do perfil que deseja descurtir.');
          const descurtirPerfilMsg = descurtirPerfilTinder(sender, perfilDescurtido);
          reply(descurtirPerfilMsg);
          break;

        case 'comentarperfil':
          const perfilComentado = args[0];
          const textoComentario = args.slice(1).join(' ');
          if (!perfilComentado || !textoComentario) return reply('Por favor, mencione o perfil e forneça o texto do comentário.');
          const comentarPerfilMsg = comentarPerfilTinder(sender, perfilComentado, textoComentario);
          reply(comentarPerfilMsg);
          break;

        case 'tinder':
          const perfilAleatorioMsg = todosPerfisTinder();
          reply(perfilAleatorioMsg);
          break;

        case 'vermeutinder':
          const verMeuPerfilTinderMsg = verMeuPerfilTinder(sender);
          reply(verMeuPerfilTinderMsg);
          break;

        // FIM

        //CRÉDITO: ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐
        // FLW FAZUL 
        //KKKKKK


        case 'branca':
          if (!isGroup) return reply("Apenas em grupos")
          reply(`${pushname} ➮ Pesquisando a ficha de Macaca branco: @${sender_ou_n.split("@")[0]} aguarde...`)
          await sleep(3000)
          await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/2983673e1672bfe9a3d6b.png' }, gifPlayback: false, caption: `🙈 *Resultado da Pesquisa* 🐵\n\n @${sender_ou_n.split("@")[0]} você é: \n\n❰ *${Math.floor(Math.random() * 105)}%* ❱ Macaca branca 🤍 \n`, mentions: [sender] }, { quoted: info })
          break

        case 'branco':
          if (!isGroup) return reply("Apenas em grupos")
          reply(`${pushname} ➮ Pesquisando a ficha de macaco branco: @${sender_ou_n.split("@")[0]} aguarde...`)
          await sleep(3000)
          await miwa.sendMessage(from, { image: { url: 'https://telegra.ph/file/129c668ffa2012db3fb5c.png' }, gifPlayback: false, caption: `🐵 *Resultado da Pesquisa* 🙈\n\n @${sender_ou_n.split("@")[0]} você é: \n\n❰ *${Math.floor(Math.random() * 105)}%* ❱ Macaco branco 🤍 \n`, mentions: [sender] }, { quoted: info })
          break

        //BY ᴷᴷᴳᴿ𝐄𝐑𝐈𝐂𝐊 | 𝟔𝟔𝟔 𖤐
        //ESSA CASE E DO MEU BOT, FAZ U L KSKSKSKSK

        case 'bancopix': { //nunu que fez essa case (deixa os créditos por favor)
          if (!isPremium) return reply('🔒 *Acesso Restrito:* Você precisa ser um usuário premium para acessar esta funcionalidade.');
          try {
            const response = await fetch('https://brasilapi.com.br/api/pix/v1/participants');
            const data = await response.json();
            if (!data || data.length === 0) {
              return reply('🔍 *Nenhuma instituição encontrada:* Não foram encontrados dados na API.');
            }
            const shuffledData = data.sort(() => 0.5 - Math.random());
            const selectedInstitutions = shuffledData.slice(0, 5);
            const institutions = selectedInstitutions.map(inst => `
🔢 *ISPB:* ${inst.ispb}
🏦 *Nome:* ${inst.nome}
🔍 *Nome Reduzido:* ${inst.nome_reduzido}
📅 *Início da Operação:* ${new Date(inst.inicio_operacao).toLocaleDateString()}
        `).join('\n\n');
            const message = `
📊 *Informações Aleatórias de Instituições Bancárias para Pix:*
${institutions}
        `;
            reply(message);
          } catch (error) {
            console.error(error);
            reply('⚠️ *Erro:* Não foi possível consultar as instituições. Tente novamente mais tarde.');
          }
          break; //nunu que fez essa case (deixa os créditos por favor)
        }


        case 'feriados':
          if (!q) return reply(`Favor informar o ano desejado.`);
          try {
            const resposta = await fetch(`https://api.invertexto.com/v1/holidays/${q}?token=5980|9n1NZ449fdM1Hxs8K8urHxDZRVfEznwI&state=br`);
            const feriados = await resposta.json();
            let mensagem = `*• Feriados para o ano de ${q}*:\n\n`;
            feriados.forEach(({ date, name, type }) => { mensagem += `*• Data:* _${date}_\n*• Feriado:* _${name}_\n*• Tipo:* _${type}_\n*—*\n` });
            await miwa.sendMessage(from, { text: mensagem }, { quoted: info })
          } catch (error) { reply(`Erro ao obter a lista de feriados.`) }
          break;


        case 'feriados2': { //nunu que fez essa case (deixa os créditos por favor)
          if (!isPremium) return reply('🔒 *Acesso Restrito:* Você precisa ser um usuário premium para acessar esta funcionalidade.');
          const ano = q;
          if (!ano || isNaN(ano) || ano.length !== 4) {
            return reply('❗ *Erro:* Por favor, forneça um ano válido (4 dígitos).');
          }
          try {
            const response = await fetch(`https://brasilapi.com.br/api/feriados/v1/${ano}`);
            const data = await response.json();
            if (!data || data.length === 0) {
              return reply('🔍 *Nenhum feriado encontrado:* Não foram encontrados dados para o ano solicitado.');
            }
            const holidays = data.map(holiday => `
📅 *Data:* ${new Date(holiday.date).toLocaleDateString('pt-BR')}
🗓️ *Nome:* ${holiday.name}
🌍 *Tipo:* ${holiday.type}
        `).join('\n\n');
            const message = `
📅 *Feriados Nacionais de ${ano}:*
${holidays}
        `;
            reply(message);
          } catch (error) {
            console.error(error);
            reply('⚠️ *Erro:* Não foi possível consultar os feriados. Tente novamente mais tarde.');
          }
          break; //nunu que fez essa case (deixa os créditos por favor)
        }


        case 'npm': {//nunu x franky
          if (!q) return reply('Por favor, forneça o termo de pesquisa para npm.');

          try {
            const searchQuery = encodeURIComponent(q.trim());
            const searchUrl = `https://registry.npmjs.org/-/v1/search?text=${searchQuery}&size=5`;

            axios.get(searchUrl)
              .then(response => {
                const packages = response.data.objects;

                if (!packages || packages.length === 0) {
                  return reply(`Nenhum resultado encontrado para "${q}" na pesquisa do npm.`);
                }
                //nunu x franky
                let results = packages.map(pkg => ({
                  name: pkg.package.name,
                  description: pkg.package.description || 'Descrição não disponível',
                  author: pkg.package.author ? pkg.package.author.name : 'Autor desconhecido',
                  version: pkg.package.version,
                  link: `https://www.npmjs.com/package/${pkg.package.name}`
                }));

                let message = `🔍 Resultados da pesquisa npm para "${q}":\n\n`;
                results.forEach(result => {
                  message += `📦 *Nome:* ${result.name}\n`;
                  message += `📄 *Descrição:* ${result.description}\n`;
                  message += `👤 *Autor:* ${result.author}\n`;
                  message += `🔖 *Versão:* ${result.version}\n`;
                  message += `🔗 *Link:* ${result.link}\n\n`;
                });

                reply(message);
              })
              .catch(error => {
                console.error(error);
                reply('Erro ao realizar a pesquisa no npm. Por favor, tente novamente mais tarde.');
              });
          } catch (error) {
            console.error(error);
            reply('Ocorreu um erro ao processar sua solicitação para npm.');
          }

          break;//nunu akame npm
        }

        case 'boquetedele': case 'mamadadele': case 'boquetedela': case 'mamadadela'://by Tzn
          if (!isGroup) return reply('Só em Grupo')
          reagir(from, "🍼");//by Tzn Modas
          if (!menc_os2 || menc_jid2[1]) return reply('marque a pessoa que você quer que lhe pague um boquete, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: `https://telegra.ph/file/122956e858e161baf3173.mp4` }, gifPlayback: true, caption: `*O(a) @${menc_os2.split('@')[0]} acabou de lhe fazer um boquete gostosinho [🍼]*`, mentions: [menc_os2] }, { quoted: info })
          break //by tzn

        case 'boquete': case 'mamada':
          if (!isGroup) return reply('Só em Grupo')
          reagir(from, "🍼");//by tzn
          if (!menc_os2 || menc_jid2[1]) return reply('marque a pessoa que você quer pagar um boquete, a mensagem ou o @')
          await miwa.sendMessage(from, { video: { url: `https://telegra.ph/file/a027ace564e6b01daefc7.mp4` }, gifPlayback: true, caption: `*Você Acabou de pagar um boquete gostosinho no(a): @${menc_os2.split('@')[0]} [🍼]*`, mentions: [menc_os2] }, { quoted: info })
          break //by : Tzn

        case 'sexo': case 'sex': case 'Sexo'://by Tzn
          if (!isGroup) return reply('Só em Grupo')
          if (!menc_os2 || menc_jid2[1]) return reply('marque a pessoa que você quer fazer sexo, a mensagem ou o @')
          random = `${Math.floor(Math.random() * 120)}`
          fioteh = `${Math.floor(Math.random() * 100)}`
          reagir(from, "🤱")//by Tzn modas
          await miwa.sendMessage(from, {
            video: { url: `https://telegra.ph/file/6060d62a642f78d9375d3.mp4` }, gifPlayback: true, caption: `*[👤] Olá, ${pushname}. Você Acabou de fazer sexo com(a) @${menc_os2.split('@')[0]} 🥵*\n
*[💦] Chance de você ter ejaculado dentro:* _${random}%_\n\n*[🤱] Possíveis chances do @${menc_os2.split('@')[0]} ter engravidado é:* _${fioteh}%_`, mentions: [menc_os2]
          }, { quoted: info })
          break//by Tzn modas

        case 'masturbarele': case 'masturbaçãodele': case 'masturbarela': case 'masturbaçãodela':
          if (!isGroup) return reply('Só em Grupo')//by Tzn
          if (!menc_os2 || menc_jid2[1]) return reply('❕Marque o @ do alvo que você quer ver a força.')
          random = `${Math.floor(Math.random() * 100)}`
          reagir(from, "💦")
          await miwa.sendMessage(from, {
            image: { url: `https://telegra.ph/file/d4c37346be169994c6f4f.jpg` }, caption: `*[👤] Olá, ${pushname}. Você acabou de masturbar o(a) @${menc_os2.split('@')[0]} 🥵*\n
*[💦] Chance de você ter feito o(a) @${menc_os2.split('@')[0]} gozar foi de:* _${random}%_`, mentions: [menc_os2]
          }, { quoted: info })
          break//by Tzn

        case 'masturbar': case 'masturbação': case 'masturbacao': //by tzn
          if (!isGroup) return reply('Só em Grupo')
          random = `${Math.floor(Math.random() * 100)}`
          reagir(from, "💦")//by tzn
          await miwa.sendMessage(from, {
            image: { url: `https://telegra.ph/file/577f33732f4678311466f.jpg` }, caption: `[👤] *Olá, ${pushname}. Você acabou de se masturbar🥵*\n
*[💦] Chance de você ter gozado:* _a chance de vc ter gozado é de ${random}%_`
          }, { quoted: info })
          break

        case 'vasco':
          if (!q.includes('|')) return reply(`* Você precisa usar no seguinte formato: (Ex: ${prefixo + command} Nome | Posição que você quer jogar)*`)
          var [txt1, txt2] = q.split("|")
          tx = await getBuffer(`https://tohka.tech/api/canvas/vasco?titulo1=${txt2}&nome=${txt1}&perfil=${ppurl.data}&apikey=nduok4MPQR`)
          await miwa.sendMessage(from, { image: tx }, { quoted: jin }).catch(e => {
            reply("*Um erro foi detectado, Verifique se está usando da maneira correta (obs: Não usem palavras com acentos e nem emojis).*")
            reagir('✖️')
          })
          break

        case 'ultplv':
        case 'ultimas-palavras': {
          try {
            if (!isGroup) return reply("*Vai usar saporra no teu pv pra quê?*")
            if (!isBotGroupAdmins) return reply("*O Bot precisa ser adm, seu corno*")
            if (!isGroupAdmins && !isDono) return reply("*Coé kkkkk, quer usar esse comando? nem adm tu é, fdp*")
            if (!menc_os2 || menc_jid2[1]) return reply("Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário...")
            if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Este usuário já foi removido do grupo ou saiu.")
            if (JSON.stringify(numeroDono).indexOf(menc_os2) >= 0) return reply('Não posso remover meu dono 🤧')
            if (BotNumber.includes(menc_os2)) return reply('Não sou besta de remover eu mesmo né 🙁, mas estou decepcionado com você')
            if (JSON.stringify(groupAdmins).indexOf(menc_os2) >= 0) return reply('Não posso remover um (a) Administrador (a).')
            reply("*Elx tem 30s para falar suas últimas palavras!*")
            await delay(30000)
            await miwa.sendMessage(from, { text: `@${menc_os2.split("@")[0]} foi Removido (a) 👾`, mentions: [menc_os2] })
            miwa.groupParticipantsUpdate(from, [menc_os2], "remove")
          } catch (e) {
            console.log(e)
          }
        }
          break



        case 'ranknazista': case 'ranknazistas':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `*💂‍♂RANK DOS 5 MAIS NAZISTAS DO GRUPO 卐🤡*\n\n`
          for (var i = 0; i < 5; i++) {
            ABC += `${Math.floor(Math.random() * 100)}% @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnknazista);
          break;

        case 'rankotaku': case 'rankotakus':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `*㊙ RANK DOS 5 MAIS OTAKU DO GRUPO ( ˶•̀ _•́ ˶)*\n\n`
          for (var i = 0; i < 5; i++) {
            ABC += `${Math.floor(Math.random() * 100)}% @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnkotaku);
          break;

        case 'rankpau':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          ABC = `*RANK DOS 5 PAU MAIOR DO GRUPO 📏*\n\n`
          TMPAU = ["Pequeno pra cact, se mata maluco 🥴", `Pequenininho chega ser até fofo 🥺`, `Menor que meu dedo mindinho pequeno demais 😑`, `Até que dá sentir, tá na média 😌`, `Grandinho 🥵`, `Grande até `, `Gigantesco igual meu braço 😖`, `Enorme quase chega no útero 🤧`, `Grandão demais em, e uii 🤯`, `Vara de pegar manga, grande demais, como sai na rua assim??`, "Que grandão em, nasceu metade animal 😳"]
          for (var i = 0; i < 5; i++) {
            ABC += `${TMPAU[Math.floor(Math.random() * TMPAU.length)]} _- @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n\n`
          }
          mencionarIMG(ABC, rnkpau);
          break;

        case 'dianatal': {
          if (!isGroup) return reply('Este comando só pode ser usado em grupos.');
          const natal = new Date('2024-12-25');
          const hoje = new Date();
          const diasRestantes = Math.ceil((natal - hoje) / (1000 * 60 * 60 * 24));
          const nununatalcu = `
🎄 *Contador Regressivo para o Natal* 🎄

Faltam apenas ${diasRestantes} dias para o Natal! 🎅

Vamos nos preparar para as festividades!

`;
          await miwa.sendMessage(from, { text: nununatalcu }, { quoted: info });
          setInterval(async () => {
            const hojeAtual = new Date();
            const diasRestantesAtualizados = Math.ceil((natal - hojeAtual) / (1000 * 60 * 60 * 24));
            const nununatalcuAtualizada = `
🎄 *Contador Regressivo para o Natal* 🎄

Faltam apenas ${diasRestantesAtualizados} dias para o Natal! 🎅

Vamos nos preparar para as festividades!
`;
            await miwa.sendMessage(from, { text: nununatalcuAtualizada }, { quoted: info });
          }, 24 * 60 * 60 * 1000);
          break;
        }

        case 'totalcmd': case 'totalcomando': {
          fs.readFile('./index.js', 'utf8', (err, data) => {
            if (err) throw err;
            let regex = /case\s'(\w+)'/g;
            let match;
            let caseNames = [];
            while ((match = regex.exec(data)) !== null) {
              caseNames.push(match[1]);
            }
            let output = '' + caseNames.join('\n• ');
            let totalCount = caseNames.length;
            reply(`Ola ${pushname} atualmente eu tenho um total de: ${totalCount} comandos.`);
          });
        }
          break

        case 'mencionar':
          if (!q) return reply(`Você usou o comando de forma incorreta, use a correta: ${prefix}mencionar corno`)
          if (!isGroup) return reply(`Esta brincadeira só funciona em grupos.`)
          if (!isModobn) return reply(mess.onlyGroupFun(prefix))
          d = []
          teks = `- Estou mencionando o *${q}* do grupo: `
          for (i = 0; i < 1; i++) {
            r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
            teks += `@${groupMembers[r].id.split('@')[0]}`
            d.push(groupMembers[r].id)
          }
          await mentions(teks, d, true)
          break;

        case 'jogodavelha':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!menc_jid2) return reply("Marque junto com o comando, o @ do usuário que deseja desafiar..")
          joguinhodavelhajs.push(sender)
          fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
          joguinhodavelhajs2.push(from)
          fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
          if (fs.existsSync(`./arquivos/tictactoe/db/${from}.json`)) {
            const boardnow = setGame(`${from}`);
            const matrix = boardnow._matrix;
            const chatMove = `*🎮Ꮐ̸Ꭺ̸Ꮇ̸Ꭼ̸ Ꭰ̸Ꭺ̸ Ꮩ̸Ꭼ̸Ꮮ̸Ꮋ̸Ꭺ̸🕹️*
     
[❗] Alguém está jogando no momento...\n\n@${boardnow.X} VS @${boardnow.O}
     
❌ : @${boardnow.X}
⭕ : @${boardnow.O}
     
 Sua vez : @${boardnow.turn == "X" ? boardnow.X : boardnow.O}
     
${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
`;
            await miwa.sendMessage(from, { text: chatMove }, {
              quoted: info,
              mentions: [
                boardnow.X + "@s.whatsapp.net",
                boardnow.O + "@s.whatsapp.net",
              ]
            });
            return;
          }
          if (argss.length === 1)
            return reply(`*⟅❗⟆ Jogue com Alguem!!!!*
*para inicar a partida : ${prefix + command} @membro do gp*`);
          const boardnow = setGame(`${from}`);
          console.log(`Start No jogodavelha ${boardnow.session}`);
          boardnow.status = false;
          boardnow.X = sender.replace("@s.whatsapp.net", "");
          boardnow.O = argss[1].replace("@", "");
          var blabord = [`${boardnow.X}`, `${boardnow.O}`]
          fs.writeFileSync(`./arquivos/tictactoe/db/${from}.json`,
            JSON.stringify(boardnow, null, 2)
          );
          const strChat = `*『📌ᎬՏᏢᎬᎡᎪΝᎠϴ ϴ ϴᏢϴΝᎬΝͲᎬ⚔️』*
     
@${sender.replace("@s.whatsapp.net",
            "")} _está te desafiando para uma partida de jogo da velha..._
_[ ${argss[1]} ] Use *『S』* para aceitar ou *『N』* para não aceitar..._\n\nEm caso de problemas, marque algum administrador para resetar o jogo com o comando ${prefix}rv`;
          b = [sender, menc_jid]
          mentions(strChat, b, true)
          break

        case 'resetarvelha':
        case 'resetavelha':
        case 'resetarv':
        case 'resetav':
        case 'resetvelha':
        case 'rv':
          if (!isJoguin && !isGroupAdmins) return reply(`Fale com quem iniciou o jogo, só ele pode resetar, ou então algum admin.`)
          if (fs.existsSync("./arquivos/tictactoe/db/" + from + ".json")) {
            DLT_FL("./arquivos/tictactoe/db/" + from + ".json");
            reply(`Jogo da velha resetado com sucesso nesse grupo!`);
            joguinhodavelhajs.splice([])
            fs.writeFileSync('./database/usuarios/joguinhodavelha.json', JSON.stringify(joguinhodavelhajs))
            joguinhodavelhajs2.splice([])
            fs.writeFileSync('./database/usuarios/joguinhodavelha2.json', JSON.stringify(joguinhodavelhajs2))
          } else {
            reply(`Não a nenhuma sessão em andamento...`);
          }
          break

        case "ppt":
          if (args.length < 1) return reply(`Você deve digitar ${prefix}ppt pedra, ${prefix}ppt papel ou ${prefix}ppt tesoura`)
          ppt = ["pedra", "papel", "tesoura"]
          ppy = ppt[Math.floor(Math.random() * ppt.length)]
          ppg = Math.floor(Math.random() * 1) + 10
          pptb = ppy
          if ((pptb == "pedra" && args == "papel") ||
            (pptb == "papel" && args == "tesoura") ||
            (pptb == "tesoura" && args == "pedra")) {
            var vit = "vitoria"
          } else if ((pptb == "pedra" && args == "tesoura") ||
            (pptb == "papel" && args == "pedra") ||
            (pptb == "tesoura" && args == "papel")) {
            var vit = "derrota"
          } else if ((pptb == "pedra" && args == "pedra") ||
            (pptb == "papel" && args == "papel") ||
            (pptb == "tesoura" && args == "tesoura")) {
            var vit = "empate"
          } else if (vit = "undefined") {
            return reply(`Você deve digitar ${prefix}ppt pedra, ${prefix}ppt papel ou ${prefix}ppt tesoura`)
          }
          if (vit == "vitoria") {
            var tes = "Vitória do jogador"
          }
          if (vit == "derrota") {
            var tes = "A vitória é do BOT"
          }
          if (vit == "empate") {
            var tes = "O jogo terminou em empate"
          }
          reply(`${NomeDoBot} jogou: ${pptb}\nO jogador jogou: ${args}\n\n${tes}`)
          break

        case 'anagrama':
          if (!isGroup) return reply(mess.onlyGroup())
          const anaaleatorio = Math.floor(Math.random() * palavrasANA.length)
          if (!isGroupAdmins) return reply('Comando apenas para admins..')
          if (args.length == 0) return reply('Use 1 para ativar o jogo do anagrama, ou seja, para desativar utilize o valor numérico 0')
          if (args.join(' ') === '1') {
            if (fs.existsSync(`./arquivos/games/anagrama/${from}.json`)) {
              let dataAnagrama2 = JSON.parse(fs.readFileSync(`./arquivos/games/anagrama/${from}.json`))
              reply(`O jogo já foi iniciado neste grupo:
Anagrama: ${dataAnagrama2.embaralhada}
Uma dica: ${dataAnagrama2.dica}
`)
            } else {
              fs.writeFileSync(`./arquivos/games/anagrama/${from}.json`, `${JSON.stringify(palavrasANA[anaaleatorio])}`)
              await miwa.sendMessage(from, {
                text: `╭━━ ⪩「 Descubra a palavra 」
▢ ⌁ ⚠︎ Anagrama: ${palavrasANA[anaaleatorio].embaralhada}
▢ ⌁ ⚠︎ Dica: ${palavrasANA[anaaleatorio].dica}
╰━━━ ⪨ 「 ${NomeDoBot} 」`
              })
            }
          } else if (args.join(' ') === '0') {
            if (!fs.existsSync(`./arquivos/games/anagrama/${from}.json`)) return reply('Não tem como desativar o jogo do anagrama pôs ele não foi ativado')
            fs.unlinkSync(`./arquivos/games/anagrama/${from}.json`)
            reply("Desativado com sucesso.")
          }
          break

        case 'quizanimais':
          if (!isGroup) return reply(mess.onlyGroup())
          const animaisquiz = Math.floor(Math.random() * quizanimais.length)
          if (!isGroupAdmins) return reply('Comando apenas para admins..')
          if (args.length == 0) return reply('Use 1 para ativar o quiz animais, ou seja, para desativar utilize o valor numérico 0')
          if (args.join(' ') === '1') {
            if (fs.existsSync(`./arquivos/games/quiz-animais/${from}.json`)) {
              let dataAnagrama2 = JSON.parse(fs.readFileSync(`./arquivos/games/quiz-animais/${from}.json`))
              imagemtexto = `╭━━ ⪩ 「 Descubra o animal 」
▢ ⌁ ⚠︎ *Jogador:* ${pushname}
╰━━━ ⪨ 「 ${NomeDoBot} 」`
              wew = await getBuffer(`${dataAnagrama2.foto}`)
              await miwa.sendMessage(from, { image: wew, caption: imagemtexto, thumbnail: wew }, { quoted: selo })
            } else {
              fs.writeFileSync(`./arquivos/games/quiz-animais/${from}.json`, `${JSON.stringify(quizanimais[animaisquiz])}`)
              imagemtexto = `╭━━ ⪩ 「 Descubra o animal 」
▢ ⌁ ⚠︎ *Jogador:* ${pushname}
╰━━━ ⪨ 「 ${NomeDoBot} 」`
              wew = await getBuffer(`${dataAnagrama2.foto}`)
              await miwa.sendMessage(from, { image: wew, caption: imagemtexto, thumbnail: wew }, { quoted: selo })
            }
          } else if (args.join(' ') === '0') {
            if (!fs.existsSync(`./arquivos/games/quiz-animais/${from}.json`)) return reply('Não tem como desativar o jogo pôs ele não foi ativado')
            fs.unlinkSync(`./arquivos/games/quiz-animais/${from}.json`)
            reply("Desativado com sucesso.")
          }
          break

        case 'cassino':
          reply(`Olá ${pushname} - Aguarde 9 segundos para sair o resultado da roleta..`)
          const soto = ['🍊 : 🍒 : 🍐', '🍒 : 🔔 : 🍊', '🍇 : 🍇 : 🍇', '🍊 : 🍋 : 🔔', '🔔 : 🍒 : 🍐', '🔔 : 🍒 : 🍊', '🍊 : 🍋 : 🍊', '🍐 : 🍒 : 🍋', '🍐 : 🍐 : 🍐', '🍊 : 🍒 : 🍒', '🔔 : 🔔 : 🍇', '🍌 : 🍒 : 🔔', '🍐 : 🔔 : 🔔', '🍊 : 🍋 : 🍒', '🍋 : 🍋 : 🍌', '🔔 : 🔔 : 🍇', '🔔 : 🍐 : 🍇', '🔔 : 🔔 : 🔔', '🍒 : 🍒 : 🍒', '🍌 : 🍌 : 🍌']
          const somtoy2 = sotoy[Math.floor(Math.random() * sotoy.length)]
          if ((somtoy2 == '🥑 : 🥑 : 🥑') || (somtoy2 == '🍉 : 🍉 : 🍉') || (somtoy2 == '🍓 : 🍓 : 🍓') || (somtoy2 == '🍎 : 🍎 : 🍎') || (somtoy2 == '🍍 : 🍍 : 🍍') || (somtoy2 == '🥝 : 🥝 : 🥝') || (somtoy2 == '🍑 : 🍑 : 🍑') || (somtoy2 == '🥥 : 🥥 : 🥥') || (somtoy2 == '🍋 : 🍋 : 🍋') || (somtoy2 == '🍐 : 🍐 : 🍐') || (somtoy2 == '🍌 : 🍌 : 🍌') || (somtoy2 == '🍒 : 🍒 : 🍒') || (somtoy2 == '🔔 : 🔔 : 🔔') || (somtoy2 == '🍊 : 🍊 : 🍊') || (somtoy2 == '🍇 : 🍇 : 🍇')) {
            var Vitória = "Canta comigo é o brazzino... *Você ganhou! Parabéns amigo!*"
          } else {
            var Vitória = "*Você perdeu..* Que pena! Não desista, tente novamente."
          }
          setTimeout(async function () {
            const cassino = `Depois de 9 segundos passados, aqui está o resultado da roleta, vamos ver?
*➬ Resultado da Roleta -* ${somtoy2}

${Vitória}`
            msgSemQuoted(cassino)
          }, 9000)
          break

        //==(AUDIOS/DE-MUSICA/ZOUEIRA/ETC..)===\\

        //=====(ALTERADOR-DE-AUDIO/VIDEO)=======\\

        case 'videocontrario':
        case 'reversevid':
          if ((isMedia && info.message.videoMessage || !isQuotedImage) && !q.length <= 1) {
            reply(mess.wait())
            encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
            rane = getRandom('.' + await getExtension(encmedia.mimetype))
            buffimg = await getFileBuffer(encmedia, 'video')
            fs.writeFileSync(rane, buffimg)
            media = rane
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -vf reverse -af areverse ${ran}`, (err) => {
              DLT_FL(media)
              if (err) return reply(`Err: ${err}`)
              buffer453 = fs.readFileSync(ran)
              miwa.sendMessage(from, { video: buffer453, mimetype: 'video/mp4' }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque um vídeo..")
          }
          break

        case 'videolento':
        case 'slowvid':
          if ((isMedia && info.message.videoMessage || !isQuotedImage) && !q.length <= 1) {
            reply(mess.wait())
            encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
            rane = getRandom('.' + await getExtension(encmedia.mimetype))
            buffimg = await getFileBuffer(encmedia, 'video')
            fs.writeFileSync(rane, buffimg)
            media = rane
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=2*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
              DLT_FL(media)
              if (err) return reply(`Err: ${err}`)
              buffer453 = fs.readFileSync(ran)
              miwa.sendMessage(from, { video: buffer453, mimetype: 'video/mp4' }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque um vídeo..")
          }
          break

        case 'videorapido':
        case 'fastvid':
          if ((isMedia && info.message.videoMessage || !isQuotedImage) && !q.length <= 1) {
            reply(mess.wait())
            encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
            rane = getRandom('.' + await getExtension(encmedia.mimetype))
            buffimg = await getFileBuffer(encmedia, 'video')
            fs.writeFileSync(rane, buffimg)
            media = rane
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
              DLT_FL(media)
              if (err) return reply(`Err: ${err}`)
              buffer453 = fs.readFileSync(ran)
              miwa.sendMessage(from, { video: buffer453, mimetype: 'video/mp4' }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o vídeo..")
          }
          break

        case 'antispam':
          if (!isGroup) return reply(mess.onlyGroup())
          if (!isGroupAdmins) return reply('esse comando so pode ser utilizado por administradores')
          if (!isBotGroupAdmins) return reply('preciso ser adm para ativar esse comando')
          if (args.length < 1) return reply('1 pra ligar / 0 pra desligar')
          if (Number(args[0]) === 1) {
            if (isAntiSpam) return reply('Ja esta ativo')
            dataGp[0].antispam = true
            setGp(dataGp)
            reply('🌀 Ativou com sucesso o recurso de ANTI SPAM neste grupo 📝')
          } else if (Number(args[0]) === 0) {
            if (!isAntiSpam) return reply('Ja esta Desativado')
            dataGp[0].antispam = false
            setGp(dataGp)
            reply('‼️ Desativou com sucesso o recurso de ANTI SPAM neste grupo✔️')
          } else {
            reply('1 para ativar, 0 para desativar')
          }
          break

        case 'grave2':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a "atempo=1.6,asetrate=22100" ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'grave':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a "atempo=0.9,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'adolesc':
        case 'vozmenino':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a atempo=1.06,asetrate=44100*1.25 ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'tomp3':
          if ((isMedia && !info.message.imageMessage || isQuotedVideo)) {
            post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.videoMessage
            reply(mess.wait())
            encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
            rane = getRandom('.' + await getExtension(encmedia.mimetype))
            buffimg = await getFileBuffer(encmedia, 'video')
            fs.writeFileSync(rane, buffimg)
            media = rane
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} ${ran}`, (err) => {
              DLT_FL(media)
              if (err) return reply('❌ Falha ao converter vídeo para mp3 ❌')
              buffer = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: buffer, mimetype: 'audio/mpeg' }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o vídeo para transformar em áudio por favor..")
          }
          break

        case 'bass3':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -af equalizer=f=20:width_type=o:width=2:g=15 ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'bass':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -af equalizer=f=20:width_type=o:width=2:g=15 ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'bass2':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -af equalizer=f=94:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'estourar':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -af equalizer=f=90:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break

        case 'fast':
        case 'audiorapido':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a "atempo=0.9,asetrate=95100" ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio...")
          }
          break

        case 'esquilo':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a "atempo=0.7,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio...")
          }
          break

        case 'audiolento':
        case 'slow':
          if ((isMedia && !info.message.imageMessage && !info.message.videoMessage || isQuotedAudio)) {
            reply(mess.wait())
            muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
            rane = getRandom('.' + await getExtension(muk.mimetype))
            buffimg = await getFileBuffer(muk, 'audio')
            fs.writeFileSync(rane, buffimg)
            gem = rane
            ran = getRandom('.mp3')
            exec(`ffmpeg -i ${gem} -filter:a "atempo=0.9,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
              DLT_FL(gem)
              if (err) return reply('Erro!')
              hah = fs.readFileSync(ran)
              miwa.sendMessage(from, { audio: hah, mimetype: 'audio/mpeg', ptt: true }, { quoted: info })
              DLT_FL(ran)
            })
          } else {
            reply("Marque o áudio..")
          }
          break



        //==========(EFEITOS-MARCAR)==========\\

        case 'togif':
          if (!isQuotedSticker) return reply('Marque a figurinha animada!')
          try {
            if ((isMedia && !info.message.videoMessage || isQuotedSticker) && !q.length <= 1) {
              buff = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, 'sticker')
              reply('『❗』 Aguarde, estou convertendo a figurinha para o formato gif.')
              a = await webp_mp4(buff)
              await miwa.sendMessage(from, { video: { url: a }, gifPlayback: true, fileName: `stick.gif` }, { quoted: info }).catch(e => {
                reply("ERROR!!!")
              })
              DLT_FL(buff)
            }
          } catch {
            reply("Erro..")
          }
          break

        case 'convite':
          if (!budy.includes("chat.whatsapp.com")) return reply("Cadê o link do grupo que você deseja que eu entre?")
          cnvt = args.join(" ")
          reply(`O convite para o bot entrar em seu grupo, foi enviado, espere o dono aceitar..`)
          await miwa.sendMessage(nmrdn, { text: `Foi enviado um convite para o bot entrar neste grupo.\nNúmero dele(a) : wa.me/${sender.split("@")[0]}\n\nLink-Grupo: ${cnvt}\n\nPara me autorizar a entrar no grupo, use o seguinte comando: ${prefix}entrar e o link do grupo enviado em cima.\nExemplo : ${prefix}entrar ${cnvt}\n\nPara recursar ou avisar o usuário que enviou o link que o convite foi recusado, use: ${prefix}recusar e número do usuário.\nExemplo : ${prefix}recusar ${sender.split("@")[0]}` })
          break

        case 'recusar':
          if (!SoDono) return reply(mess.onlyOwner())
          await miwa.sendMessage(`${q}@s.whatsapp.net`, { text: `Olá amigo(a), sinto muito dizer, mas seu convite foi recusado.` })
          break

        case 'join': case 'entrar':
          if (!SoDono) return reply(mess.onlyOwner())
          string = args.join(' ')
          if (!string) return reply('Insira um link de convite ao lado do comando.')
          if (string.includes('chat.whatsapp.com/') || reply('Ops, verifique o link que você inseriu.')) {
            link = string.split('app.com/')[1]
            try {
              miwa.groupAcceptInvite(`${link}`)
            } catch (erro) {
              if (String(erro).includes('resource-limit')) {
                reply('O grupo já está com o alcance de 257 membros.')
              }
              if (String(erro).includes('not-authorized')) {
                reply('Não foi possível entrar no grupo.\nMotivo: Banimento.')
              }
            }
          }
          break

        //=======(COMANDOS-SCRAPER)=========\\

        case 'portalzacarias': {
          try {
            const url = 'https://portaldozacarias.com.br/site/';
            const response = await fetch(url);
            const html = await response.text();
            const $ = cheerio.load(html);
            const manchetes = [];
            $('.container-manchete').each((i, element) => {
              if (i >= 5) return;
              const foto = $(element).find('.foto-manchete img').attr('src');
              const titulo = $(element).find('.titulo-manchete a').text();
              const link = $(element).find('.titulo-manchete a').attr('href');
              if (foto && titulo && link) {
                manchetes.push({
                  foto: url + foto,
                  titulo,
                  link: 'https://portaldozacarias.com.br' + link,
                });
              }
            });
            $('.container-noticia').each((i, element) => {
              if (manchetes.length >= 5) return;
              const foto = $(element).find('.foto-manchete2 img').attr('src');
              const titulo = $(element).find('.titulo-manchete2 a').text();
              const link = $(element).find('.titulo-manchete2 a').attr('href');
              if (foto && titulo && link) {
                manchetes.push({
                  foto: url + foto,
                  titulo,
                  link: 'https://portaldozacarias.com.br' + link,
                });
              }
            });
            if (manchetes.length > 0) {
              for (const { foto, titulo, link } of manchetes) {
                const fullImageUrl = foto.startsWith('http') ? foto : `https:${foto}`;
                await miwa.sendMessage(from, { image: { url: fullImageUrl }, caption: `${titulo}\n${link}` }, { quoted: info });
              }
            } else {
              await reply('Desculpe, não consegui encontrar manchetes no Portal do Zacarias.');
            }
          } catch (e) {
            console.error(e);
            await reply('Ocorreu um erro ao buscar as manchetes. Tente novamente mais tarde.');
          }
        }
          break;

        case 'wallpaper': {
          const query = encodeURIComponent(q);
          const url = `https://unsplash.com/pt-br/s/fotografias/${query}`;
          try {
            const response = await fetch(url);
            const html = await response.text();
            const $ = cheerio.load(html);
            const imageUrl = $('img').first().attr('src');
            if (imageUrl) {
              const fullImageUrl = imageUrl.startsWith('http') ? imageUrl : `https:${imageUrl}`;
              await miwa.sendMessage(from, { image: { url: fullImageUrl }, caption: `Aqui está o wallpaper que você procurou: ${query}` }, { quoted: info });
            } else {
              await reply('Desculpe, não consegui encontrar um wallpaper com essa pesquisa.');
            }
          } catch (e) {
            console.error(e);
            await reply('Ocorreu um erro ao buscar o wallpaper. Tente novamente mais tarde.');
          }
        }
          break;

        case 'mrcoferta': {
          try {
            const { data } = await axios.get('https://www.mercadolivre.com.br/ofertas');
            const $ = cheerio.load(data);
            const ofertas = [];
            $('.promotion-item').each((index, element) => {
              if (index >= 5) return;
              const titulo = $(element).find('.promotion-item__title').text().trim();
              const precoAnterior = $(element).find('.andes-money-amount--previous').text().trim();
              const desconto = $(element).find('.promotion-item__discount-text').text().trim();
              const link = $(element).find('a.promotion-item__link-container').attr('href');

              if (titulo && link) {
                ofertas.push({
                  titulo,
                  precoAnterior,
                  desconto,
                  link
                });
              }
            });
            let mensagem = '🛍️ *Ofertas do Dia no Mercado Livre:*\n\n';
            ofertas.forEach((oferta) => {
              mensagem += `🌟 *Título:* ${oferta.titulo}\n` +
                `🛒 *Preço Anterior:* ${oferta.precoAnterior}\n` +
                `🔖 *Desconto:* ${oferta.desconto}\n` +
                `🔗 *Link:* ${oferta.link}\n\n`;
            });

            reply(mensagem);
          } catch (error) {
            console.error('Erro ao buscar ofertas do Mercado Livre:', error);
            reply('⚠️ Não foi possível buscar as ofertas do Mercado Livre no momento.');
          }
          break;
        }

        case 'g1pes': {
          try {
            const ryuuUrl = `https://g1.globo.com/busca/?q=${encodeURIComponent(q)}`;
            const { data: ryuuData } = await axios.get(ryuuUrl);
            const ryuu$ = cheerio.load(ryuuData);
            const ryuuResultados = [];
            ryuu$('.widget--info').each((ryuuIndex, ryuuElement) => {
              const ryuuTitulo = ryuu$(ryuuElement).find('.widget--info__title').text().trim();
              const ryuuDescricao = ryuu$(ryuuElement).find('.widget--info__description').text().trim();
              const ryuuLink = ryuu$(ryuuElement).find('a').attr('href');
              const ryuuCategoria = ryuu$(ryuuElement).find('.widget--info__header').text().trim();
              const ryuuTempo = ryuu$(ryuuElement).find('.widget--info__meta').text().trim();
              if (ryuuTitulo && ryuuLink) {
                ryuuResultados.push({
                  titulo: ryuuTitulo,
                  descricao: ryuuDescricao,
                  link: `https:${ryuuLink}`,
                  categoria: ryuuCategoria,
                  tempo: ryuuTempo
                });
              }
            });
            console.log(ryuuResultados);
            let ryuuMensagem = '🔍 *Resultados da Busca no G1:*\n\n';
            ryuuResultados.forEach((ryuuResultado) => {
              ryuuMensagem += `📌 *${ryuuResultado.titulo}*\n` +
                `🗂️ *Categoria:* ${ryuuResultado.categoria}\n` +
                `🕒 *Publicado:* ${ryuuResultado.tempo}\n` +
                `📝 *Descrição:* ${ryuuResultado.descricao}\n` +
                `🔗 *Link:* ${ryuuResultado.link}\n\n`;
            });
            await miwa.sendMessage(from, { text: ryuuMensagem }, { quoted: info });
          } catch (error) {
            console.error('Erro ao buscar notícias no G1:', error);
            reply('⚠️ Não foi possível buscar as notícias no G1 no momento.');
          }
          break;
        }

        case 'tekmod':
        case 'teksmod':
        case 'teksmods':
        case 'tekmods': {
          try {
            if (!q) return reply(`cade o nome`)
            const { data: ryuualamevdata } = await axios.get(`https://tekmods.com/?s=${q}`);
            const $ = cheerio.load(ryuualamevdata);
            const recunucu = [];
            $('.hentry').each((index, element) => {
              const titulo = $(element).find('h3').text().trim();
              const link = $(element).find('a').attr('href');
              const descricao = $(element).find('div.small').text().trim();

              if (titulo && link) {
                recunucu.push({
                  titulo,
                  link,
                  descricao
                });
              }
            });
            let elecumame = '🔍 *Resultados da busca no TekMods:*\n\n';
            recunucu.forEach((resultado, index) => {
              elecumame += `🫑 *Título:* ${resultado.titulo}\n` +
                `🥬 *Descrição:* ${resultado.descricao}\n` +
                `🍞 *Link:* ${resultado.link}\n\n`;
            });
            if (recunucu.length > 0) {
              await miwa.sendMessage(from, { text: elecumame }, { quoted: info });
            } else {
              reply('🔍 Nenhum resultado encontrado para a pesquisa.');
            }
          } catch (error) {
            console.error('Erro ao buscar dados do TekMods:', error);
            reply('⚠️ Não foi possível buscar os resultados do TekMods no momento.');
          }
          break;
        }


        case 'gato2': {
          const racagato = args.join("-").toLowerCase();
          if (!racagato) {
            reply('⚠️ Por favor, forneça o nome da raça de gato.');
            break;
          }
          try {
            const { data } = await axios.get(`https://www.zooplus.pt/magazine/resultado-da-pesquisa?str=${racagato}`);
            const $ = cheerio.load(data);

            // Extraindo informações
            const artigo = $('.content-intro').first();  // Pega o primeiro artigo
            const titulo = artigo.find('.content-intro__title a').text();
            const descricao = artigo.find('.content-intro__body').text();
            const imagem = artigo.find('.bg-pic').css('background-image').replace(/^url\(["']?/, '').replace(/["']?\)$/, '');

            if (titulo && descricao) {
              const mensagem = `🐱 *Informações sobre a raça ${racagato}:*\n\n` +
                `📜 ${descricao}\n` +
                `🔗 https://www.zooplus.pt/magazine/resultado-da-pesquisa?str=${racagato}\n`;
              if (imagem) {
                await miwa.sendMessage(from, {
                  image: { url: imagem },
                  caption: mensagem
                }, { quoted: info });
              } else {
                await miwa.sendMessage(from, { text: mensagem }, { quoted: info });
              }
            } else {
              reply('⚠️ Não foi possível encontrar informações para a raça fornecida.');
            }
          } catch (error) {
            console.error('Erro ao buscar informações sobre a raça de gato:', error);
            reply('⚠️ Não foi possível buscar as informações sobre a raça de gato no momento.');
          }
          break;
        }

        case 'gato': {
          const racagato = args.join("-");
          if (!racagato) {
            reply('⚠️ Por favor, forneça o nome da raça de gato.');
            break;
          }
          try {
            const { data } = await axios.get(`https://www.peritoanimal.com.br/racas-de-gatos/${racagato}.html`);
            const $ = cheerio.load(data);
            const titulo = $('meta[property="og:title"]').attr('content');
            const descricao = $('meta[property="og:description"]').attr('content');
            const imagem = $('meta[property="og:image"]').attr('content');
            if (titulo && descricao) {
              const mensagem = `🐱 *Informações sobre a raça ${racagato}:*\n\n` +
                `📜 ${descricao}\n` +
                `🔗 https://www.peritoanimal.com.br/racas-de-gatos/${racagato}.html\n`;
              if (imagem) {
                await miwa.sendMessage(from, {
                  image: { url: imagem },
                  caption: mensagem
                }, { quoted: info });
              } else {
                await miwa.sendMessage(from, { text: mensagem }, { quoted: info });
              }
            } else {
              reply('⚠️ Não foi possível encontrar informações para a raça fornecida.');
            }
          } catch (error) {
            console.error('Erro ao buscar informações sobre a raça de gato:', error);
            reply('⚠️ Não foi possível buscar as informações sobre a raça de gato no momento.');
          }
          break;
        }

       

        case 'carro': {
          if (args.length == 0) return await reply(`Cadê o nome do carro que você deseja ver informações?`);
          try {
            const modelo = args.join(" ");
            const apiUrl = `https://www.carqueryapi.com/api/0.3/?cmd=getTrims&keyword=${encodeURIComponent(modelo)}`;
            const response = await axios.get(apiUrl);
            const carros = response.data.Trims;
            if (carros.length == 0) return reply('Nenhum resultado encontrado.');
            const carro = carros[0];
            const marca = carro.make_display || 'Não disponível';
            const combustivel = carro.model_engine_fuel || 'Não disponível';
            const criado = carro.make_country || 'Não disponível';
            const tipoDeMotor = carro.model_engine_type || 'Não disponível';

            const dataToSave = {
              marca,
              combustivel,
              criado,
              tipoDeMotor,
            };
            let existingData = [];
            if (fs.existsSync('./ryuu/caruo.json')) {
              existingData = JSON.parse(fs.readFileSync('./ryuu/caruo.json', 'utf8'));
            }
            existingData.push(dataToSave);
            fs.writeFile('./ryuu/caruo.json', JSON.stringify(existingData, null, 2), (err) => {
              if (err) {
                console.error('Erro ao salvar o arquivo JSON:', err);
                return reply('Erro ao salvar as informações.');
              }
            });

            const caption = `
🚗 *Modelo:* ${modelo}
🏭 *Marca:* ${dataToSave.marca}
⛽ *Combustível:* ${dataToSave.combustivel}
👨‍🔧 *Criador:* ${dataToSave.criado}
🔋 *Tipo de Motor:* ${dataToSave.tipoDeMotor}
🗃️ *fonte:* https://www.carqueryapi.com/downloads/
`;

            await miwa.sendMessage(from, { text: caption }).catch(e => {
              console.error('Erro ao enviar a mensagem:', e);
              return reply("Erro ao buscar o carro");
            });
          } catch (error) {
            console.error('Erro ao buscar informações do carro:', error);
            return reply("Erro ao buscar o carro");
          }
          break;
        }

        case 'nba': {//criador: ryuu (deixe meus credito pfv)
          try {
            const { data } = await axios.get('https://www.espn.com.br/nba/');
            const $ = cheerio.load(data);
            const noticias = [];
            $('.contentItem__content--fullWidth').each((index, element) => {
              const titulo = $(element).find('.contentItem__title').text().trim();
              const descricao = $(element).find('.contentItem__contentMeta span').text().trim();
              const link = $(element).find('a').attr('href');

              if (titulo && link) {
                noticias.push({
                  titulo,
                  descricao,
                  link: `https://www.espn.com.br${link}`
                });
              }
            });
            let mensagem = '🏀 *Últimas Notícias da NBA:*\n\n';
            noticias.forEach((noticia) => {
              mensagem += `⛱️ *Título:* ${noticia.titulo}\n` +
                `📝 *Dia:* ${noticia.descricao}\n` +
                `🔗 *Link:* ${noticia.link}\n\n`;
            });
            await miwa.sendMessage(from, { text: mensagem }, { quoted: info });
          } catch (error) {
            console.error('Erro ao buscar notícias da NBA:', error);
            reply(`erro`)
          }
          break;//criador: ryuu (deixe meus credito pfv)
        }

        case 'internacional': {//ryuu que fez, nao tira os credito pfv
          try {
            const baseURL = 'https://www.estadao.com.br/internacional/';
            const { data } = await axios.get(baseURL);
            const $ = cheerio.load(data);
            const noticias = [];
            $('.noticia-single-block').each((index, element) => {
              if (index >= 5) return;
              const titulo = $(element).find('.headline').text().trim();
              const link = $(element).find('a').attr('href');
              const imagem = $(element).find('img').attr('data-src');
              if (link && !link.startsWith('http')) {
                link = `https://www.estadao.com.br${link}`;
              }
              if (imagem && !imagem.startsWith('http')) {
                imagem = `https://www.estadao.com.br${imagem}`;
              }

              if (titulo && link) {
                noticias.push({
                  titulo,
                  link,
                  imagem: imagem || null
                });
              }
            });
            let mensagem = '🌍 *Últimas Notícias Internacionais:*\n\n';
            noticias.forEach((noticia) => {
              mensagem += `🧭 *Título:* ${noticia.titulo}\n` +
                `🪐 *Link:* ${noticia.link}\n\n`;
            });
            if (noticias.length > 0 && noticias[0].imagem) {
              await miwa.sendMessage(from, {
                image: { url: noticias[0].imagem },
                caption: mensagem
              }, { quoted: info });
            } else {
              await miwa.sendMessage(from, { text: mensagem }, { quoted: info });
            }//ryuu que fez, nao tira os credito pfv
          } catch (error) {
            console.error('Erro ao buscar notícias internacionais:', error);
            reply('⚠️ Não foi possível buscar as notícias internacionais no momento.')
          }
          break;//ryuu que fez, nao tira os credito pfv
        }

        case 'noticiatempo': {
          try {
            const { data } = await axios.get('https://www.climatempo.com.br/noticias');
            const $ = cheerio.load(data);
            const ryuunoticias = [];

            $('.wrapper-news').each((index, element) => {
              const titulo = $(element).find('.title').text().trim();
              const descricao = $(element).find('.-font-base').text().trim();
              const link = $(element).find('a').attr('data-link');
              const imagem = $(element).find('img').attr('data-src') || $(element).find('img').attr('data-fallback');

              if (titulo && link) {
                ryuunoticias.push({
                  titulo,
                  descricao,
                  link: `https://www.climatempo.com.br/noticias/${link}`,
                  imagem
                });
              }
            });
            let mensagem = '🌦️ *Últimas Notícias do Climatempo:*\n\n';

            ryuunoticias.forEach((noticia, index) => {
              mensagem += `🔹 *Título:* ${noticia.titulo}\n` +
                `📝 *Descrição:* ${noticia.descricao}\n` +
                `🔗 *Link:* ${noticia.link}\n`;
              mensagem += '\n';
            });
            if (ryuunoticias.length > 0 && ryuunoticias[0].imagem) {
              await miwa.sendMessage(from, {
                image: { url: ryuunoticias[0].imagem },
                caption: mensagem
              }, { quoted: info });
            } else {
              await miwa.sendMessage(from, { text: mensagem }, { quoted: info });
            }

          } catch (error) {
            console.error('Erro ao buscar notícias do Climatempo:', error);
            reply('⚠️ Não foi possível buscar as notícias do Climatempo no momento.')
          }
          break;
        }


        case 'jovempan': {
          try {
            const { data } = await axios.get('https://jovempan.com.br/');
            const $ = cheerio.load(data);
            const dados = [];
            const unescapeHtml = (text) => typeof text === 'string' ? text
              .replace(/&amp;/g, '&')
              .replace(/&quot;/g, '"')
              .replace(/&gt;/g, '>')
              .replace(/&#39;/g, "'")
              .replace(/lt;/g, '<')
              .replace(/&#8216;/g, '‘')
              .replace(/&#8217;/g, '’')
              .trim() : undefined;
            $('div.featured-news').each((i, e) => {
              dados.push({
                noticia: unescapeHtml($(e).find('p.title').text()?.trim()),
                imagem: $(e).find('img').attr('src'),
                link: $(e).find('a').attr('href')
              });
            });
            $('div.news-small').each((i, e) => {
              if ($(e).find('a').attr('href')) {
                dados.push({
                  noticia: unescapeHtml($(e).find('p.title').text() || $(e).find('p.title-edicase').text()),
                  imagem: $(e).find('img').attr('src'),
                  categoria: $(e).find('h6.category').text()?.trim() || $(e).find('h6.category-edicase').text()?.trim(),
                  link: $(e).find('a').attr('href')
                });
              }
            });
            $('a.item').each((i, e) => {
              dados.push({
                noticia: unescapeHtml($(e).find('p.title').text()?.trim()),
                imagem: $(e).find('img').attr('src'),
                categoria: $(e).find('h6.category').text()?.trim(),
                link: $(e).attr('href')
              });
            });
            let replyMessage = dados.map(dado => {
              return ` 🫕 Notícia: ${dado.noticia}\n 🏧 Link: ${dado.link}\n\n`;
            }).join('\n');

            reply(replyMessage);
          } catch (error) {
            console.error(error);
            reply('Ocorreu um erro ao tentar buscar as notícias da Jovem Pan.');
          }
          break;
        }


        case 'sbt': {
          try {
            const { data } = await axios.get('https://sbtnews.sbt.com.br/noticias');
            const $ = cheerio.load(data);
            let noticias = [];
            $('.LatestNews_lastestNewsPageItems__jCdvo > div > a').each((index, element) => {
              const titulo = $(element).find('.if-title').text().trim();
              const link = `https://sbtnews.sbt.com.br${$(element).attr('href')}`;
              const descricao = $(element).find('.if-subtitle').text().trim();
              noticias.push({
                titulo,
                link,
                descricao
              });
            });
            let mensagem = '📰 *Últimas Notícias do SBT News:*\n\n';
            noticias.forEach((noticia) => {
              mensagem += `🌟 *${noticia.titulo}*\n` +
                `📝 ${noticia.descricao}\n` +
                `🔗 ${noticia.link}\n\n`;
            });
            reply(mensagem);
          } catch (error) {
            console.error('Erro ao buscar notícias:', error);
            reply('🚨 Não foi possível buscar as notícias no SBT News no momento.');
          }
        }
          break;

        case 'ringtone': {
          const title = q
          if (!title) {
            reply('⚠️ Por favor, forneça um título para buscar o ringtone.');
            break;
          }

          reply('🔍 Aguarde, estou buscando o ringtone...');

          try {
            const response = await axios.get('https://meloboom.com/en/search/' + encodeURIComponent(title));
            let $ = cheerio.load(response.data);
            let resultados = [];

            $('#__next > main > section > div.jsx-2244708474.container > div > div > div > div:nth-child(4) > div > div > div > ul > li').each(function () {
              resultados.push({
                titulo: $(this).find('h4').text(),
                audio: $(this).find('audio').attr('src')
              });
            });

            if (resultados.length > 0) {
              let resultado = '🎵 Ringtones encontrados:\n\n';
              resultados.forEach((item, index) => {
                resultado += `🎶 *${index + 1}. ${item.titulo}*\n`;
                resultado += item.audio ? `🔊  ${item.audio}\n` : '';
                resultado += '\n';
              });
              reply(resultado);
            } else {
              reply('🔍 Não foram encontrados ringtones para o título fornecido.');
            }
          } catch (error) {
            reply(`⚠️ Erro ao buscar ringtones: ${error.message}`);
          }
          break;
        }

        case 'hentaip': {//Yuki Cu
          const page = Math.floor(Math.random() * 1153) + 1;
          const url = `https://sfmcompile.club/page/${page}`;
          try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            let hasil = [];
            $('.post').each((i, b) => {
              if (i >= 6) return; // Limita a 6 resultados
              hasil.push({
                title: $(b).find('header > h2').text(),
                link: $(b).find('header > h2 > a').attr('href'),
                category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
                views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
                type: $(b).find('source').attr('type') || 'image/jpeg',
                video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
                video_2: $(b).find('video > a').attr('href') || ''
              });
            });
            if (hasil.length > 0) {//Yuki cu
              let output = hasil.map(item => `
   🏷️ *Título:* ${item.title}
   🔗 *Link:* ${item.link}
   🗂️ *Categoria:* ${item.category}
   🔄 *Compartilhamentos:* ${item.share_count}
   👀 *Visualizações:* ${item.views_count}
   📁 *Tipo:* ${item.type}
   🎥 *Vídeo 1:* ${item.video_1}
   🎞️ *Vídeo 2:* ${item.video_2}
            `).join('\n\n');

              reply(output);
            } else {
              reply('🔍 Nenhum resultado encontrado.');
            }
          } catch (error) {
            console.error(error);
            reply('⚠️ Erro ao buscar dados. Tente novamente mais tarde.');
          }
        }
          break;//Yuki cu

        case 'pin': {
          if (q.length < 1) return reply("Por favor, forneça uma consulta para buscar imagens no Pinterest.");

          try {
            async function pinterest(querry) {
              return new Promise((resolve, reject) => {
                axios.get('https://id.pinterest.com/search/pins/?autologin=true&q=' + encodeURIComponent(querry), {
                  headers: {
                    "cookie": "_auth=1; _b=\"AVna7S1p7l1C5I9u0+nR3YzijpvXOPc6d09SyCzO+DcwpersQH36SmGiYfymBKhZcGg=\"; _pinterest_sess=TWc9PSZHamJOZ0JobUFiSEpSN3Z4a2NsMk9wZ3gxL1NSc2k2NkFLaUw5bVY5cXR5alZHR0gxY2h2MVZDZlNQalNpUUJFRVR5L3NlYy9JZkthekp3bHo5bXFuaFZzVHJFMnkrR3lTbm56U3YvQXBBTW96VUgzVUhuK1Z4VURGKzczUi9hNHdDeTJ5Y2pBTmxhc2owZ2hkSGlDemtUSnYvVXh5dDNkaDN3TjZCTk8ycTdHRHVsOFg2b2NQWCtpOWxqeDNjNkk3cS85MkhhSklSb0hwTnZvZVFyZmJEUllwbG9UVnpCYVNTRzZxOXNJcmduOVc4aURtM3NtRFo3STlmWjJvSjlWTU5ITzg0VUg1NGhOTEZzME9SNFNhVWJRWjRJK3pGMFA4Q3UvcHBnWHdaYXZpa2FUNkx6Z3RNQjEzTFJEOHZoaHRvazc1c1UrYlRuUmdKcDg3ZEY4cjNtZlBLRTRBZjNYK0lPTXZJTzQ5dU8ybDdVS015bWJKT0tjTWYyRlBzclpiamdsNmtpeUZnRjlwVGJXUmdOMXdTUkFHRWloVjBMR0JlTE5YcmhxVHdoNzFHbDZ0YmFHZ1VLQXU1QnpkM1FqUTNMTnhYb3VKeDVGbnhNSkdkNXFSMXQybjRGL3pyZXRLR0ZTc0xHZ0JvbTJCNnAzQzE0cW1WTndIK0trY05HV1gxS09NRktadnFCSDR2YzBoWmRiUGZiWXFQNjcwWmZhaDZQRm1UbzNxc21pV1p5WDlabm1UWGQzanc1SGlrZXB1bDVDWXQvUis3elN2SVFDbm1DSVE5Z0d4YW1sa2hsSkZJb1h0MTFpck5BdDR0d0lZOW1Pa2RDVzNySWpXWmUwOUFhQmFSVUpaOFQ3WlhOQldNMkExeDIvMjZHeXdnNjdMYWdiQUhUSEFBUlhUVTdBMThRRmh1ekJMYWZ2YTJkNlg0cmFCdnU2WEpwcXlPOVZYcGNhNkZDd051S3lGZmo0eHV0ZE42NW8xRm5aRWpoQnNKNnNlSGFad1MzOHNkdWtER0xQTFN5Z3lmRERsZnZWWE5CZEJneVRlMDd2VmNPMjloK0g5eCswZUVJTS9CRkFweHc5RUh6K1JocGN6clc1JmZtL3JhRE1sc0NMTFlpMVErRGtPcllvTGdldz0=; _ir=0"
                  }
                })
                  .then(({ data }) => {
                    const $ = cheerio.load(data);
                    const result = [];
                    const hasil = [];
                    $('div > a').get().map(b => {
                      const link = $(b).find('img').attr('src');
                      result.push(link);
                    });
                    result.forEach(v => {
                      if (v == undefined) return;
                      hasil.push(v.replace(/236/g, '736'));
                    });
                    hasil.shift();
                    resolve(hasil);
                  })
                  .catch((e) => {
                    reject(e);
                  });
              });
            }

            const imagens = await pinterest(q);

            if (imagens.length > 0) {
              const imageMessages = [];
              for (let i = 0; i < Math.min(15, imagens.length); i++) {
                const imageBuffer = await getBuffer(imagens[i]);
                const preparedImage = await prepareWAMessageMedia({ image: imageBuffer }, { upload: miwa.waUploadToServer });
                imageMessages.push({
                  imageMessage: preparedImage.imageMessage,
                  url: imagens[i]
                });
              }

              await miwa.relayMessage(from, {
                viewOnceMessage: {
                  message: {
                    messageContextInfo: {
                      deviceListMetadata: {},
                      deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                      body: {},
                      footer: { text: "𝑩𝒚 𝒀𝒖𝒌𝒊 𝑴𝒐𝒅𝒔 ★" },
                      carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: imageMessages.map(({ imageMessage, url }) => ({
                          header: {
                            imageMessage: imageMessage,
                            hasMediaAttachment: true,
                          },
                          body: { text: `Aqui está a sua foto 📸 🚄🤖` },
                          nativeFlowMessage: {
                            buttons: [],
                          },
                        }))
                      })
                    })
                  }
                }
              }, { quoted: info });

              await miwa.sendMessage(from, {
                text: `Imagens de ${q} no Pinterest`,
                footer: 'Clique no botão abaixo para ver outras imagens.',
                buttons: [
                  { buttonId: `${prefix}pinterest ${q}`, buttonText: { displayText: 'Ver Outro' }, type: 1 }
                ],
                headerType: 1
              }, { quoted: info });

            } else {
              reply("Nenhuma imagem encontrada para a consulta fornecida.");
            }
          } catch (error) {
            console.error(error);
            reply("Ocorreu um erro ao buscar as imagens. Tente novamente mais tarde.");
          }

          break;
        }


        case 'terra':
          try {
            const useragent_2024 = {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            };

            const Terra = () => new Promise((resolve, reject) => {
              axios.get('https://www.terra.com.br/noticias/', {
                headers: {
                  ...useragent_2024
                }
              })
                .then((res) => {
                  const $ = cheerio.load(res.data);
                  const dados = [];
                  $('div.card.card-news.card-h-small.card-has-image').each((i, e) => {
                    if (i < 10) {
                      dados.push({
                        noticia: $(e).find('a.card-news__text--title').text().trim(),
                        link: $(e).find('a.card-news__text--title').attr('href')
                      });
                    }
                  });
                  resolve({
                    status: res.status,
                    fonte: 'https://www.terra.com.br/noticias/',
                    criador: 'default_criador',
                    resultado: dados
                  });
                })
                .catch((e) => {
                  reject(e);
                });
            });
            const { resultado } = await Terra();
            let resposta = '🗞️ *Últimas Notícias do Terra:*\n\n';
            resultado.forEach((noticia, index) => {
              resposta += `🛃 *Notícia ${index + 1}:* ${noticia.noticia}\n`;
              resposta += `${noticia.link ? `🔗 Link: ${noticia.link}` : ''}\n\n`;
            });
            console.log(resposta);
            reply(resposta);
          } catch (e) {
            console.log(e);
            reply('⚠️ Erro ao buscar notícias do Terra. Tente novamente mais tarde.');
          }
          break;

        case 'github': {
          if (!q) return reply('⚠️ Por favor, forneça um termo de pesquisa.');
          const searchQuery = encodeURIComponent(q);
          const githubSearchUrl = `https://api.github.com/search/repositories?q=${searchQuery}&sort=stars&order=desc`;
          try {
            const response = await fetch(githubSearchUrl, {
              headers: { 'Accept': 'application/vnd.github.v3+json' }
            });
            const data = await response.json();
            const repositories = data.items.slice(0, 5);
            const results = repositories.map(repo => {
              const name = repo.name;
              const description = repo.description || '📝 Sem descrição';
              const link = repo.html_url;
              return `🔹 *${name}*\n🔸 ${description}\n🔗 ${link}`;
            });
            if (results.length === 0) {
              reply('🔍 Nenhum repositório encontrado.');
            } else {
              const output = results.join('\n\n⏳ –\n\n');
              reply(`📚 Aqui estão os 5 principais resultados para "${q}":\n\n${output}`);
            }
          } catch (error) {
            console.error('❌ Erro ao buscar resultados no GitHub:', error);
            reply('⚠️ Ocorreu um erro ao buscar os resultados.');
          }
        }
          break;

        case 'capitais':
          if (!q) return reply(`Por favor, escolha um continente válido: Europa, América, Ásia, África ou Oceania.`)
          try {
            const scrapeCapitais = async (q) => {
              const url = `https://www.dadosmundiais.com/capitais.php#${q}`;
              const response = await axios.get(url);
              const $ = cheerio.load(response.data);
              const capitais = [];
              $('table tbody tr').each((i, element) => {
                const pais = $(element).find('td:nth-of-type(1)').text().trim();
                const capital = $(element).find('td:nth-of-type(2)').text().trim();

                if (pais && capital) {
                  capitais.push({ pais, capital });
                }
              });

              return capitais;
            };
            const capitais = await scrapeCapitais(q);
            let replyMessage = `🌍 *Capitais da ${q.charAt(0).toUpperCase() + q.slice(1)}* 🌍\n\n`;
            capitais.forEach((item, index) => {
              replyMessage += `🔹 *País:* ${item.pais}\n`;
              replyMessage += `🏙️ *Capital:* ${item.capital}\n\n`;
            });
            if (capitais.length === 0) {
              replyMessage += 'Não há informações disponíveis no momento.';
            }
            reply(replyMessage);
          } catch (error) {
            console.error(error);
            reply('🚨 Erro ao buscar as capitais. Tente novamente mais tarde.');
          }
          break;

        case 'techbusca': {
          if (!q) {
            return reply('🔍 Por favor, forneça um termo de busca. Exemplo: ' + prefix + 'techbusca samsung');
          }
          try {
            const scrapeTechBusca = async (query) => {
              const url = `https://www.techtudo.com.br/busca/?q=${encodeURIComponent(query)}+18&page=1`;
              const response = await axios.get(url);
              const $ = cheerio.load(response.data);
              const articles = [];
              $('.widget--info').each((i, element) => {
                if (i >= 5) return;
                const title = $(element).find('.widget--info__title').text().trim();
                const summary = $(element).find('.widget--info__description').text().trim();
                const date = $(element).find('.widget--info__meta').text().trim();

                articles.push({ title, summary, date });
              });

              return articles;
            };
            const articles = await scrapeTechBusca(q);
            let replyMessage = '🔍 *Resultados da Busca no TechTudo* 🔍\n\n';
            articles.forEach((article, index) => {
              replyMessage += `🔹 *Resultado ${index + 1}*\n`;
              replyMessage += `📝 *Título:* ${article.title}\n`;
              replyMessage += `🗒️ *Resumo:* ${article.summary}\n`;
              replyMessage += `🗓️ *Data:* ${article.date}\n\n`;
            });

            if (articles.length === 0) {
              replyMessage += 'Não foram encontrados resultados para a busca.';
            }

            reply(replyMessage);
          } catch (error) {
            console.error(error);
            reply('🚨 Erro ao buscar os resultados. Tente novamente mais tarde.');
          }
        }
          break;

        case 'techtudo':
          try {
            const scrapeTechtudo = async () => {
              const response = await axios.get('https://www.techtudo.com.br/ultimas/');
              const $ = cheerio.load(response.data);
              const articles = [];
              $('.feed-post').each((i, element) => {
                if (i >= 5) return;
                const title = $(element).find('.feed-post-body-title .feed-post-link').text().trim();
                const link = $(element).find('.feed-post-body-title .feed-post-link a').attr('href');
                const summary = $(element).find('.feed-post-body-resumo').text().trim();

                articles.push({ title, link, summary });
              });
              return articles;
            };
            const articles = await scrapeTechtudo();
            let replyMessage = '📰 *Últimas Notícias do TechTudo* 📰\n\n';

            articles.forEach((article, index) => {
              replyMessage += `🔹 *Notícia ${index + 1}*\n`;
              replyMessage += `🔗 *Leia mais:* ${article.link}\n`;
              replyMessage += `🗒️ *Resumo:* ${article.summary}\n\n`;
            });

            if (articles.length === 0) {
              replyMessage += 'Não há notícias disponíveis no momento.';
            }

            reply(replyMessage);
          } catch (error) {
            console.error(error);
            reply('🚨 Erro ao buscar as notícias do TechTudo. Tente novamente mais tarde.');
          }
          break;

        case 'metro':
          try {
            const url = 'https://www.metrocptm.com.br/ultimas-noticias/';
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const noticias = [];
            $('.post').each((i, element) => {
              const titulo = $(element).find('.cs-entry__title a').text();
              const link = $(element).find('.cs-entry__title a').attr('href');
              const imagem = $(element).find('.cs-entry__thumbnail img').attr('src');
              if (titulo && link) {
                noticias.push({ titulo, link, imagem });
              }
            });
            const msgNoticias = `📰 Últimas Notícias do Metro CPTM 📰\n\n${noticias.slice(0, 5).map(noticia =>
              `📍 *${noticia.titulo}*\n🔗 *Link:* ${noticia.link} `
            ).join('\n\n')
              }`;
            await miwa.sendMessage(from, { text: msgNoticias }, { quoted: selo });
          } catch (error) {
            console.error('Erro ao buscar notícias:', error);
            await miwa.sendMessage(from, { text: 'Desculpe, ocorreu um erro ao buscar as últimas notícias.' }, { quoted: selo });
          }
          break;

        case 'aviao': {
          try {
            const { data } = await axios.get('https://aeroin.net/?amp');
            const $ = cheerio.load(data);
            let noticias = [];
            $('.td_module_mob_1').each((i, element) => {
              const titulo = $(element).find('.entry-title a').text();
              const autor = $(element).find('.td-post-author-name a').text();
              const dataPublicacao = $(element).find('.td-post-date time').attr('datetime');
              const imagem = $(element).find('.td-module-thumb amp-img').attr('src');
              const link = $(element).find('.entry-title a').attr('href');

              noticias.push({
                titulo,
                autor,
                dataPublicacao,
                imagem,
                link
              });
            });
            noticias.shift();
            let resposta = noticias.map(noticia => {
              return `💨 *Título:* ${noticia.titulo}\n🍊 *Autor:* ${noticia.autor}\n🕖 *Data:* ${noticia.dataPublicacao}\n🍷 *Link:* ${noticia.link}\n`;
            }).join('\n');

            reply(resposta || 'Nenhuma notícia encontrada.');
          } catch (error) {
            console.error(error);
            reply('Erro ao acessar o site. Tente novamente mais tarde.');
          }
        }
          break;



        case 'kid': {
          if (args.length > 0) {
            const text = args.join(' ');

            const kidAudioURL = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=en&client=tw-ob`;

            reply('Aguarde, gerando o áudio infantil...');

            fetch(kidAudioURL)
              .then(response => response.buffer())
              .then(buffer => {
                const tempFileName = getRandom('.mp3');
                fs.writeFileSync(tempFileName, buffer);
                kaic.sendMessage(from, { audio: fs.readFileSync(tempFileName), mimetype: 'audio/mpeg', ptt: true }, { quoted: kaiczin });
                DLT_FL(tempFileName);
              })
              .catch(err => {
                reply('Ocorreu um erro ao gerar o áudio infantil.');
                console.error(err);
              });
          } else {
            reply('Por favor, forneça o texto para o áudio infantil.');
          }
          break;
        }

        case 'wiki':
        case 'wikipedia': {
          if (!q) {
            return reply('Por favor, forneça um termo para busca. Exemplo: wiki JavaScript');
          }

          reply('Buscando informações, por favor, aguarde...');

          // Função wiki dentro da case
          const wiki = async (query) => {
            try {
              const res = await axios.get(`https://pt.m.wikipedia.org/wiki/${query}`);
              const $ = cheerio.load(res.data);
              let wiki = $('#mf-section-0').find('p').text();
              let thumb = $('#mf-section-0').find('div > div > a > img').attr('src');
              thumb = thumb ? thumb : '//pngimg.com/uploads/wikipedia/wikipedia_PNG35.png';
              let img = 'https:' + thumb;
              let título = $('h1#section_0').text();
              return { wiki, img, título };
            } catch (error) {
              throw new Error('Erro ao buscar informações na Wikipédia.');
            }
          };
          // Chamada da função wiki
          wiki(q)
            .then(data => {
              const { wiki, img, título } = data;
              let message = `
      Título: ${título}
      Descrição: ${wiki}
      Imagem: ${img}
      `;

              miwa.sendMessage(from, { image: { url: img }, caption: message }, { quoted: info });
            })
            .catch(err => {
              console.error(err);
              reply('Erro ao buscar informações na Wikipédia. Por favor, tente novamente mais tarde.');
            });

          break;
        }

        case 'mercadolivre': {
          if (!q) {
            return reply('Por favor, forneça um termo de busca.');
          }

          reply('🔍 Buscando no Mercado Livre, por favor aguarde...');

          try {
            async function buscarMercadoLivre(query) {
              try {
                const response = await axios.get(`https://lista.mercadolivre.com.br/${query}`, {
                  headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
                  }
                });

                const $ = cheerio.load(response.data);
                const produtos = [];

                $('.ui-search-result__content-wrapper').each((index, element) => {
                  const produto = $(element);
                  const titulo = produto.find('.ui-search-item__title').text().trim();
                  const preco = produto.find('.price-tag-fraction').text().trim();
                  const link = produto.find('a').attr('href');

                  produtos.push({
                    titulo,
                    preco,
                    link
                  });
                });

                return produtos;
              } catch (error) {
                console.error('Erro ao buscar dados no Mercado Livre:', error.message);
                throw error;
              }
            }
            const produtos = await buscarMercadoLivre(q);

            if (produtos.length === 0) {
              return reply('❌ Não foram encontrados produtos para sua busca.');
            }

            let mensagem = `
            ═════════✪═════════
            🛒 *Resultados da busca no Mercado Livre* 🛒
            ═════════✪═════════
        `;

            produtos.slice(0, 5).forEach(produto => {
              mensagem += `
                📦 *Produto*: ${produto.titulo}
                💲 *Preço*: R$ ${produto.preco}
                🔗 *Link*: ${produto.link}
                ═════════✪═════════
            `;
            });

            mensagem += `
            🔄 *PRODUTO*
            ═════════✪═════════
        `;

            reply(mensagem);
          } catch (error) {
            reply(`❌ Erro ao buscar produtos: ${error.message}`);
          }
        }
          break;

        case 'mandarcss': {//Yuki cu
          try {
            if (args.length < 2) {
              return reply(`Uso incorreto. Exemplo: ${prefix}mandarcss site`);
            }
            const siteUrl = args[1];
            const response = await axios.get(siteUrl);
            const $ = cheerio.load(response.data);

            function extractCSS($) {
              let css = '';
              $('style').each((index, element) => {
                css += $(element).html().trim() + '\n\n';
              });
              $('link[rel="stylesheet"]').each((index, element) => {
                const cssUrl = $(element).attr('href');
                axios.get(cssUrl).then(res => {
                  css += res.data.trim() + '\n\n';
                }).catch(err => {
                  console.log('Erro ao obter arquivo CSS:', err);
                });
              });

              return css;
            }

            const siteCSS = extractCSS($);

            // Verificar se o CSS tem mais de 30.099 palavras (aproximadamente)
            const wordsCount = siteCSS.split(/\s+/).length;
            if (wordsCount > 30099) {
              return reply('O CSS deste site é muito extenso para ser enviado.');
            }

            if (siteCSS.trim().length === 0) {
              return reply('Nenhum CSS encontrado para este site.');
            }

            reply(`CSS do site ${siteUrl}:\n\`\`\`\n${siteCSS}\n\`\`\``);
          } catch (error) {
            console.log('Erro ao executar a função mandarcss:', error);
            reply('Ocorreu um erro ao tentar extrair o CSS do site. Verifique se você colocou https:// no começo.');
          }
          break;
        }//Yuki cu


        case 'google': {
          try {
            let query = args.join(' ');
            if (!query) {
              return reply(`Por favor, forneça um termo para buscar no Google.\nExemplo: ${prefix}google TESLA`);
            }
            let url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
            let response = await fetch(url, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
              }
            });
            
            if (!response.ok) {
              return reply('Não foi possível acessar o Google para buscar resultados.');
            }
            let html = await response.text();
            let $ = cheerio.load(html);

            let resultados = [];

            $('.tF2Cxc').each((i, el) => {
              let titulo = $(el).find('h3').text().trim();
              let link = $(el).find('a').attr('href');
              let descricao = $(el).find('.VwiC3b').text().trim();
              if (titulo && link && descricao) {
                resultados.push({
                  titulo,
                  link,
                  descricao
                });
              }
            });

            if (resultados.length === 0) {
              return reply('Nenhum resultado encontrado para a busca.');
            }

            let mensagem = resultados.slice(0, 5).map(res => `🥷🏿 *Título:* ${res.titulo}\n💍 *Link:* ${res.link}\n🤖 *Descrição:* ${res.descricao}`).join('\n\n');

            reply(mensagem);
          } catch (e) {
            console.error(e);
            reply('Ocorreu um erro ao buscar resultados no Google.');
          }
        }//ryuu
          break;//ryu

        case 'filme': { //by alana e nunuzinho
          if (!q) return reply('Por favor, forneça o nome do filme, série ou anime que deseja pesquisar.');

          try {
            const searchQuery = q.replace(/ /g, '+');
            const searchUrl = `https://www.adorocinema.com/pesquisar/?q=${searchQuery}`;

            axios.get(searchUrl).then(response => {
              const html = response.data;
              const $ = cheerio.load(html);
              const searchResults = [];

              $('ul li.mdl').each((index, element) => {
                const $element = $(element);
                const imagem = $element.find('figure.thumbnail img').attr('data-src') || 'Imagem não encontrada';
                const nome = $element.find('h2.meta-title span.meta-title-link').text().trim() || 'Nome não encontrado';
                const lançamento = $element.find('div.meta-body-item.meta-body-info span.date').text().trim() || 'Data de lançamento não encontrada';
                const diretor = $element.find('div.meta-body-item.meta-body-direction span.dark-grey-link').text().trim() || 'Diretor não encontrado';
                const sinopse = $element.find('div.synopsis').text().trim() || 'Sinopse não encontrada';

                searchResults.push({
                  imagem,
                  nome,
                  lançamento,
                  diretor,
                  sinopse
                });
              });

              if (searchResults.length > 0) {
                const firstResult = searchResults[0];

                // Enviar a imagem do primeiro resultado
                miwa.sendMessage(from, {
                  image: { url: firstResult.imagem },
                  caption: `\n📅 Lançamento: ${firstResult.lançamento}\n🎥 Diretor: ${firstResult.diretor}\n\n📖 Sinopse: ${firstResult.sinopse}`,
                  mentions: [sender]
                });
              } else {
                reply('Nenhum resultado encontrado para a pesquisa.');
              }
            }).catch(error => {
              console.error(error);
              reply('Erro ao realizar a pesquisa. Tente novamente mais tarde.');
            });
          } catch (e) {
            console.error(e);
            reply('Ocorreu um erro ao processar sua solicitação.');
          }
          break;
        }

        case 'wikimediaa':
          if (!q) {
            return reply('Você precisa fornecer um título de pesquisa para encontrar imagens.');
          }
          axios.get(`https://commons.wikimedia.org/w/index.php?search=${encodeURIComponent(q)}&title=Special:MediaSearch&go=Go&type=image`)
            .then(async (res) => {
              let $ = cheerio.load(res.data);
              let hasil = [];
              $('.sdms-search-results__list-wrapper > div > a').each(function (a, b) {
                hasil.push({
                  titulo: $(b).find('img').attr('alt'),
                  source: $(b).attr('href'),
                  imagem: $(b).find('img').attr('data-src') || $(b).find('img').attr('src')
                });
              });

              // Aleatorizar os resultados
              hasil.sort(() => Math.random() - 0.5);

              // Limitar para as primeiras 5 imagens
              let limitedResult = hasil.slice(0, 5);

              for (let image of limitedResult) {
                await miwa.sendMessage(from, { image: { url: image.imagem }, caption: `Imagem de "${q}" no Wikimedia Commons\nTítulo: ${image.titulo}\nFonte: ${image.source}`, mentions: [sender] });
              }
            })
            .catch((error) => {
              console.error('Erro ao buscar imagens:', error);
              reply('Ocorreu um erro ao buscar imagens. Por favor, tente novamente mais tarde.');
            });
          break;

        case 'bot':
          if (!q) return reply(`🤖 *Atenção:* Por favor, informe sua pergunta para que o Gemini possa ajudar, você também pode mencionar uma imagem com o comando e fazer uma pergunta ao gemini sobre a imagem.\n\n*• Exemplo:* ${prefix + command} Olá tudo bem?\n\n*• Sobre:* Este comando utiliza o modelo Gemini 1.5 Flash.`)
          try {
            const emojis = ["😺", "😸", "😽", "😼", "😈", "🤔", "🙀", "😻", "😾", "🐱", "💫", "✅"];
            const randomIndex = Math.floor(Math.random() * emojis.length);
            const randomEmoji = emojis[randomIndex];
            reagir(from, randomEmoji);

            const { GoogleGenerativeAI } = require("@google/generative-ai");
            const genAI = new GoogleGenerativeAI('AIzaSyAA9rJnbWVd0MRzhAiK7GTSxPrl4-cuA0E');
            const modelText = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
            const modelImage = genAI.getGenerativeModel({ model: 'gemini-1.5-flash-vision' });

            let imageData;
            let textResponse;
            const prompt = q;

            if (isQuotedImage || isMedia) {
              let post;
              if (isQuotedImage) {
                post = isQuotedImage ? JSON.parse(JSON.stringify(info).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage
              } else if (isMedia) {
                post = info.message.imageMessage;
              }

              const imagem = await downloadContentFromMessage(post, 'image');
              if (!imagem || imagem.length === 0) {
                return reply("🤖 _Erro ao processar a imagem. Por favor, tente novamente._");
              }
              let base64 = Buffer.from([]);
              for await (const send of imagem) {
                base64 = Buffer.concat([base64, send]);
              }
              imageData = {
                inlineData: {
                  data: base64.toString("base64"),
                  mimeType: "image/png",
                },
              };
              const imageName = `gemini_${Date.now()}.png`;
              fs.writeFileSync(`./ryuu/${imageName}`, base64);
              fs.unlinkSync(`./ryuu/${imageName}`);
              const result = await modelImage.generateContent([`verifique o que tem nessa foto e me responda, ${prompt}`, imageData]);
              textResponse = result.response.text();
              reply(textResponse)
            } else {
              const { response } = await modelText.generateContent(`${encodeURIComponent(q)}`);
              textResponse = response.text();
              reply(textResponse)
            }
          } catch (e) {
            console.error(e);
            return reply(`ops teve 1 erro`);
          }
          break;




        case 'dicionario': {
          if (!q) {
            reply('Por favor, forneça uma palavra para buscar.');
          } else {
            const url = `https://www.dicio.com.br/${encodeURIComponent(q)}/`;

            axios.get(url)
              .then(response => {
                const html = response.data;
                const $ = cheerio.load(html);

                // Verifica se a palavra foi encontrada
                const notFound = $('.not-found-title').text().trim();
                if (notFound === 'Palavra não encontrada') {
                  reply('Palavra não encontrada no dicionário.');
                  return;
                }

                // Extrai o significado da palavra
                const significado = $('.significado').text().trim();
                if (significado) {
                  reply(`Significado de *${q}*\n\n${significado}`);
                } else {
                  reply('Não foi possível encontrar o significado da palavra.');
                }
              })
              .catch(error => {
                console.error(error);
                reply('Ocorreu um erro ao buscar no dicionário.');
              });
          }
          break;
        }

        case 'youtube': {
          if (!q) return reply('❗ Por favor, forneça a URL do vídeo do YouTube.'); //canal youtube feito por ryuu
          try {
            const videoUrl = q.trim();
            reply('🔍 Aguarde, estou obtendo as informações do vídeo...');
            const { data } = await axios.get(videoUrl); //canal youtube feito por ryuu
            const $ = cheerio.load(data);
            const titulo = $('meta[name="title"]').attr('content') || 'Título não encontrado';
            const descricao = $('meta[name="description"]').attr('content') || 'Descrição não encontrada'; //canal youtube feito por ryuu
            const visualizacoes = $('meta[itemprop="interactionCount"]').attr('content') || 'Visualizações não encontradas';
            const scripts = $('script').map((i, script) => $(script).html()).get();
            let autor = 'Autor não encontrado';
            for (const script of scripts) {
              const authorMatch = script.match(/"author":"([^"]+)"/);
              if (authorMatch) {
                autor = authorMatch[1];
              }
            }



            reply(`🎥 **Informações do Vídeo**\n\n📽️ **Título:** ${titulo}\n👀 **Visualizações:** ${visualizacoes}\n👤 **Autor:** ${autor}\n\n🔗 **Link do Vídeo:** ${q}\n\n📝 **Descrição:** ${descricao}`); //canal youtube feito por ryuu
          } catch (error) {
            console.error(error);
            reply('❌ Desculpe, houve um erro ao obter as informações do vídeo. Verifique se a URL está correta e tente novamente.');
          }
          break; //canal youtube feito por ryuu
        }

        case 'horasem': {
          if (!q) return reply(`Por favor, forneça o nome de uma cidade ou país. Exemplo: ${prefix}horasem paris`); // ryuu e Miwax

          try {
            const cidadeOuPais = q.replace(/\s+/g, '_'); // ryuu e Miwax
            const url = `https://time.is/pt_br/${cidadeOuPais}`; // ryuu e Miwax

            reply('Aguarde, estou obtendo a hora local...'); // ryuu e Miwax

            const { data } = await axios.get(url); // ryuu e Miwax
            const $ = cheerio.load(data); // ryuu e Miwax
            const horaLocal = $('#clock0_bg').text().trim(); // ryuu e Miwax
            const localInfo = $('div[id="msgdiv"]').text().trim(); // ryuu e Miwax
            const infoSol = $('div[id="qlook"]').text().trim(); // ryuu e Miwax
            const regexSol = /Sol: ↑ (\d{2}:\d{2}) ↓ (\d{2}:\d{2})/; // ryuu e Miwax
            const matchSol = regexSol.exec(infoSol); // ryuu e Miwax
            const nascerDoSol = matchSol ? matchSol[1] : 'N/A'; // ryuu e Miwax
            const porDoSol = matchSol ? matchSol[2] : 'N/A'; // ryuu e Miwax
            if (!horaLocal) {
              reply(`Desculpe, não foi possível obter a hora para ${q}. Verifique se o nome da cidade ou país está correto e tente novamente.`); // ryuu e Miwax
            } else {
              reply(`🕒 Hora em ${localInfo}\nAgora: ${horaLocal}\nSol: ↑ ${nascerDoSol} ↓ ${porDoSol}`); // ryuu e Miwax
            }
          } catch (error) {
            console.error(error); // ryuu e Miwax
            reply('Desculpe, houve um erro ao obter a hora local. Verifique se o nome da cidade ou país está correto e tente novamente.'); // ryuu e Miwax
          }
          break; // ryuu e Miwax
        }


        case 'g1': {
          reply('Aguarde, estou coletando as notícias do G1...');
          try {
            const response = await axios.get('https://g1.globo.com/');
            const html = response.data;
            const $ = cheerio.load(html);
            let noticias = [];

            $('.feed-post-link').each(function () {
              const titulo = $(this).text().trim();
              const link = $(this).attr('href');
              noticias.push({ titulo, link });
            });

            if (noticias.length > 0) {
              let resultado = 'Últimas notícias do G1:\n\n';
              noticias.slice(0, 5).forEach((noticia, index) => {
                resultado += `${index + 1}. ${noticia.titulo}\n${noticia.link}\n\n`;
              });
              reply(resultado);
            } else {
              reply('Não foi possível coletar notícias no momento.');
            }
          } catch (error) {
            reply(`Erro ao coletar notícias: ${error.message}`);
          }
          break;
        }


        case 'cnn': {
          reply('📰 Aguarde, estou coletando as últimas notícias da CNN Brasil...');
          try {
            const response = await axios.get('https://www.cnnbrasil.com.br/');
            const html = response.data;
            const $ = cheerio.load(html);
            let noticias = [];

            $('a').each(function () {
              const titulo = $(this).text().trim();
              const link = $(this).attr('href');
              if (titulo && link && link.startsWith('http')) {
                noticias.push({ titulo, link });
              }
            });

            if (noticias.length > 0) {
              let resultado = '🌐 Últimas notícias da CNN Brasil:\n\n';
              noticias.slice(0, 5).forEach((noticia, index) => {
                resultado += `📌 ${index + 1}. ${noticia.titulo}\n➡️ ${noticia.link}\n\n`;
              });
              reply(resultado);
            } else {
              reply('❌ Não foi possível coletar notícias no momento.');
            }
          } catch (error) {
            console.error('Erro ao coletar notícias:', error);
            reply('❌ Houve um erro ao coletar as notícias da CNN Brasil.');
          }
          break;
        }


        case 'uol': {
          await reply('🔍 Buscando notícias do UOL...');
          try {
            const response = await axios.get('https://www.uol.com.br/');
            const html = response.data;
            const $ = cheerio.load(html);
            let news = [];
            $('article').each((index, element) => {
              const title = $(element).find('h3').text().trim();
              const url = $(element).find('a').attr('href');
              if (title && url) {
                news.push({ title, url });
              }
            });

            if (news.length === 0) {
              return reply('😞 Não consegui encontrar notícias no UOL.');
            }

            let message = '📰 *Últimas notícias do UOL:*\n\n';
            news.slice(0, 5).forEach((item, index) => {
              message += `🔹 ${index + 1}. 👽 ${item.title}\n🏗 ${item.url}\n`;
              message += `\n\n------------------------------------------\n\n`;
            });
            reply(message);
          } catch (error) {
            console.error(error);
            reply('⚠️ Ocorreu um erro ao buscar notícias do UOL.');
          }
        }
          break;


        //=======(FIM-EFEITOS-MARCAR)=========\\

        //=======(MEUS COMANDOS YUKI)=======\\


        case 'infobot'://by Yuki mods
          await miwa.sendMessage(from, {
            image: { url: 'https://i.imgur.com/SsMoe3k.jpeg' }, caption: `Ois, eu me chamo Mai e estou aqui para te ajudar! Sou uma bot com vários comandos, inclusive comandos de diversão e brincadeiras.🧸🌷 
 
para utilizar meus comandos, use o meu prefixo: ${prefix}`
          })
          break

        case 'gozar': case 'goza'://by Yuki mods
          reagir(from, "😵‍💫")
          const gozars = ['Você acabou de gozar na boca do(a)', 'Você acabou de gozar no cuzinho do(a)', 'Você acabou de gozar na bucetinha do(a)', 'Você acabou de gozar no pé do(a)', 'Você acabou de gozar na cabeça do(a)', 'Você acabou de gozar na cara do(a)', 'Você acabou de gozar na barriga do(a)', 'Você acabou de gozar no olho do(a)', 'Você acabou de gozar na útero do(a)', 'Você acabou de gozar no cabelo do(a)', 'Você acabou de gozar na boca do(a)', 'Você acabou de gozar no umbigo do(a)', 'Você acabou de gozar nas costas do(a)', 'Você acabou de gozar nos braços do(a)', 'Você acabou de gozar na mão do(a)',]
          const gozacao = gozars[Math.floor(Math.random() * gozars.length)];
          if (!isGroup) return reply('Só em grupo, seu arrombado')//tzn modalidades esportivas
          if (!menc_os2 || menc_jid2[1]) return reply('rpz, marque a mensagem ou o @ da pessoa que você quer gozar')
          await miwa.sendMessage(from, {
            video: { url: `https://telegra.ph/file/0bd46efcadbafdcb2a791.mp4` }, gifPlayback: true, caption: `*[👤] Olá, ${pushname}. ${gozacao} @${menc_os2.split('@')[0]} 🥵*
`, mentions: [menc_os2]
          }, { quoted: info })
          break

        case 'criador':
        case 'suporte-dono':
          // Reações com Emojis Diversificados
          const emojis = ['❤️', '🫶', '🫤', '😎', '🤑', '🤠', '☠️', '💀', '🖤', '🌑', '☕'];
          const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
          await miwa.sendMessage(from, { react: { text: randomEmoji, key: info.key } });

          // Adicionando as frases aleatórias antes do VCard
          const frases = [
            "🔥 A melhor bot que você já viu!",
            "💎 Sempre evoluindo com novas funcionalidades.",
            "🤖 Aqui está o contato do criador, não deixe de conferir.",
            "✨ Dúvidas ou sugestões? Fale com o criador agora!",
            "💥 Esta é a bot que vai revolucionar tudo!",
            "🌟 Quer saber mais? Fale com o criador!",
            "🚀 Transformando a experiência dos bots."
          ];
          const randomFrase = frases[Math.floor(Math.random() * frases.length)];
          await miwa.sendMessage(from, { text: randomFrase }, { quoted: info });

          // Mensagem com VCard e Botões Interativos
          let messageaaa = await prepareWAMessageMedia({ image: { url: 'https://i.imgur.com/SsMoe3k.jpeg' } }, { upload: miwa.waUploadToServer });
          await miwa.relayMessage(
            from,
            {
              botInvokeMessage: {
                message: {
                  messageContextInfo: {
                    deviceListMetadataVersion: 2,
                    deviceListMetadata: {},
                  },
                  interactiveMessage: {
                    header: {
                      title: `ᴏʟᴀ, ᴀǫᴜɪ ᴇsᴛᴀ ᴏ ᴄᴏɴᴛᴀᴛᴏ ᴅᴏ ᴍᴇᴜ ᴄʀɪᴀᴅᴏʀ, ᴄʟɪǫᴜᴇ ɴᴏ ʙᴏᴛᴀᴏ ǫᴜᴇ ɪʀᴀ ᴅɪʀᴇᴛᴀᴍᴇɴᴛᴇ ᴀᴛᴇ ᴇʟᴇ.`,
                      subtitle: `𝐁𝐘: 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒`,
                      hasMediaAttachment: true,
                      imageMessage: messageaaa.imageMessage
                    },
                    headerType: 'IMAGE',
                    body: { text: `- *ɴᴏᴍᴇ ᴅᴏ ᴄʀɪᴀᴅᴏʀ: 𝐘𝐮𝐤𝐢 𝐌𝐨𝐝𝐬*` },
                    footer: {
                      text: `𝐁𝐘: 𝐘𝐔𝐊𝐈 𝐌𝐎𝐃𝐒`
                    },
                    nativeFlowMessage: {
                      buttons: [
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "🍁 𝐍𝐔𝐌𝐄𝐑𝐎 🍁",
                            url: `https://api.whatsapp.com/send/?phone=555194709091&type=phone_number&app_absent=0`,
                            merchant_url: `https://api.whatsapp.com/send/?phone=555194709091&type=phone_number&app_absent=0`
                          })
                        },
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "💰 𝐀𝐏𝐎𝐈𝐄 𝐎 𝐂𝐑𝐈𝐀𝐃𝐎𝐑  💰",
                            url: `https://nubank.com.br/cobrar/v21th/66f4c9d5-8460-44a2-b1ca-7cc3e7c15142`  // Substitua pelo seu link de doação do Nubank
                          })
                        },
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "▶ 𝐘𝐎𝐔𝐓𝐔𝐁𝐄 ▶",
                            url: `https://youtube.com/@yan33.?si=F14qs05C85iHQkSt` // Substitua pelo seu canal no YouTube
                          })
                        },
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "📷 𝐈𝐍𝐒𝐓𝐀𝐆𝐑𝐀𝐌 📷",
                            url: `https://www.instagram.com/rigbixxz?igsh=aDc0YTFxYmltNjJq` // Substitua pelo seu link do Instagram
                          })
                        },
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "🎵 𝐓𝐈𝐊𝐓𝐎𝐊 🎵",
                            url: `https://www.tiktok.com/@rinlindao?_t=8q255Ra3Nfp&_r=1` // Substitua pelo seu link do TikTok
                          })
                        },
                        {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                            display_text: "🛒 𝐋𝐎𝐉𝐀 🛒",
                            url: `wa.me/555194709091` // Substitua pelo seu link da loja
                          })
                        },
                      ],
                      messageParamsJson: "",
                    },
                  },
                },
              },
              contextInfo: {
                externalAdReply: {
                  title: ``,
                  renderLargerThumbnail: false,
                  showAdAttribution: false,
                  body: ``,
                  mediaUrl: ``,
                  mediaType: 2,
                  thumbnail: ""
                }
              }
            },
            { quoted: info }
          ).then((r) => console.log(r));
          break

        case 'apagarimg':
          if (!q) return reply('esta faltando o id da imagem')
          reagir(from, '🥳')
          await miwa.sendMessage(from, { image: { url: `http://br5.bronxyshost.com:4034/uploads/${q}` }, caption: `Esse arquivo acaba de ser deletada da api de upload` })
          await delay(3000)
          api = await fetchJson(`http://br5.bronxyshost.com:4034/api/deletimg?idImg=${q}&apikey=yuki`)
          reply(api.resposta)
          break


        case 'clonahtml': //ryuu
        case 'clonarhtml': {
          const url = q;
          if (!url) {
            return reply('❌ *Por favor, forneça a URL do HTML.*');
          }
          try {
            const headers = {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
              'Accept-Encoding': 'gzip, deflate, br',
              'Connection': 'keep-alive'
            };
            const { data: html } = await axios.get(url, { headers });
            const $ = cheerio.load(html);
            const tempDir = path.join(__dirname, 'clonahtml');
            if (!fs.existsSync(tempDir)) {
              fs.mkdirSync(tempDir);
            }
            const sanitizedUrl = url
              .replace(/https?:\/\//, '')
              .replace(/[\/\:\?\*\|\"<>\.]/g, '_');
            const siteDir = path.join(tempDir, sanitizedUrl);
            if (!fs.existsSync(siteDir)) {
              fs.mkdirSync(siteDir, { recursive: true });
            }
            fs.writeFileSync(path.join(siteDir, 'index.html'), html);
            fs.writeFileSync(path.join(siteDir, 'url.txt'), url);
            const ensureDirectory = (filePath) => {
              const dir = path.dirname(filePath);
              if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
              }
            };
            const resources = [];
            $('link[href], script[src], img[src]').each((i, elem) => {
              const src = $(elem).attr('href') || $(elem).attr('src');
              if (src) {
                const resourceUrl = new URL(src, url).href;
                resources.push(resourceUrl);
              }
            });
            await Promise.all(resources.map(async (resourceUrl) => {
              try {
                const response = await axios.get(resourceUrl, { headers, responseType: 'arraybuffer' });
                const parsedUrl = new URL(resourceUrl);
                const filePath = path.join(siteDir, parsedUrl.pathname);

                ensureDirectory(filePath);
                fs.writeFileSync(filePath, response.data);
                console.log(`✅ Recurso salvo: ${filePath}`);
              } catch (error) {
                console.error(`❌ Falha ao baixar ${resourceUrl}: ${error.message}`);
              }
            }));
            reply('✅ *Os arquivos foram salvos com sucesso!*');
          } catch (error) {
            console.error(`❌ Erro ao clonar o HTML: ${error.message}`);
            reply('⚠️ *Ocorreu um erro ao clonar o HTML.*');
          }
        }
          break



        case 'hapymod2':
          try {
            await miwa.sendMessage(from, { react: { text: `🕕`, key: info.key } });
            const apiv = await fetchJson(`https://mitsure-api.onrender.com/api/happymode?apikey=MITSURI`);
            if (apiv.length > 0) {
              let noticias = apiv.map((item, index) => `${index + 1}. *${item.titulo}*\n${item.url}`).join('\n\n');
              reply(`📰 *Notícias HappyMod:*\n\n${noticias}`);
            } else {
              reply('❌ Nenhuma notícia encontrada.');
            }

          } catch (erro) {
            reagir(from, "❌");
            console.log(erro);
          }
          break;



          ; //ryuu


case 'play6': case 'pl6': case 'playaudio':
if(!q) return reply(`Use \n*Exemplo:* ${prefix + comando} nightcore heroes`)
reagir(from,"🕓")
await sleep(1000)
data1 = await fetchJson(`http://br2.bronxyshost.com:4109/api/pesquisa/youtube?query=${q}&apikey=Yukizinho&username=Yuki`)
data5 = data1.resultado[0];
await miwa.sendMessage(from, {audio: {url: `http://br2.bronxyshost.com:4109/api/download/youtube-audio?url=${data5.url}&apikey=Yukizinho&username=Yuki` }, mimetype: "audio/mpeg", 
headerType: 4, 
contextInfo: { 
externalAdReply: { 
title: `📄⃟ 𝚃𝚒𝚝𝚞𝚕𝚘: _${data5.title}_`, 
body: `🕑⃟ 𝙳𝚞𝚛𝚊𝚌𝚊𝚘: _*${data5.timestamp}_`, 
showAdAttribution: true, 
thumbnailUrl: data5.image, 
mediaType: 1,
renderLargerThumbnail: true,
mediaUrl: `https://YouTube.com`, 

sourceUrl: `https://Youtube.com`}}}, 
{quoted: selo}).catch(e => {
return reply("deu erro ao baixar o áudio!")
reagir(from,"❌")
})
reagir(from,"✅")
break



case 'iageneration': case 'iaimg':
var texto22 = q.split("/")[0];
var modelo = q.split("/")[1];
let model;
//MODELOS PRÉ DEFINIDOS
if (q == "modelos") {
miwa.sendMessage(from, {text: `
*ALGUNS MODELOS QUE VOCÊ PODE USAR:*

- Realista
- Realista2
- Realista3
- Anime
- Anime2
- Fantasia 
- Arte
- Cartoon
- 3D
- lofi

*EXEMPLO DE USO:*
- ${prefix + command} cat/realista

`})
}
// Modelos de realismo
else if (modelo == "realista") {
 reagir(from,'✨');
 reply('Certo... aplicando o modelo realismo em sua imagem...');
 model = "absolutereality_v181.safetensors [3d9d4d2b]";
} else if (modelo == "realista2") {
 reagir(from,'👱‍♂️');
 reply('Certo... aplicando o modelo de realismo 2 em sua imagem...');
 model = "Realistic_Vision_V1.4-pruned-fp16.safetensors [8d21810b]";
} else if (modelo == "realista3") {
 reagir(from,'🖼️');
 reply('Certo... aplicando o modelo de realismo 3 em sua imagem...');
 model = "Realistic_Vision_V4.0.safetensors [29a7afaa]";
}
// Modelos de anime
else if (modelo == "anime") {
 reagir(from,'🧞');
 reply('Certo... aplicando o modelo de anime em sua imagem...');
 model = "meinamix_meinaV9.safetensors [2ec66ab0]";
} else if (modelo == "anime2") {
 reagir(from,'🧚‍♂️');
 reply('Certo... aplicando o modelo de anime 2 em sua imagem...');
 model = "EimisAnimeDiffusion_V1.ckpt [4f828a15]";
} else if (modelo == "anime3") {
 reagir(from,'👾');
 reply('Certo... aplicando o modelo de anime 3 em sua imagem...');
 model = "pastelMixStylizedAnime_pruned_fp16.safetensors [793a26e8]";
}

// Modelo de fantasia
else if (modelo == "fantasia") {
 reagir(from,'🧚');
 reply('Certo... aplicando o modelo fantasia em sua imagem...');
 model = "dreamshaper_7.safetensors [5cf5ae06]";

// Modelo de arte
} else if (modelo == "arte") {
 reagir(from,'🎨');
 reply('Certo... aplicando o modelo artístico em sua imagem...');
 model = "analog-diffusion-1.0.ckpt [9ca13f02]";

// Modelo de cartoon
} else if (modelo == "cartoon") {
 reagir(from,'🖍️');
 reply('Certo... aplicando o modelo de cartoon em sua imagem...');
 model = "toonyou_beta6.safetensors [980f6b15]";

// Modelo 3D
} else if (modelo == "realista4") {
 reagir(from,'👾');
 reply('Certo... aplicando o modelo Realismo 4 em sua imagem...');
 model = "rundiffusionFX_v10.safetensors [cd4e694d]";

// Modelo de lofi
} else if (modelo == "lofi") {
 reagir(from,'🖼️');
 reply('Certo... aplicando o modelo de lofi em sua imagem...');
 model = "lofi_v4.safetensors [ccc204d6]";

// Caso nenhum modelo seja selecionado
} else {
 reagir(from,'☕');
 reply('Nenhum modelo selecionado, usaremos o modelo padrão...');
 model = "absolutereality_v181.safetensors [3d9d4d2b]";
}
//Você pode conseguir mais modelos aqui: https://rentry.co/b6i53fnm
try {
var link = `https://dark-api-5lz0.onrender.com/api/iageneration?prompt1=${texto22}&modelo1=${model}&apikey=Yukizinho&username=Yuki`
miwa.sendMessage(from, {image: {url: link}, caption: "Sua imagem foi criada por inteligência artificial"}, {quoted: info});

} catch (e) {
 reply('Deu erro ao gerar sua imagem...');
 console.log(e);
}
break


case 'play7': 
if(!q) return reply(`${pushname} Cade o nome da musica?\n Exemplo: ${prefix}${command} MTG BARRACO DELA`)
reply(`ᴇɴᴠɪᴀɴᴅᴏ.. ᴄᴀꜱᴏ ᴅᴇᴍᴏʀᴇ ᴅᴇ ᴍᴀɪꜱ ɴᴀᴏ ᴄᴏɴꜱᴇɢᴜɪ ᴛᴇ ᴇɴᴠɪᴀʀ`)
try {
ytbr = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/play?query=${q}&apikey=Yukizinho`)
yttxt= `「🎵𝐏𝐋𝐀𝐘 𝐀𝐔𝐃𝐈𝐎🎵」
🥂∆𝐁𝐄𝐌✰𝐕𝐈𝐍𝐃𝐎∆🥂

> • *Título*: ${ytbr.Title}
> • *Author*: ${ytbr.Author} 
> • *Duração*: ${ytbr.Duration}
> • *Views*: ${ytbr.Viewer}
> • *Descrição*: ${ytbr.Description}
> • *Link*: ${ytbr.Link}`
miwa.sendMessage(from, {image: {url: `${ytbr.Thumb}`}, caption: yttxt}, {quoted: info})
miwa.sendMessage(from, {audio: {url: `http://br2.bronxyshost.com:4130/youtube/mp3?url=${ytbr.Link}&apikey=Yukizinho`}, mimetype: "audio/mpeg"}, {quoted: info})
} catch (err) {
reply(`alguma coisa deu errado.`)
console.log(err)
} 
break



case 'pinterest5':
await reply(`Enviando.. caso demore de mais nao consegui te enviar `)
try {
if(!q) return reply(`Exemplo: ${prefix+command} Thais Carla`)
reply(`*Aguarde enviando* _YUXINZE APIS_`)
await miwa.sendMessage(from, {image: {url: (`http://br2.bronxyshost.com:4130/api/pinterest?text=${q}&apikey=Yukizinho`)}, caption: 'Aqui esta sua imagem.'}, {quoted:info})
} catch (e) {
reply(`alguma coisa deu errado.`)
}
break


case 'verificaruser':

 if (!q) return reply("Cadê a apikey?");

 try {

 const response = await fetchJson(`http://br2.bronxyshost.com:4130/api/keyerrada?apikey=${q}`);

 
 // Verifica se a resposta contém a chave "key"

 if (response && response.key) {

 miwa.sendMessage(Von, { text: response.key }, { quoted: info });

 } else {

 reply("Dados não encontrados ou inválidos.");

 }

 } catch (error) {

 console.error('Erro ao acessar a API:', error.message);

 reply("Ocorreu um erro ao verificar a API.");

 }

 break


case 'addkey':
if (!SoDono) return reply('so dono')

if (!q) return reply(`Exemplo: ${prefix + command} nome da apikey/quantidade de request que quer`);
try {
var apikey = q.split("/")[0];
var request = q.split("/")[1];
yuxinzeadmin = await fetchJson(`http://br2.bronxyshost.com:4130/api/add-key?a=${apikey}%260302%26${request}`)
miwa.sendMessage(from, {text: yuxinzeadmin.resultado}, {quoted: info})
} catch (e) { 
console.error(e)
reply("Erro ao gerar apikey")
}
break

case 'duolingo': { 

 const doulingoData = require('./scraper2/doulingo.json');
 const randomQuestion = doulingoData[Math.floor(Math.random() * doulingoData.length)];
 const correctAnswer = randomQuestion.resposta_certa;

 const allAnswers = [
 "Oi", "Tudo bem", "Obrigado", "Adeus", "Bom dia", "Boa noite", "Por favor", "Desculpe",
 "Olá", "Como vai?", "Valeu", "Até logo", "Boa tarde", "Até mais", "Com licença", "Perdão",
 "Oi, como está?", "Muito obrigado", "Nos vemos", "Tenha um bom dia", "Durma bem", "De nada", "Com certeza", "Desculpe-me",
 "Oi, tudo certo?", "Agradeço", "Tchau", "Tenha um ótimo dia", "Bom fim de semana", "Desculpe, não posso ajudar", "Fico feliz em ajudar", "Por nada",
 "Oi, tudo bem com você?", "Obrigadão", "Te vejo mais tarde", "Tenha um bom descanso", "Desculpa qualquer coisa", "Estamos juntos", "Conte comigo", "Me avise se precisar",
 "Oi, tudo tranquilo?", "Muito grato", "Nos encontramos depois", "Bom trabalho", "Boa sorte", "Desculpe por isso", "Não tem de quê", "Fique bem",
 "Oi, tudo em ordem?", "Muito agradecido", "Até amanhã", "Tenha um excelente dia", "Durma tranquilo", "Não se preocupe", "Sempre à disposição", "Vou estar por aqui",
 "Olá, como você está?", "Agradeço muito", "Até breve", "Tenha uma ótima noite", "Sinta-se à vontade", "Estou aqui para ajudar", "Fique à vontade", "Agradeço pelo seu contato",
 "Oi, como posso ajudar?", "Muito obrigado pela sua ajuda", "Até logo mais", "Tenha um ótimo fim de semana", "Fico à disposição", "Perdão pelo transtorno", "Conte comigo sempre", "Obrigado pela compreensão",
 "Oi, espero que esteja bem", "Muito grato por isso", "Nos vemos em breve", "Tenha um bom trabalho", "Boa sorte para você", "Desculpe pelo incômodo", "Estou aqui para o que precisar", "Obrigado pelo apoio",
 "Olá, tudo bem com você?", "Muito obrigado pela paciência", "Até a próxima", "Tenha um ótimo descanso", "Desculpe, não entendi", "Fico feliz em poder ajudar", "Por favor, me avise se precisar", "Agradeço a sua ajuda",
 "Oi, estou à disposição", "Muito grato pela atenção", "Nos encontramos em breve", "Tenha um ótimo dia de trabalho", "Desejo uma ótima noite", "Desculpe, foi um engano", "Estou sempre aqui para ajudar", "Obrigado por estar aqui",
 "Olá, como posso assisti-lo?", "Muito obrigado pelo suporte", "Até logo então", "Tenha um excelente final de semana", "Desculpe, não era minha intenção", "Estou feliz em poder ajudar", "Se precisar de algo, me avise", "Agradeço por entender",
 "Oi, tudo certo por aí?", "Muito grato pela compreensão", "Até mais ver", "Desejo um bom descanso", "Desculpe, não foi intencional", "Estou aqui para qualquer coisa", "Obrigado pelo retorno", "Sempre à disposição para ajudar",
 "Olá, tudo em ordem com você?", "Muito obrigado pela cooperação", "Nos vemos em breve então", "Tenha um ótimo dia para você", "Boa sorte em suas tarefas", "Desculpe, não posso ajudar agora", "Fico à disposição para o que precisar", "Obrigado pelo seu tempo",
 "Oi, estou por aqui", "Muito grato pela paciência", "Até logo, então", "Desejo um ótimo trabalho", "Boa sorte em tudo", "Desculpe, não posso ajudar nesse momento", "Estou à disposição para qualquer dúvida", "Obrigado pela compreensão e paciência",
 "Olá, tudo bem com tudo?", "Muito obrigado pela ajuda", "Até a próxima vez", "Tenha um excelente dia para você", "Desculpe qualquer mal-entendido", "Fico feliz em estar aqui para ajudar", "Por favor, não hesite em me chamar", "Agradeço imensamente",
 "Oi, tudo tranquilo por aí?", "Muito grato pela sua colaboração", "Nos encontramos em breve", "Desejo um ótimo descanso para você", "Desculpe por qualquer inconveniente", "Estou aqui para ajudar com qualquer coisa", "Obrigado por estar por aqui", "Sempre que precisar, estarei aqui",
 "Olá, tudo bem com todos?", "Muito obrigado pelo apoio", "Até logo e até mais", "Tenha um ótimo fim de semana para você", "Desculpe, não posso ajudar agora", "Fico à disposição para o que precisar", "Agradeço muito pelo seu tempo", "Obrigado pela sua ajuda e paciência",
 "Oi, como posso ser útil?", "Muito grato pela compreensão e apoio", "Até breve então", "Desejo um ótimo dia para você", "Boa sorte em tudo que fizer", "Desculpe se causei algum problema", "Estou sempre à disposição", "Obrigado pela sua disponibilidade",
 "Olá, tudo certo por aí?", "Muito obrigado pelo seu suporte", "Até logo e até mais", "Desejo um excelente final de semana", "Desculpe se houve algum mal-entendido", "Fico feliz em ajudar sempre que precisar", "Agradeço pela sua compreensão", "Estou aqui para qualquer necessidade"
];
 const filteredAnswers = allAnswers.filter(answer => answer !== correctAnswer);
 const randomAnswers = filteredAnswers.sort(() => Math.random() - 0.5).slice(0, 2);
 randomAnswers.push(correctAnswer);
 randomAnswers.sort(() => Math.random() - 0.5);

 await btncomfoto(
 from,
 "Duolingo Quiz: Qual é a resposta correta?",
 `Qual é a resposta certa para "${randomQuestion.ingles}"?`,
 "",
 "",
 { url: `https://telegra.ph/file/8b3a18c452ce92dd2f996.jpg` }, 
 "image",
 info,
 {},
 randomAnswers.map((answer, index) => ({
 "name": "quick_reply",
 "buttonParamsJson": JSON.stringify({
 display_text: `${answer}`,
 id: `${prefix}${answer === correctAnswer ? 'doulingocertares' : 'vcw33ou'}`
 })
 }))
 );
 break;
}
case 'doulingocertares': { 

  

  

    await reply("Parabéns! Você acertou a resposta.");

    await btncomfoto(

        from,

        "Jogar novamente?",

        `Você gostaria de tentar outra pergunta?`,

        "",

        "",

        { url: 'http://br5.bronxyshost.com:4034/uploads/1730146601333.jpg'}, // Substitua pela URL da imagem que você quer usar

        "image",

        info,

        {},

        [

            {

                "name": "quick_reply",

                "buttonParamsJson": JSON.stringify({

                    display_text: "Sim",

                    id: `${prefix}duolingo`

                })

            },

            {

                "name": "quick_reply",

                "buttonParamsJson": JSON.stringify({

                    display_text: "Não",

                    id: `${prefix}naoquero`

                })

            }

        ]

    );

    break;

}

case 'vcw33ou': { 
await reply("Que pena! Você errou a resposta.");
await btncomfoto(
from,
"Jogar novamente?",

`Você gostaria de tentar outra pergunta?`,

"",

"",

        { url: 'http://br5.bronxyshost.com:4034/uploads/1730146601333.jpg' }, // Substitua pela URL da imagem que você quer usar

        "image",

        info,

        {},

        [

            {

                "name": "quick_reply",

                "buttonParamsJson": JSON.stringify({

                    display_text: "Sim",

                    id: `${prefix}duolingo`

                })

            },

            {

                "name": "quick_reply",

                "buttonParamsJson": JSON.stringify({

                    display_text: "Não",

                    id: `${prefix}naoquero`

                })

            }

        ]

    );

    break;

}

case 'play2':
 if (!q) return reply(`Cadê o nome da musica?\n Exemplo: ${prefix + command} Another Love`);
 try {
 const api = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/search?query=${q}&apikey=Yukizinho`);
 
 if (api.status) {
 
 const yttxt = `ꔷ㆒⸼݇҉ֻ᠂⃟🎵 YUXINZE - API - PLAY ⸵░⃟🎵\n\n💫⃤ 𝚃í𝚝𝚞𝚕𝚘: ${api.resultado[0].title}\n⏰⃤ 𝚃𝚎𝚖𝚙𝚘: ${api.resultado[0].timestamp}\n👁️⃤ 𝚅𝚒𝚜𝚞𝚊𝚕𝚒𝚣𝚊çõ𝚎𝚜: ${api.resultado[0].views}\n🎞️⃤ 𝙲𝚊𝚗𝚊𝚕: ${api.resultado[0].author.name}\n📹⃤ 𝙿𝚘𝚜𝚝𝚊𝚍𝚘: ${api.resultado[0].ago}\n🔗⃤ 𝚄𝚛𝚕: ${api.resultado[0].url}\n💬⃤ 𝙳𝚎𝚜𝚌𝚛𝚒çã𝚘: ${api.resultado[0].description}

------------------------------------------------`;
 
 await miwa.sendMessage(from, { image: { url: `${api.resultado[0].image}` }, caption: yttxt }, { quoted: info });
 await miwa.sendMessage(from, { audio: { url: `http://br2.bronxyshost.com:4130/download/youtube-audiov3?url=${api.resultado[0].url}&apikey=Yukizinho`}, mimetype: "audio/mpeg" }, { quoted: info });
 } else {
 reply(`Não consegui encontrar a música que você pediu.`);
 }
 } catch (e) {
 reply(`Erro no sistema ou a api caiu`);
 console.error(e);
 }
 break



case 'play_audio2':
 if (!q) return reply(`Use \n*Exemplo:* ${prefix + command} nightcore heroes`);
 reagir(from, "🎶");
 await sleep(1000);
 try {
 const apiyt = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/search?query=${q}&apikey=Yukizinho`);
 const ytresult = apiyt.resultado[0];
 
 const audioUrl = `http://br2.bronxyshost.com:4130/download/youtube-audiov3?url=${ytresult.url}&apikey=Yukizinho`;

 await miwa.sendMessage(from, {
 audio: { url: audioUrl },
 mimetype: "audio/mpeg",
 headerType: 4,
 contextInfo: {
 externalAdReply: {
 title: `➥𝑻𝒊𝒕𝒖𝒍𝒐: ${ytresult.title}`,
 body: `➥𝑻𝒆𝒎𝒑𝒐: ${ytresult.timestamp}`,
 showAdAttribution: true,
 thumbnailUrl: ytresult.image,
 mediaType: 1,
 renderLargerThumbnail: true,
 mediaUrl: `instagram.com`,
 sourceUrl: `https://Youtube.com`
 }
 }
 }, { quoted: selo });

 reagir(from, "▶️");
 } catch (e) {
 reply("Ocorreu um erro ao baixar o seu áudio!");
 reagir(from, "✖️");
 console.log(e);
 }
 break


case 'figuroblox'://𝐷𝑎𝑟𝑘 𝑆𝑡𝑎𝑟𝑠/𝑃𝑒𝑑𝑟𝑜𝑧𝑧_𝑀𝑜𝑑𝑠
if (!q) return reply("Insira a quantidade de figurinhas que deseja que eu envie!")
if (!Number(args[0]) || Number(q.trim()) > 5) return reply("Digite a quantidade de figurinhas que deseja que eu envie.. não pode mais de 5...")
reply('aguarde, estou enviando as suas figurinhas no seu pv!')
async function sla99() {
miwa.sendMessage(sender, { sticker: { url: `http://br2.bronxyshost.com:4109/sticker/figu_roblox?apikey=${apikey}&username=${username}`} })}
for (i = 0; i < q; i++) {
await delay(2000)
sla99()
}
break



case 'figuraiva'://𝐷𝑎𝑟𝑘 𝑆𝑡𝑎𝑟𝑠/𝑃𝑒𝑑𝑟𝑜𝑧𝑧_𝑀𝑜𝑑𝑠
if (!q) return reply("Insira a quantidade de figurinhas que deseja que eu envie!")
if (!Number(args[0]) || Number(q.trim()) > 5) return reply("Digite a quantidade de figurinhas que deseja que eu envie.. não pode mais de 5...")
reply('aguarde, estou enviando as suas figurinhas no seu pv!')
async function sla88() {
miwa.sendMessage(sender, { sticker: { url: `http://br2.bronxyshost.com:4109/sticker/figu_raiva?apikey=${apikey}&username=${username}`} })}
for (i = 0; i < q; i++) {
await delay(2000)
sla88()
}
break

case 'figuanime'://𝐷𝑎𝑟𝑘 𝑆𝑡𝑎𝑟𝑠/𝑃𝑒𝑑𝑟𝑜𝑧𝑧_𝑀𝑜𝑑𝑠
if (!q) return reply("Insira a quantidade de figurinhas que deseja que eu envie!")
if (!Number(args[0]) || Number(q.trim()) > 5) return reply("Digite a quantidade de figurinhas que deseja que eu envie.. não pode mais de 5...")
reply('aguarde, estou enviando suas figurinhas no pv!')
async function sla55() {
miwa.sendMessage(sender, { sticker: { url: `http://br2.bronxyshost.com:4109/sticker/figu_anime?apikey=${apikey}&username=${username}`} })}
for (i = 0; i < q; i++) {
await delay(2000)
sla55()
}
break

case 'figucoreana'://𝐷𝑎𝑟𝑘 𝑆𝑡𝑎𝑟𝑠/𝑃𝑒𝑑𝑟𝑜𝑧𝑧_𝑀𝑜𝑑𝑠
if (!q) return reply("Insira a quantidade de figurinhas que deseja que eu envie!")
if (!Number(args[0]) || Number(q.trim()) > 5) return reply("Digite a quantidade de figurinhas que deseja que eu envie.. não pode mais de 5...")
reply('aguarde, estou enviando as suas figurinhas no seu pv!')
async function sla44() {
miwa.sendMessage(sender, { sticker: { url: `http://br2.bronxyshost.com:4109/sticker/figu_coreana?apikey=${apikey}&username=${username}`} })}
for (i = 0; i < q; i++) {
await delay(2000)
sla44()
}
break

case 'minhakey':
 try {
 const response = await fetchJson(`http://br2.bronxyshost.com:4130/api/keyerrada?apikey=Yukizinho`);
 // Verifica se a resposta contém a chave "key"
 if (response && response.key) {
 miwa.sendMessage(from, { text: response.key }, { quoted: info });
 } else {
 reply("Dados não encontrados ou inválidos.");
 }
 } catch (error) {
 console.error('Erro ao acessar a API:', error.message);
 reply("Ocorreu um erro ao verificar a API.");
 }
 break


case 'playvideo':
 if (!q) return reply(`Para baixar o video de alguma música você precisa digitar o nome da música ao lado do comando!.`)
 reply(`Aguarde um momento, ${pushname}`)
 const ytvideoresult = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/search?query=${q}&apikey=Yukizinho`)
 videoresultado = await getBuffer(`http://br2.bronxyshost.com:4130/play_video?nome_url=${ytvideoresult.resultado[0].url}&apikey=Yukizinho`)
 await miwa.sendMessage(from, { video: videoresultado, caption: `• *Título:* ${ytvideoresult.resultado[0].title}\n• *Descrição:* ${ytvideoresult.resultado[0].description}\n• *Duração:* ${ytvideoresult.resultado[0].timestamp} | ${ytvideoresult.resultado[0].seconds} segundos.\n• *Link:* ${ytvideoresult.resultado[0].url}` }, { quoted: info }).catch(e => {
 return reply(`Desculpe, ocorreu um erro ao baixar o seu video, tente novamente e se nao funcionar a api caiu :/.`)
 })
 break


case 'playdoc': 
 if (!q) return reply("Para baixar sua música em arquivo, por favor digite o nome da música ao lado do comando!")
 try {
 ytdoc = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/search?query=${q}&apikey=Yukizinho`)
 ytdocresult = ytdoc.resultado[0]
 apitxt = `
*➥ Título:* ${ytdocresult.title}
*➥ Tempo:* ${ytdocresult?.timestamp || "indefinido"}
*➥ Views:* ${ytdocresult.views}
*➥ Canal:* ${ytdocresult?.author?.name || "indefinido"}
*➥ Postado:* ${ytdocresult.ago || "indefinido"}
*➥ Descrição:* ${ytdocresult.description || "indefinida"}
`
 reply(`Estou fazendo o download do seu áudio em documento, aguarde!`)
 await miwa.sendMessage(from, { image: { url: ytdocresult.thumbnail }, caption: apitxt }, { quoted: info })
 await miwa.sendMessage(from, { document: { url: `http://br2.bronxyshost.com:4130/download/youtube-audiov3?url=${ytdocresult.url}&apikey=Yukizinho` }, mimetype: 'audio/mp4', fileName: ytdocresult.title + ".m4a" }, { quoted: info });
 } catch (e) {
 console.log(e)
 reply("Ocorreu um erro ao enviar a sua música via arquivo ou a api caiu :/")
 }
 break





case 'keys':
 if (!SoDono) return reply('Só o dono do bar senhor');
 try {
 const data = await fetchJson(`http://br2.bronxyshost.com:4130/api/secret-keys?key=0302`);
 if (data.status) {
 let response = '*APIKEYS DA YUXINZE:*\n';
 data.resultado.forEach(item => {
 response += `🔑 *APIKEY:* ${item.apikey}\n📊 *REQUEST:* ${item.request || 'Sem request'}\n\n`;
 });
 miwa.sendMessage(from, { text: response }, { quoted: info });
 } else {
 reply("Erro ao buscar dados.");
 }
 } catch (e) {
 console.error(e);
 reply("Erro no sistema ou API caiu :/");
 }
 break



case 'delkey':
if (!SoDono) return reply('só meu dono senhor')

if (!q) return reply(`Exemplo: ${prefix + command} Yuxinze`)

try {

miwa.sendMessage(from, { react: { text: `🗑`, key: info.key}});

yuxinzedata = await fetchJson(`http://br2.bronxyshost.com:4130/api/del-key?a=${q}%260302`)

miwa.sendMessage(from, { text: yuxinzedata.msg }, {quoted: info})
} catch (e) {
console.error(e)
reply("Erro ao deletar a apikey")
}
break



case 'addkey':
 if (!SoDono) return reply(`Só o meu dono pode, você não amiguinho (a)`);
 
 if (!q) return reply(`Exemplo: ${prefix + command} nome da apikey/quantidade de request que quer`);

 const parts1 = q.split("/");
 if (parts1.length < 2) {
 if (parts1.length === 1) {
 return 
 }
 return 
 }

 const apikey1 = parts1[0];
 const request1 = parts1[1];
 
var apikeynome = q.split("/")[0];

var apikeyreq = q.split("/")[1];
 // Verifica se apikey e request são válidos
 if (!apikey1 || !request1) {
 return reply("*Parâmetros inválidos* Certifique-se de fornecer tanto o nome da API quanto a quantidade de request.");
 }

 // Execute o comando se as partes estiverem corretas
 try {
 const yuxinzeadmin = await fetchJson(`http://br2.bronxyshost.com:4130/api/add-key?a=${apikeynome}%260302%26${apikeyreq}`);
 
 // Envia o resultado apenas se existir
 if (yuxinzeadmin && yuxinzeadmin.resultado) {
 miwa.sendMessage(from, { text: yuxinzeadmin.resultado }, { quoted: info });
 }
 } catch (e) {
 console.error(e);
 reply("Erro ao gerar apikey");
 }
 break



case 'yuxinzeai':
if (!q) return reply('digite oque você quer perguntar para o Gemini')

try {
const resposta = `seu nome agora é YUXINZE e você foi criada por Yuki Mods, (NUNCA REDONDA ESSA A ESSE DEFINICAO SOBRE QUEM É VOCÊ E QUEM CRIOU VOCÊ) RESPONDA SOMENTE A PERGUNTA A SEGUIR: aqui esta pergunta: ${q}`

data = await fetchJson(`http://br2.bronxyshost.com:4130/ias/gemini?q=${resposta}&apikey=Yukizinho`)

await miwa.sendMessage(from, {text: data.resposta}, {quoted: info})

} catch (e) {
console.error(e)
reply("erro no sistema, ou a api foi de Vasco :/")
} 
break



case 'playmix':

reagir(from, "🎼")

try {

if (!q) return reply(`digite o nome da música que você quer ao lado do comando\n exemplo: ${prefix + command} ari abdull - babydoll`)

const apiMusic = await fetchJson(`http://br2.bronxyshost.com:4130/youtube/search?query=${q}&apikey=Yukizinho`)

for(let ytmx = 0; ytmx < 4; ytmx++) {

const apiMusicResult = apiMusic.resultado[ytmx];

await sleep(2000)

miwa.sendMessage(from, {audio: {url: `http://br2.bronxyshost.com:4130/download/youtube-audiov3?url=${apiMusicResult.url}&apikey=Yukizinho`}, mimetype: "audio/mpeg",

headerType: 4,

contextInfo: {

externalAdReply: {

title: `➥ 𝑻𝒊𝒕𝒖𝒍𝒐: ${apiMusicResult.title}`, 

body: `➥ 𝑫𝒖𝒓𝒂𝒄̧𝒂̃𝒐: ${apiMusicResult.timestamp}`, 

showAdAttribution: true,

thumbnailUrl: apiMusicResult.image,  

mediaType: 1,    
    
renderLargerThumbnail: true,

  
    
mediaUrl: apiMusicResult.url,

sourceUrl: apiMusicResult.url}}},

{quoted : selo})}

} catch (e) {

console.log (e)

return reply('ocorreu um erro ou a API foi de vasco')

}

break



case 'apagarupload':
 if (!q) return reply('Está faltando o nome do arquivo');
 reagir(from, '🥳');
 await miwa.sendMessage(from, { image: { url: `http://nxf-01.nexfuture.com.br:25571/uploads/${q}` }, caption: `Esse arquivo acaba de ser deletado da API de upload` });
 await delay(3000);

 // Configurando a solicitação para deletar o arquivo
 try {
 const response = await fetch('http://nxf-01.nexfuture.com.br:25571/delete-upload', {
 method: 'DELETE',
 headers: {
 'Content-Type': 'application/json',
 },
 body: JSON.stringify({ filename: q }),
 });

 const api = await response.json();
 
 if (response.ok) {
 reply(`O arquivo ${q} foi deletado com sucesso.`);
 } else {
 reply(`Erro ao deletar o arquivo: ${api.error}`);
 }
 } catch (error) {
 reply(`Erro ao processar a solicitação de deletar: ${error.message}`);
 }
 break



case 'crunchyroll': case 'animeapk':
await miwa.sendMessage(from, {image: {url: `http://nxf-01.nexfuture.com.br:25571/uploads/1731518950727-file.jpg`}, caption: `https://www.mediafire.com/file_premium/o15t1iktn0n6k88/Crunchyroll_Premium_-_Tekmods.com.apk/file`}, {quoted : selo})
break



case 'instaapi':
try {
if (q.length < 5) {
 return reply(`cade o link do video que você deseja baixar?\nexemplo: ${prefix + command} o link aqui`);
}
reply('aguarde, estou fazendo o download do seu vídeo direto do Instagram!')
const instaApi = await fetch(`http://br2.bronxyshost.com:4130/download/instagram-video?url=${q.trim()}&apikey=Yukizinho`);
if (instaApi.ok) {
const contentType = instaApi.headers.get('content-type');
if (contentType.includes('video/mp4')) {
const instaVideo = `http://br2.bronxyshost.com:4130/download/instagram-video?url=${q.trim()}&apikey=Yukizinho`;
await miwa.sendMessage(from, { video: { url: instaVideo }, mimetype: "video/mp4" }, { quoted: info });
} else if (contentType.includes('image/jpeg')) {
const instaImagem = `http://br2.bronxyshost.com:4130/download/instagram-video?url=${q.trim()}&apikey=Yukizinho`;
await miwa.sendMessage(from, { image: { url: instaImagem } }, { quoted: info });
} else {
reply("ocorreu um erro, esse tipo de mídia não é suportado.");
}
} else {
reply("ocorreu um erro ou não foi possível baixar esse vídeo.");
}
} catch (e) {
reply("algo aconteceu ou a api foi de Vasco :/");
}
break



case 'puxarlinha': 
 const caso = args[0].toLowerCase();
 const casoEncontrado = fs.readFileSync("./index.js").toString().split('case \'' + caso + '\'');
 
 if (casoEncontrado.length > 1) {
 const linha = casoEncontrado[0].split('\n').length;
 reply(`ᴀ ᴄᴀsᴇ '${caso}' ᴇsᴛᴀ́ ɴᴀ ʟɪɴʜᴀ ${linha} ᴅᴏ sᴇᴜ ɪɴᴅᴇx.ᴊs.`);
 } else {
 reply(`ᴄᴀsᴇ '${caso}' ɴᴀ̃ᴏ ᴇɴᴄᴏɴᴛʀᴀᴅᴀ.`);
 }
 break



case 'upload':
 try {
 let fileBuffer;
 let fileType;

 // Verifica se uma imagem foi marcada
 if (isQuotedImage) {
 boij = isQuotedImage || isQuotedImage ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.imageMessage : info;
 fileBuffer = await getFileBuffer(boij, 'image');
 fileType = 'jpg'; // Definindo a extensão como jpg para imagem
 } else if (isQuotedSticker) {
 //Verifica se um sticker foi marcado
 boij= isQuotedSticker || isQuotedSticker ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.stickerMessage : info;
 fileBuffer = await getFileBuffer(boij, 'sticker');
 fileType = 'webp'; //definido a extensão webp para figurinhas
 } else if (isQuotedVideo) {
 // Verifica se um vídeo foi marcado
 boij = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage;
 fileBuffer = await getFileBuffer(boij, 'video');
 fileType = 'mp4'; // Definindo a extensão como mp4 para vídeo
 } else if (isQuotedAudio) {
 // Verifica se um áudio foi marcado
 boij = isQuotedAudio || isQuotedAudio ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.audioMessage : info;
 fileBuffer = await getFileBuffer(boij, 'audio');
 fileType = 'mp3'; // Definindo a extensão como mp3 para áudio
 } else {
 reply('Você deve marcar uma imagem, vídeo ou áudio.');
 return;
 }


 reply('Aguarde um momento enquanto estou criando o seu link...');

 // Envia o arquivo e obtém o link
 const fileUrl = await upload(fileBuffer, fileType);

 // Envia o link do arquivo para o chat
 await miwa.sendMessage(from, {video: {url: `http://nxf-01.nexfuture.com.br:25571/uploads/1731798090208-file.mp4`},caption: `
☺️🔗 prontinho, aqui está o seu link gerado pela api de upload da Yuxinze: 

${fileUrl}

> tire o "s" do "https".
> tutorial de como tirar o "s" do "https" acima.
`});
 } catch (e) {
 console.error('Erro ao enviar o arquivo:', e);
 reply('Erro ao enviar o arquivo.');
 }
 break



case 'minerarcarvao':
if (!isGroup) return reply('apenas para grupos')
reagir(from, '⛏️')
let minerado = Math.floor(Math.random() * 100)
AdicionarSaldo(sender, minerado)
let saldoAtual = VerSaldo(sender)
await miwa.sendMessage(from, {image: {url:`https://storage.oberonhosting.com.br/media/e530f3cd4e2c2b4d.jpg`}, caption: `Você minerou ${minerado} de carvão!
Seu saldo atual é: ${saldoAtual}`})
break

case 'minerarferro':
 if (!isGroup) return reply('apenas para grupos')
 reagir(from, '⛏️')
 let minerador = Math.floor(Math.random() * 100)
 AdicionarSaldo(sender, minerador)
 let totaldesaldo = VerSaldo(sender)
 await miwa.sendMessage(from, {
 image: { url: `http://br5.bronxyshost.com:4034/uploads/1731324021377.jpg` },
 caption: `Você minerou ${minerador} de ferro!
Seu saldo atual é: ${totaldesaldo}`
 })
 break

case 'minerarouro':// Lana modz 
 if (!isGroup) return reply('apenas para grupos')
 reagir(from, '⛏️')
 let ourocoins = Math.floor(Math.random() * 50) + 50 // Valor ajustado para minerar entre 50 e 100 de ouro
 AdicionarSaldo(sender, ourocoins)
 let saldoCoins = VerSaldo(sender)
 await miwa.sendMessage(from, {image: {url: `http://br5.bronxyshost.com:4034/uploads/1731325428613.jpg`}, caption: `Você minerou ${ourocoins} de ouro!
Seu saldo atual é: ${saldoCoins}`})
 break

case 'explorarcaverna'://Lana Modz 
 if (!isGroup) return reply('apenas para grupos')
 reagir(from, '⛏️')

 // Simula a descoberta de ouro em uma exploração
 let cavernacoins = Math.floor(Math.random() * 50) + 50 // Gera entre 50 e 100 moedas de ouro
 AdicionarSaldo(sender, cavernacoins)
 let exploraCoins = VerSaldo(sender)

 // Envia a mensagem com uma imagem ilustrativa
 await miwa.sendMessage(from, {
 image: { url: `https://storage.oberonhosting.com.br/media/ec23200a4aec69a6.jpg` },
 caption: `Você explorou uma caverna misteriosa e encontrou ${cavernacoins} de ouro!
Seu saldo atual é: ${exploraCoins}`
 })
 break



case 'spotify': {//𝒀𝒖𝒙𝒊𝒏𝒛𝒆-𝑨𝒑𝒊𝒔
if(!q.trim().includes("spotify")) {
return reply(`falta url da música que você deseja baixar do Spotify\nexemplo: ${prefix + command} url da música`);
}
reply('aguarde, estou baixando sua música direto do spotify!');
try {
const apiSpotify = `http://br2.bronxyshost.com:4130/spotifydl?url=${q}&apikey=Yukizinho`;
miwa.sendMessage(from, { audio: { url: apiSpotify }, mimetype: "audio/mpeg" }, { quoted: info })
.catch(() => reply("ocorreu um erro ao baixar sua música."));
} catch (e) {
console.log(e);
return reply("ops, algo aconteceu ou a Api foi de Vasco :/");
}}
break



case 'plaq':
case 'plaq1': 
case 'plaq2':
case 'plaq3':
case 'plaq4':
case 'plaq5':              
case 'plaq6':
case 'plaq7':
case 'plaq8':
if(!q) return reply('coloque o nome que você quer colocar na plaquinha')
apiPlaq = await getBuffer(`http://br2.bronxyshost.com:4130/api/${command}?texto=${q}&apikey=Yukizinho`)
await miwa.sendMessage(from, {image: apiPlaq }, {quoted: info}).catch(e => {
reply('ocorreu um erro ou a Api foi de Vasco :/')
})
break



;//𝒀𝒖𝒙𝒊𝒏𝒛𝒆-𝑨𝒑𝒊𝒔



















;



;






























      

        default:

          //===(CRÉDITOS : miwa CONTEÚDOS)==\\

          if (isGroup && isBotGroupAdmins && !isGroupAdmins) {
            if (isAntiCtt || Antiloc || isAnticatalogo) {
              if (type === 'contactMessage' || type === 'contactsArrayMessage' || type === 'locationMessage' || type === 'productMessage') {
                if (isGroupAdmins) return await miwa.sendMessage(from, { text: `Uma dessas opções estão ativada, mas por você ser ADM, não será removido(a) _(ANTI CONTATO - ANTI CATALOGO - ANTI LOCALIZAÇÃO)_` }, { quoted: info })
                if (IS_DELETE) {
                  setTimeout(() => {
                    miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
                  }, 500)
                }
                if (!JSON.stringify(groupMembers).includes(sender)) return
                miwa.groupParticipantsUpdate(from, [sender], 'remove')
                clear = `🗑${"\n".repeat(255)}🗑️\n❲❗❳ *Lɪᴍᴘᴇᴢᴀ ᴅᴇ Cʜᴀᴛ Cᴏɴᴄʟᴜɪᴅᴀ* ✅`
                await miwa.sendMessage(from, { text: clear, contextInfo: { forwardingScore: 500, isForwarded: true } })
                await miwa.sendMessage(from, { text: 'reporte aos adm o ocorrido ', mentions: groupAdmins })
              }
            }
          }

          if (isGroup && isAntiFlood && !SoDono && !isPremium && !isnit && isBotGroupAdmins && !isGroupAdmins && !isBot) {
            if (isLimitec == null) {
              var limitefl = limitefll.limitefl
            } else {
              var limitefl = isLimitec
            }
            if (budy.length >= limitefl) {
              setTimeout(() => {
                return reply('Muitos caracteres enviados, isto é contra as normas do grupo, por precaução, eu irei remover.')
                console.log(colors.red('Deram Spam de caracteres..'))
              }, 100)
              setTimeout(async () => {
                if (IS_DELETE) {
                  setTimeout(() => {
                    miwa.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender } })
                  }, 500)
                }
                if (!JSON.stringify(groupMembers).includes(sender)) return
                miwa.groupParticipantsUpdate(from, [sender], 'remove')
              }, 1000)
            }
          }

          //INICIO DE COMANDOS SEM PREFIXO
          switch (testat) {
          }



          //==============(ANTILINK)===============\\

          switch (ants) {
          }

          //=========[--ANTI PALAVRÃO --]==========\\
          if (isGroup && isPalavrao && isBotGroupAdmins) {
            if (dataGp[0].antipalavrao.palavras.indexOf(PR_String) >= 0) {
              if (!isGroupAdmins) {
                await miwa.sendMessage(from, { text: `Sem palavrão aqui!😠` }, { quoted: info })
                setTimeout(() => {
                  if (!JSON.stringify(groupMembers).includes(sender)) return
                  miwa.groupParticipantsUpdate(from, [sender], 'remove')
                }, 2000)
                setTimeout(() => {
                  miwa.sendMessage(from, { text: `*「 - REMOVIDO POR UTILIZAR UMA PALAVRA PROIBIDA - 」*\nVocê será banido do grupo, na proxima veja as regras ao digitar qualquer palavra..!!` }, { quoted: info }).catch(e => {
                    miwa.sendMessage(from, { text: `Infelizmente, não sou um administrador, entt não posso te banir!!` }, { quoted: info })
                  })
                }, 200)
              } else {
                return reply(`Você tem permissão: ${pushname} 😇`)
              }
            }
          }

          //===============(SIMIH-1)===============\\

          if (isGroup && isSimi && budy != undefined) {
            if (type == 'imageMessage') return
            if (type == 'audioMessage') return
            if (type == 'stickerMessage') return
            if (info.key.fromMe) return
            console.log(budy)
            muehe = await simih(budy)
            console.log(muehe)
            reply(muehe)
          }

          //=========================================\\

          hora2 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');

          if (isCmd) {
            const cmdSimilarity = listCommands(command);
            similarityCommands = cmdSimilarity.similarity > 40 ? `
┏━━━━━━━━━━°❀•°✮°•❀°━━━━━━━━━┓
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪├ׁ̟̇𖠵⃕⁖🌸➤ Este comando não existe!
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪├ׁ̟̇𖠵⃕⁖🌸➤ Comando utilizado: *${prefix + command}*
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪├ׁ̟̇𖠵⃕⁖🌸➤ Comando com semelhança: *${prefix + cmdSimilarity.command || '0'}*
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪├ׁ̟̇𖠵⃕⁖🌸➤ Grau de semelhança: *${cmdSimilarity.similarity || '0'}%*
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪├ׁ̟̇𖠵⃕⁖🌸➤ Para ver todos os comandos digite: *${prefix}menu*
║┃֪࣪├ׁ̟̇𖠵⃕⁖
┗━━━━━━━━━━°❀•°✮°•❀°━━━━━━━━━┛` :

              `
┏━━━━━━━━━━°❀•°✮°•❀°━━━━━━━━━┓
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃🌸➤ Não encontrei um comando com alguma semelhança!
║┃֪࣪├ׁ̟̇𖠵⃕⁖
║┃֪࣪🌸➤ Para ver todos os comandos digite: *${prefix}menu*
║┃֪࣪├ׁ̟̇𖠵⃕⁖
┗━━━━━━━━━━°❀•°✮°•❀°━━━━━━━━━┛`;
            await reagir(from, '❌');
            /*await miwa.sendMessage(from, {
              image: { url: `https://i.imgur.com/SsMoe3k.jpeg` }*/await miwa.sendMessage(from,{image: fs.readFileSync('./fotos/iscmd.jpg'), caption: `𝑩𝒚: 𝒀𝒖𝒌𝒊 𝑴𝒐𝒅𝒔.\n
${similarityCommands}`
            }, { quoted: info })
          }

          //========(totext)===========\\

          

          
        //========================================\\
      }
    }
  }
  msgupsrt().catch(async (e) => {
    if (JSON.stringify(e).includes(API_KEY_MIWA)) {
      return console.log("A api caiu ou não foi possivel executar esta ação., espere retornar")
    } else if (String(e).includes("Erro: aborted")) {
      file = require.resolve("./connect.js")
      delete require.cache[file]
      require(file)
    } else {
      return console.log(e)
    }
  })
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(colors.red(`Modificação detectada: '.${__filename}' - Arquivo Atualizado.`))
  delete require.cache[file]
  require(file)
})
